/* SPDX-License-Identifier: GPL-3.0-only */
/* The firmware as one translation unit, in dependency order. The backend (web/hal_web.c, fm1/hal_fm1.c)
 * includes this file after defining the hal_* functions' bodies it owns. */
#include <stdint.h>
#ifdef ORBIT_FREESTANDING                 /* the device: no C library; memcpy, memset come with the hardware layer */
static unsigned strlen(const char *s) { unsigned n = 0; while (s[n]) n++; return n; }
static char *strcpy(char *d, const char *s) { char *r = d; do *d++ = *s; while (*s++); return r; }
static char *strcat(char *d, const char *s) { strcpy(d + strlen(d), s); return d; }
static void *memmove(void *d, const void *s, unsigned n)
{
    uint8_t *a = d;
    const uint8_t *b = s;
    if (a < b)
        while (n--) *a++ = *b++;
    else
        while (n--) a[n] = b[n];
    return d;
}
#else
#include <string.h>
#endif
#include "hal.h"
#include "tables.h"                       /* build/gen: SINE and the FM core's tables (third_party/felucca tools) */
#include "../third_party/felucca/src/fm6_core.c"
#include "voices.h"                       /* build/gen: the factory bank */
#include "fx.c"
#include "synth.c"
#include "play.c"
#include "gfx.c"
#include "app.c"
