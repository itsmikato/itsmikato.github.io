/* SPDX-License-Identifier: GPL-3.0-only */
/* The six effects of the FM-1, in a fixed chain: DIST > FILTER > PHASER > CHORUS > DELAY > REVERB. Each has
 * an on / off switch and three settings (0..100; FILTER's and REVERB's first is a type 0..2). Integer only.
 * In: the voices' mix, mono, Q23. Out: left and right. The audio context runs fx_block; the main loop only
 * writes fx.on[] and fx.p[][] (single bytes). */
enum { FX_DIST, FX_FILTER, FX_PHASER, FX_CHORUS, FX_DELAY, FX_REVERB, FX_N };
#define CH_LEN 2048u
#define DL_LEN 32768u
static const uint16_t RV_LEN[2][6] = {{1116, 1188, 1277, 1356, 556, 441}, {1139, 1211, 1300, 1379, 579, 464}};
#define RV_TOTAL (1116 + 1188 + 1277 + 1356 + 556 + 441 + 1139 + 1211 + 1300 + 1379 + 579 + 464)

static struct {
    uint8_t on[FX_N], p[FX_N][3];
    int32_t d_lp;                         /* DIST: its tone filter */
    int32_t f_low, f_band;                /* FILTER */
    int32_t ph_z[4], ph_fb;               /* PHASER: its stages, what it feeds back */
    uint32_t ph_lfo;
    int16_t ch_buf[CH_LEN];               /* CHORUS */
    uint32_t ch_w, ch_lfo;
    int16_t dl_buf[DL_LEN];               /* DELAY */
    uint32_t dl_w;
    int16_t rv_buf[RV_TOTAL];             /* REVERB: per side four combs, two allpasses */
    uint16_t rv_at[2][6];
    int32_t rv_lp[2][4];
    uint16_t cut[100];                    /* FILTER: its coefficient per cutoff step (100 Hz .. 20 kHz) */
} fx;

static __attribute__((noinline)) int32_t mq15(int32_t a, int32_t b) { return (int32_t)(((int64_t)a * b) >> 15); }
static int32_t sat16(int32_t x) { return x > 32767 ? 32767 : x < -32767 ? -32767 : x; }
static int32_t fx_sin(uint32_t ph)        /* sine of a 32-bit phase, Q15 */
{
    uint32_t i = ph >> 22;
    int32_t a = SINE[i], b = SINE[i + 1u];
    return a + (((b - a) * (int32_t)((ph >> 7) & 0x7FFFu)) >> 15);
}
/* FILTER's cutoff step as Hz: 100 x 200 ^ (step / 99) */
static uint32_t fx_cut_hz(uint32_t step)
{
    uint32_t hz_q8 = 100u << 8, i;
    for (i = 0; i < step && i < 99u; i++)
        hz_q8 = (uint32_t)(((uint64_t)hz_q8 * 69139u) >> 16);      /* x 200 ^ (1 / 99) */
    return hz_q8 >> 8;
}

/* every effect's three values as a sound has them that never had its effects touched */
static const uint8_t FX_USUAL[FX_N][3] = {{40, 60, 70}, {0, 70, 20}, {30, 60, 50}, {30, 50, 50}, {40, 40, 35}, {1, 50, 30}};
static void fx_init(void)
{
    uint32_t i;
    memset(&fx, 0, sizeof fx);
    memcpy(fx.p, FX_USUAL, sizeof FX_USUAL);
    for (i = 0; i < 100u; i++) {          /* a state-variable filter run twice a sample: f = 2 sin(pi fc / 2 fs) */
        int32_t f = 2 * fx_sin(fx_cut_hz(i) * 24348u);        /* (2^32 / (4 x 44100): 20 kHz stays in 32 bits) */
        fx.cut[i] = (uint16_t)(f > 26000 ? 26000 : f);   /* (0.8: about 11 kHz, where it is still well-behaved) */
    }
}

static int32_t fx_comb(uint32_t side, uint32_t k, int16_t *buf, int32_t in, int32_t fb, int32_t damp)
{
    int32_t y = buf[fx.rv_at[side][k]];
    fx.rv_lp[side][k] = y + mq15(fx.rv_lp[side][k] - y, damp);
    buf[fx.rv_at[side][k]] = (int16_t)sat16(in + mq15(fx.rv_lp[side][k], fb));
    if (++fx.rv_at[side][k] >= RV_LEN[side][k])
        fx.rv_at[side][k] = 0;
    return y;
}
static int32_t fx_allpass(uint32_t side, uint32_t k, int16_t *buf, int32_t in)
{
    int32_t b = buf[fx.rv_at[side][k]], y = b - in;
    buf[fx.rv_at[side][k]] = (int16_t)sat16(in + (b >> 1));
    if (++fx.rv_at[side][k] >= RV_LEN[side][k])
        fx.rv_at[side][k] = 0;
    return y;
}

/* n samples: in[] (mono, Q23) through the chain into l[] and r[] */
static void fx_block(const int32_t *in, int32_t *l, int32_t *r, uint32_t n)
{
    const uint8_t *p;
    uint32_t i, k;
    for (i = 0; i < n; i++) {
        int32_t x = in[i], xl, xr;
        if (fx.on[FX_DIST]) {             /* gain into a soft clip (1.5 c - 0.5 c^3), a tone low-pass, a level */
            int32_t c, y;
            p = fx.p[FX_DIST];
            /* the drive: a single note (about 2^19 here) is a quarter of the way to the ceiling at GAIN 0 and
             * far over it from the middle up; out again at about the level a chord comes in */
            c = sat16(((x >> 6) * (8 + p[0] * 5)) >> 3);
            y = (3 * c - mq15(mq15(c, c), c)) / 2;
            fx.d_lp += mq15((y << 6) - fx.d_lp, 1500 + p[1] * 300);
            x = fx.d_lp / 100 * p[2];
        }
        if (fx.on[FX_FILTER]) {           /* low, band or high pass with resonance */
            int32_t f, q, high = 0;
            p = fx.p[FX_FILTER];
            f = fx.cut[p[1] > 99 ? 99 : p[1]];
            q = 65536 - p[2] * 622;       /* damping: 2 (none) .. 0.1 */
            if (q > 62000 - f)            /* this filter only stays stable while damping < 2 - f: at a high cutoff */
                q = 62000 - f;            /* it gets less (a little resonance comes with it) */
            for (k = 0; k < 2u; k++) {
                fx.f_low += mq15(f, fx.f_band);
                high = x - fx.f_low - mq15(q, fx.f_band);
                fx.f_band += mq15(f, high);
                fx.f_band = fx.f_band > (1 << 27) ? 1 << 27 : fx.f_band < -(1 << 27) ? -(1 << 27) : fx.f_band;
                fx.f_low = fx.f_low > (1 << 27) ? 1 << 27 : fx.f_low < -(1 << 27) ? -(1 << 27) : fx.f_low;
            }
            x = p[0] == 0 ? fx.f_low : p[0] == 1 ? fx.f_band : high;
            x = x > (1 << 25) ? 1 << 25 : x < -(1 << 25) ? -(1 << 25) : x;
        }
        if (fx.on[FX_PHASER]) {           /* four all-pass stages swept by a triangle, fed back into themselves and */
            int32_t t, a, y;              /* mixed with the dry sound: two notches travelling up and down */
            p = fx.p[FX_PHASER];
            fx.ph_lfo += (5u + p[0] * 5u) * 974u;                   /* 0.05 .. 5 Hz */
            t = (int32_t)(fx.ph_lfo >> 16);
            t = t < 32768 ? t : 65535 - t;
            /* the stages' coefficient: 0.97 (their turning point near 200 Hz) down to, at full DEPTH, 0.36
             * (near 5 kHz); the first notch lies at 0.4 of the turning point, the second at 2.4 */
            a = 31800 - (((32767 - t) * (p[1] * 200)) >> 15);
            y = x + fx.ph_fb / 2;         /* (feedback 0.5: the notches' edges sharper) */
            y = y > (1 << 26) ? 1 << 26 : y < -(1 << 26) ? -(1 << 26) : y;
            for (k = 0; k < 4u; k++) {
                int32_t o = fx.ph_z[k] - mq15(a, y);
                fx.ph_z[k] = y + mq15(a, o);
                y = o;
            }
            fx.ph_fb = y;
            k = p[2] * 192u / 100u;       /* the share of the swept sound: half (the deepest notches) from MIX 67 on */
            x += (y - x) / 256 * (int32_t)(k > 128u ? 128u : k);
        }
        xl = xr = x;
        if (fx.on[FX_CHORUS]) {           /* a short delay swept by a sine, a quarter turn apart left and right */
            int32_t tap[2];
            p = fx.p[FX_CHORUS];
            fx.ch_buf[fx.ch_w & (CH_LEN - 1u)] = (int16_t)sat16(x >> 8);
            fx.ch_lfo += (10u + p[0] * 8u) * 974u;                  /* 0.1 .. 8 Hz */
            for (k = 0; k < 2u; k++) {
                int32_t d = (529 << 8) + ((fx_sin(fx.ch_lfo + k * 0x40000000u) * (p[1] * 679)) >> 15);   /* 12 ms +- 6 */
                uint32_t at = fx.ch_w - (uint32_t)(d >> 8);
                int32_t a = fx.ch_buf[at & (CH_LEN - 1u)], b = fx.ch_buf[(at - 1u) & (CH_LEN - 1u)];
                tap[k] = (a << 8) + (b - a) * (d & 255);
            }
            fx.ch_w++;
            xl += tap[0] / 128 * p[2];
            xr += tap[1] / 128 * p[2];
        }
        if (fx.on[FX_DELAY]) {            /* 30 .. 740 ms, repeating */
            int32_t rd, m = (xl + xr) / 2;
            p = fx.p[FX_DELAY];
            rd = fx.dl_buf[(fx.dl_w - (1300u + p[0] * 314u)) & (DL_LEN - 1u)];
            fx.dl_buf[fx.dl_w++ & (DL_LEN - 1u)] = (int16_t)sat16((m >> 8) + mq15(rd, p[1] * 295));
            xl += (rd << 8) / 100 * p[2];
            xr += (rd << 8) / 100 * p[2];
        }
        if (fx.on[FX_REVERB]) {           /* ROOM, HALL, PLATE: how long it rings and how dull it gets */
            static const int16_t FB0[3] = {22900, 26200, 24600}, FBR[3] = {66, 56, 66}, DAMP[3] = {13100, 9800, 3300};
            int32_t m = (xl + xr) >> 11, fb, wet;                   /* (a quarter of the level into the tank) */
            int16_t *buf = fx.rv_buf;
            uint32_t side, ty;
            p = fx.p[FX_REVERB];
            ty = p[0] > 2 ? 2 : p[0];
            fb = FB0[ty] + p[1] * FBR[ty];
            for (side = 0; side < 2u; side++) {
                wet = 0;
                for (k = 0; k < 4u; k++) {
                    wet += fx_comb(side, k, buf, m, fb, DAMP[ty]);
                    buf += RV_LEN[side][k];
                }
                for (k = 4; k < 6u; k++) {
                    wet = fx_allpass(side, k, buf, wet);
                    buf += RV_LEN[side][k];
                }
                if (side)
                    xr += (wet << 8) / 100 * p[2];
                else
                    xl += (wet << 8) / 100 * p[2];
            }
        }
        l[i] = xl;
        r[i] = xr;
    }
}
