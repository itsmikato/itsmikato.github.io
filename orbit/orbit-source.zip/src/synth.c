/* SPDX-License-Identifier: GPL-3.0-only */
/* The sound: one six-operator FM patch, SYN_VOICES notes of it, on the FM core (third_party/felucca
 * fm6_core.c, a C port of msfa). The main loop edits the patch and queues notes; the audio context
 * (syn_render) plays them. What crosses between the two: the note queue (one writer, one reader), and the
 * patch, copied under hal_lock. */
#define SYN_VOICES 12                     /* as the stock FM-1 (measured on one unit: six notes take a fifth of the
                                           * processor, the effects another fifth) */
#define SCOPE_N 512u

typedef struct {
    fm6_note_t n;
    uint8_t note, held;
    uint32_t born;
    int32_t pitch;                        /* where the note's pitch is now: 1/16 semitone, Q8 (GLIDE moves it to the note) */
    int32_t rel_from[6];                  /* each envelope's level when the key was let go (for the screen) */
} syn_voice_t;

static struct {
    uint8_t patch[FP_SIZE];               /* what sounds: the edited patch with the macros applied */
    uint8_t next[FP_SIZE];                /* another sound was chosen: what sounds once the notes of the one before are out */
    int32_t next_tone;
    volatile uint8_t cut;                 /* (syn_cut: blocks left of their fade; then next is the patch) */
    syn_voice_t v[SYN_VOICES];
    fm6_lfo_t lfo;
    int32_t tone;                         /* a level offset of the modulators, microsteps */
    uint32_t clock;
    volatile uint8_t q_w, q_r;
    struct { uint8_t note, vel; } q[32];
    uint32_t master;                      /* 0..1023 */
    uint8_t limit;                        /* how many notes may sound now: SYN_VOICES, fewer while the processor is short (app.c) */
    uint8_t glide;                        /* 0 off .. 99: the time a new note takes to arrive from the one before */
    int8_t tune;                          /* cents, -50 .. 50 */
    int32_t last_pitch;                   /* the pitch the newest note is heading for (the next one starts there) */
    uint8_t mono[8], mono_n;              /* GLIDE on: one note at a time; the keys held, the newest last */
    /* for the screen */
    int16_t scope[SCOPE_N];
    uint32_t scope_w;
    int32_t op_level[6];                  /* the loudest sounding envelope per operator (the sixth first), Q24 log2 */
    /* the newest sounding note's envelopes, per operator (the sixth first): the stage (0 attack, 1 decay,
     * 2 held, 3 released, 4 none) and how far through it the envelope is (0..255) */
    uint8_t op_stage[6], op_prog[6];
    uint8_t any_held;                     /* a note is being held (else what sounds is ringing out) */
} syn;

/* the packed 128-byte voice -> the 155-byte patch (FP_*) */
static void syn_unpack(uint8_t *d, const uint8_t *s)
{
    uint32_t k, i;
    for (k = 0; k < 6u; k++, d += FP_OP, s += 17) {
        for (i = 0; i < 11u; i++)
            d[i] = s[i] & 127u;           /* rates, levels, break point, depths */
        d[FP_LC] = s[11] & 3u;
        d[FP_RC] = (s[11] >> 2) & 3u;
        d[FP_RS] = s[12] & 7u;
        d[FP_DET] = (s[12] >> 3) & 15u;
        d[FP_AMS] = s[13] & 3u;
        d[FP_KVS] = (s[13] >> 2) & 7u;
        d[FP_OL] = s[14] & 127u;
        d[FP_MODE] = s[15] & 1u;
        d[FP_FC] = (s[15] >> 1) & 31u;
        d[FP_FF] = s[16] & 127u;
    }
    for (i = 0; i < 8u; i++)
        d[i] = s[i] & 127u;               /* pitch envelope: rates, levels (d is at FP_PR1 now) */
    d += 8;
    s += 8;
    d[0] = s[0] & 31u;                    /* algorithm */
    d[1] = s[1] & 7u;                     /* feedback */
    d[2] = (s[1] >> 3) & 1u;              /* oscillator key sync */
    d[3] = s[2] & 127u;                   /* LFO speed, delay, pitch depth, amplitude depth */
    d[4] = s[3] & 127u;
    d[5] = s[4] & 127u;
    d[6] = s[5] & 127u;
    d[7] = s[6] & 1u;                     /* LFO key sync */
    d[8] = (s[6] >> 1) & 7u;              /* LFO wave */
    d[9] = (s[6] >> 4) & 7u;              /* pitch modulation sensitivity */
    d[10] = s[7] & 127u;                  /* transpose */
    for (i = 0; i < 10u; i++)
        d[11 + i] = s[8 + i] & 127u;      /* name */
}

/* the 155-byte patch -> the packed 128-byte voice (syn_unpack the other way) */
static void syn_pack(uint8_t *d, const uint8_t *s)
{
    uint32_t k, i;
    for (k = 0; k < 6u; k++, s += FP_OP, d += 17) {
        for (i = 0; i < 11u; i++)
            d[i] = s[i] & 127u;
        d[11] = (uint8_t)((s[FP_LC] & 3u) | (s[FP_RC] & 3u) << 2);
        d[12] = (uint8_t)((s[FP_RS] & 7u) | (s[FP_DET] & 15u) << 3);
        d[13] = (uint8_t)((s[FP_AMS] & 3u) | (s[FP_KVS] & 7u) << 2);
        d[14] = s[FP_OL] & 127u;
        d[15] = (uint8_t)((s[FP_MODE] & 1u) | (s[FP_FC] & 31u) << 1);
        d[16] = s[FP_FF] & 127u;
    }
    for (i = 0; i < 8u; i++)
        d[i] = s[i] & 127u;
    d += 8;
    s += 8;
    d[0] = s[0] & 31u;
    d[1] = (uint8_t)((s[1] & 7u) | (s[2] & 1u) << 3);
    d[2] = s[3] & 127u;
    d[3] = s[4] & 127u;
    d[4] = s[5] & 127u;
    d[5] = s[6] & 127u;
    d[6] = (uint8_t)((s[7] & 1u) | (s[8] & 7u) << 1 | (s[9] & 7u) << 4);
    d[7] = s[10] & 127u;
    for (i = 0; i < 10u; i++)
        d[8 + i] = s[11 + i] & 127u;
}

/* a patch from outside (a file somebody made): every value into the range the engine takes, the name into
 * letters the screen has */
static void syn_tidy(uint8_t *d)
{
    uint32_t k, i;
    for (k = 0; k < 6u; k++, d += FP_OP) {
        for (i = 0; i < 11u; i++)
            if (d[i] > 99u)
                d[i] = 99;
        if (d[FP_DET] > 14u)
            d[FP_DET] = 14;
        if (d[FP_OL] > 99u)
            d[FP_OL] = 99;
        if (d[FP_FF] > 99u)
            d[FP_FF] = 99;
    }
    for (i = 0; i < 8u; i++)
        if (d[i] > 99u)
            d[i] = 99;
    d += 8;
    for (i = 3; i < 7u; i++)
        if (d[i] > 99u)
            d[i] = 99;                    /* LFO speed, delay, depths */
    if (d[8] > 5u)
        d[8] = 5;                         /* LFO wave */
    if (d[10] > 48u)
        d[10] = 48;                       /* transpose */
    for (i = 0; i < 10u; i++)
        if (d[11 + i] < 32u || d[11 + i] > 126u)
            d[11 + i] = ' ';
}

/* the main loop: this patch sounds from the next block on (notes already sounding follow it) */
static void syn_set_patch(const uint8_t *p, int32_t tone)
{
    uint32_t s = hal_lock();
    if (syn.cut) {                        /* (a cut is under way: this is what comes after it) */
        memcpy(syn.next, p, FP_SIZE);
        syn.next_tone = tone;
    } else {
        memcpy(syn.patch, p, FP_SIZE);
        syn.tone = tone;
        fm6_lfo_reset(&syn.lfo, syn.patch);
    }
    hal_unlock(s);
}

/* the main loop: another sound is about to be set (syn_set_patch follows). The notes sounding are not carried
 * into it: operators in the middle of one sound, wired up as another, howl. They fade out within 6 ms
 * and end; a key still down sounds again when it is pressed again */
static void syn_cut(void)
{
    uint32_t s = hal_lock();
    if (!syn.cut) {
        memcpy(syn.next, syn.patch, FP_SIZE);
        syn.next_tone = syn.tone;
        syn.cut = 8;                      /* blocks: 6 ms */
    }
    hal_unlock(s);
}

/* the main loop: the held note `from` is `to` from now on (the octave or TRANSP changed under a held key):
 * its pitch moves at once, its envelopes go on as they are */
static void syn_move(uint32_t from, uint32_t to)
{
    uint32_t s = hal_lock(), i;
    for (i = 0; i < SYN_VOICES; i++)
        if (syn.v[i].n.live && syn.v[i].held && syn.v[i].note == from) {
            syn.v[i].pitch += ((int32_t)to - (int32_t)from) * 16 * 256;
            syn.v[i].note = (uint8_t)to;
            hal_midi_out(0x80u, from & 127u, 0);   /* (outside, the old note ends and the new one starts) */
            hal_midi_out(0x90u, to & 127u, 100);
        }
    for (i = 0; i < syn.mono_n; i++)
        if (syn.mono[i] == from)
            syn.mono[i] = (uint8_t)to;
    if (syn.last_pitch == (int32_t)from * 16 * 256)
        syn.last_pitch = (int32_t)to * 16 * 256;
    hal_unlock(s);
}

/* the main loop: a key down (vel 1..127) or up (vel 0) */
static void syn_note(uint32_t note, uint32_t vel)
{
    uint8_t w = syn.q_w;
    if ((uint8_t)(w + 1u) % 32u == syn.q_r)
        return;                           /* full: dropped */
    syn.q[w].note = (uint8_t)note;
    syn.q[w].vel = (uint8_t)vel;
    syn.q_w = (uint8_t)((w + 1u) % 32u);
}
/* the main loop: a note that came in over MIDI (it sounds, and is not sent out again) */
static void syn_note_in(uint32_t note, uint32_t vel) { syn_note(note, (vel & 127u) | 0x80u); }

static void syn_play(uint32_t note, uint32_t vel);
/* GLIDE on: the newest held key sounds; let go, the one held before it comes back */
static int syn_mono(uint32_t note, uint32_t vel)
{
    uint32_t i, k = 0, was = syn.mono_n ? syn.mono[syn.mono_n - 1u] : 255u;
    if (!syn.glide) {
        syn.mono_n = 0;
        return 0;
    }
    for (i = 0; i < syn.mono_n; i++)      /* out of the stack; a key down goes on its top */
        if (syn.mono[i] != note)
            syn.mono[k++] = syn.mono[i];
    if (vel && k == 8u) {
        memmove(syn.mono, syn.mono + 1, 7);
        k = 7;
    }
    if (vel)
        syn.mono[k++] = (uint8_t)note;
    syn.mono_n = (uint8_t)k;
    if (vel) {
        return 0;                         /* (the caller starts it, in the voice that sounds) */
    }
    if (note != was)
        return 1;                         /* a key under the sounding one let go: nothing to hear */
    if (k) {                              /* back to the key still held */
        uint8_t back = syn.mono[k - 1u];
        syn.mono_n = (uint8_t)(k - 1u);
        syn_play(back, 100);
        return 1;
    }
    return 0;                             /* the last key: an ordinary release */
}

/* a note starts (vel 1..127) or is let go (vel 0), in the sound only */
static void syn_play(uint32_t note, uint32_t vel)
{
    const uint8_t *p = syn.patch;
    syn_voice_t *v = 0;
    uint32_t i, was_live;
    if (syn_mono(note, vel))
        return;
    if (!vel) {
        for (i = 0; i < SYN_VOICES; i++)
            if (syn.v[i].held && syn.v[i].note == note) {
                uint32_t k;
                syn.v[i].held = 0;
                for (k = 0; k < 6u; k++)
                    syn.v[i].rel_from[k] = syn.v[i].n.env[k].level;
                fm6_note_key(&syn.v[i].n, p, 0);
            }
        return;
    }
    for (i = 0; i < SYN_VOICES && !v; i++)   /* GLIDE on: the one voice, whatever it plays */
        if (syn.glide && syn.v[i].n.live)
            v = &syn.v[i];
    for (i = 0; i < SYN_VOICES && !v; i++)   /* the same note again, else a free voice, else the oldest */
        if (syn.v[i].n.live && syn.v[i].note == note)
            v = &syn.v[i];
    for (i = 0, was_live = 0; i < SYN_VOICES; i++)
        was_live += syn.v[i].n.live != 0;
    for (i = 0; i < SYN_VOICES && !v && was_live < (syn.limit ? syn.limit : SYN_VOICES); i++)
        if (!syn.v[i].n.live)
            v = &syn.v[i];
    if (!v) {
        v = &syn.v[0];
        for (i = 1; i < SYN_VOICES; i++)
            if (syn.v[i].born < v->born)
                v = &syn.v[i];
    }
    was_live = v->n.live;
    fm6_note_init(&v->n, p, (int32_t)note + p[FP_TRNSP] - 24, (int32_t)vel, !v->n.live);
    fm6_lfo_key(&syn.lfo);
    v->note = (uint8_t)note;
    if (!syn.glide)
        v->pitch = (int32_t)note * 16 * 256;
    else if (!was_live)                   /* GLIDE: from where the pitch is, or was last */
        v->pitch = syn.last_pitch ? syn.last_pitch : (int32_t)note * 16 * 256;
    syn.last_pitch = (int32_t)note * 16 * 256;
    v->held = 1;
    v->born = ++syn.clock;
}

/* what envelope level (the core's units) the patch level lv (0..99) is for envelope e (fm6_env_advance) */
static int32_t syn_env_at(const fm6_env_t *e, int32_t lv)
{
    int32_t a = ((fm6_scaleout(lv) >> 1) << 6) + e->outlevel - 4256;
    return (a < 16 ? 16 : a) << 16;
}
/* for the screen: where the newest sounding note's envelopes are. A stage is one segment of the picture
 * (attack: up to level 1; decay: level 1 to level 3; released: from where it was let go to level 4) and the progress is the
 * envelope's level between that segment's two ends, so the dot always runs the whole segment */
static void syn_follow(void)
{
    const uint8_t *p = syn.patch;
    const syn_voice_t *v = 0;
    uint32_t i, k;
    uint8_t held = 0;
    for (i = 0; i < SYN_VOICES; i++) {
        if (syn.v[i].n.live && (!v || syn.v[i].born > v->born))
            v = &syn.v[i];
        held |= syn.v[i].n.live && syn.v[i].held;
    }
    syn.any_held = held;
    for (k = 0; k < 6u; k++) {
        const uint8_t *op = p + k * FP_OP;
        const fm6_env_t *e;
        int32_t from, to, at;
        uint32_t st;
        if (!v || v->n.env[k].ix >= 4u) {
            syn.op_stage[k] = 4;
            syn.op_prog[k] = 0;
            continue;
        }
        e = &v->n.env[k];
        st = e->ix == 0u ? 0u : e->ix < 3u ? 1u : e->down ? 2u : 3u;
        from = st == 3u ? v->rel_from[k] : syn_env_at(e, st == 0u ? 0 : op[FP_L1]);
        to = syn_env_at(e, st == 0u ? op[FP_L1] : st == 1u ? op[FP_L1 + 2] : op[FP_L1 + 3]);
        if (st == 0u && to > (1716 << 16))
            from = 1716 << 16;            /* (a rising envelope starts from here) */
        at = e->level;
        syn.op_stage[k] = (uint8_t)st;
        if (st == 3u && from == to) {
            syn.op_prog[k] = 255;         /* let go where the release ends */
        } else if (st == 2u || from == to) {
            syn.op_prog[k] = 128;         /* held, or a stage that only waits: the middle */
        } else {
            int32_t span = (to - from) / 4096, pr = span ? (at - from) / 4096 * 255 / span : 255;
            syn.op_prog[k] = (uint8_t)(pr < 0 ? 0 : pr > 255 ? 255 : pr);
        }
    }
}

/* the audio context: a note the instrument plays itself (a key, the arpeggiator, the sequencer): in the sound
 * and out over MIDI, channel 1 */
static void syn_event(uint32_t note, uint32_t vel)
{
    hal_midi_out(vel ? 0x90u : 0x80u, note & 127u, vel ? vel & 127u : 0u);
    syn_play(note, vel);
}

/* the last stage: up to 0.6 of full scale as it is; above that it bends over and never passes full scale, so
 * many loud notes press together instead of breaking up */
static int32_t syn_soft(int32_t x)
{
    int32_t a = x < 0 ? -x : x, d;
    if (a <= 5000000)
        return x;
    d = (a - 5000000) >> 8;
    d = d > 100000 ? 100000 : d;
    a = 5000000 + ((d * 13235 / (13235 + d)) << 8);   /* (13235: what is left to full scale, >> 8) */
    return x < 0 ? -a : a;
}

/* the audio context: AUDIO_BLOCK stereo frames, Q23 */
static void syn_render(int32_t *out)
{
    static const int32_t DT[6] = {0, 0, 0, 0, 0, 0};
    const uint8_t *p = syn.patch;
    int32_t mix[FM6_N], bus[FM6_N], fl[FM6_N], fr[FM6_N], lv, ld, peak[6] = {0, 0, 0, 0, 0, 0};
    uint32_t i, k, alg = p[FP_ALG] & 31u;
    while (syn.q_r != syn.q_w) {
        if (syn.q[syn.q_r].vel & 0x80u)   /* from MIDI in: not sent out again */
            syn_play(syn.q[syn.q_r].note, syn.q[syn.q_r].vel & 127u);
        else
            syn_event(syn.q[syn.q_r].note, syn.q[syn.q_r].vel);
        syn.q_r = (uint8_t)((syn.q_r + 1u) % 32u);
    }
    lv = fm6_lfo_sample(&syn.lfo);
    ld = fm6_lfo_delay(&syn.lfo);
    memset(mix, 0, sizeof mix);
    for (i = 0; i < SYN_VOICES; i++) {
        syn_voice_t *v = &syn.v[i];
        int32_t lf;
        if (!v->n.live)
            continue;
        if (v->pitch != (int32_t)v->note * 16 * 256) {   /* GLIDE: an octave in 5 ms .. 2 s */
            int32_t want = (int32_t)v->note * 16 * 256, ms = 5 + syn.glide * syn.glide / 5;
            int32_t step = 192 * 256 * 1000 / (ms * (AUDIO_FS / AUDIO_BLOCK));
            step = step < 1 ? 1 : step;
            v->pitch = !syn.glide ? want : v->pitch < want ? (v->pitch + step > want ? want : v->pitch + step)
                                                           : (v->pitch - step < want ? want : v->pitch - step);
        }
        lf = fm6_note_logfreq((v->pitch >> 8) + (p[FP_TRNSP] - 24) * 16,
                              ((v->pitch & 255) >> 4) + syn.tune * 2366 / 1000);   /* (a cent: 2.366 / 4096) */
        if (fm6_note_compute(&v->n, p, bus, lv, ld, lf, alg, p[FP_FB] & 7, DT, syn.tone << 16)) {
            for (k = 0; k < FM6_N; k++) {
                int32_t x = bus[k] - v->n.dc;
                v->n.dc += x >> 10;       /* ~7 Hz high-pass: FM leaves sidebands at 0 Hz */
                mix[k] += x >> 6;         /* room for twelve notes on the way through the effects; made up at the end */
            }
        }
        for (k = 0; k < 6u; k++)
            if (v->n.op[k].level_in > peak[k])
                peak[k] = v->n.op[k].level_in;
        if (fm6_note_done(&v->n, p, alg))
            v->n.live = 0;
    }
    if (syn.cut) {                        /* another sound: these notes out over this block, then it is the patch */
        int32_t g = (int32_t)syn.cut * 32;                      /* 256 at the start, down by one a sample */
        for (k = 0; k < FM6_N; k++)
            mix[k] = (mix[k] >> 8) * (g - (int32_t)(k * 32u / FM6_N));
        if (!--syn.cut) {
            for (i = 0; i < SYN_VOICES; i++)
                syn.v[i].n.live = 0;
            syn.mono_n = 0;
            memcpy(syn.patch, syn.next, FP_SIZE);
            syn.tone = syn.next_tone;
            fm6_lfo_reset(&syn.lfo, syn.patch);
            for (k = 0; k < 6u; k++)
                peak[k] = 0;
        }
    }
    for (k = 0; k < 6u; k++)
        syn.op_level[k] = peak[k];
    syn_follow();
    fx_block(mix, fl, fr, FM6_N);
    for (k = 0; k < FM6_N; k++) {
        /* x master / 1024 in 32 bits (no 64-bit multiply in this loop: felucca-bsp docs/CPU.md) */
        int32_t m = (int32_t)syn.master;
        int32_t xl = syn_soft(2 * ((fl[k] >> 10) * m + (((fl[k] & 1023) * m) >> 10)));
        int32_t xr = syn_soft(2 * ((fr[k] >> 10) * m + (((fr[k] & 1023) * m) >> 10)));
        out[2u * k] = xl > 8388607 ? 8388607 : xl < -8388607 ? -8388607 : xl;
        out[2u * k + 1u] = xr > 8388607 ? 8388607 : xr < -8388607 ? -8388607 : xr;
        if (!(k & 1u))                    /* the screen's scope: every other sample of the left side, before MASTER */
            syn.scope[syn.scope_w++ & (SCOPE_N - 1u)] = (int16_t)(fl[k] > 8388607 ? 32767 : fl[k] < -8388607 ? -32767 : fl[k] >> 8);
    }
}
