/* SPDX-License-Identifier: GPL-3.0-only */
/* What plays the notes besides the keys: the clock, the arpeggiator and the sequencer. They run in the
 * audio context, a block at a time (play_block, before the synth renders), so their timing does not depend
 * on the main loop. The main loop sets the settings (single bytes) and, under hal_lock, the arpeggiator's
 * keys; it writes the pattern being recorded a byte at a time. */
#define ARP_KEYS 16
#define SEQ_PATTERNS 16
#define SEQ_STEPS 16
enum { PM_OFF, PM_ARP, PM_SEQ };
enum { AM_ORDER, AM_UP, AM_DOWN, AM_INCL, AM_EXCL, AM_RANDOM, AM_REPEAT, AM_COUNT };   /* (ORDER first: as entered) */
typedef struct { uint8_t n, off, note[4]; } seq_step_t;       /* n notes; off: the step is silenced */
typedef struct { seq_step_t step[SEQ_STEPS]; uint8_t len; } seq_pattern_t;

static struct {
    /* settings */
    uint8_t mode;                         /* PM_* */
    uint16_t tempo;                       /* beats a minute */
    uint8_t swing;                        /* 50 (even) .. 75: the share of a pair of steps the first one takes */
    uint8_t arp_mode, arp_oct, arp_rate, arp_gate;
    uint8_t arp_stop;                     /* PLAY / STOP: the arpeggiator is stopped (its notes stay) */
    uint8_t hold;                         /* 1 HOLD: the keys collect notes (below); 2 LOOP: the notes stay, the keys play */
    uint8_t seq_rate, seq_gate, pattern, playing;
    int8_t shift;                         /* semitones on every note played here: the octave and TRANSP now. The
                                           * arpeggiator's keys and the patterns hold notes without them, so
                                           * OCT- / OCT+ and TRANSP move what is already playing */
    /* the arpeggiator's notes, in the order pressed: the keys held down or, with HOLD, the notes collected */
    uint8_t key[ARP_KEYS], nkeys;
    /* running */
    uint32_t pos_q8, len_q8;              /* samples into the step, the step's length */
    uint32_t step;                        /* steps played since the start */
    uint32_t rnd;
    uint8_t sounding[4], nsound;          /* the notes the step started (to let go at its gate) */
    uint8_t gate_done;
    uint8_t now;                          /* for the screen: the sequencer's step playing, the arpeggiator's place */
    seq_pattern_t pat[SEQ_PATTERNS];
} play;

/* a step as a fraction of a beat: 1/4 1/8 1/8T 1/16 1/16T 1/32 */
static const uint8_t RATE_NUM[6] = {1, 1, 1, 1, 1, 1}, RATE_DEN[6] = {1, 2, 3, 4, 6, 8};
static const char *const N_RATE[] = {"1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32"};
static const char *const N_AMODE[] = {"ORDER", "UP", "DOWN", "INCL", "EXCL", "RAND", "RPT"};

static void play_init(void)
{
    uint32_t i;
    memset(&play, 0, sizeof play);
    play.tempo = 120;
    play.swing = 50;
    play.arp_oct = 1;
    play.arp_rate = play.seq_rate = 3;
    play.arp_gate = play.seq_gate = 50;
    play.rnd = 0x1234567u;
    for (i = 0; i < SEQ_PATTERNS; i++)
        play.pat[i].len = SEQ_STEPS;
}

static void play_release(void)            /* the step's notes off */
{
    uint32_t i;
    for (i = 0; i < play.nsound; i++)
        syn_event(play.sounding[i], 0);
    play.nsound = 0;
}

static uint8_t play_shifted(uint32_t note)
{
    int32_t n = (int32_t)note + play.shift;
    return (uint8_t)(n < 0 ? 0 : n > 127 ? 127 : n);
}

/* the main loop: another mode, or the transport: from the top, nothing left sounding */
static void play_restart(void)
{
    uint32_t s = hal_lock();
    play_release();
    play.pos_q8 = play.len_q8 = 0;
    play.step = 0;
    play.now = 0;
    hal_unlock(s);
}

/* the arpeggiator's note for its n-th step: the keys in the mode's order, over the octaves */
static uint32_t arp_note(uint32_t n, uint32_t *place)
{
    uint8_t k[ARP_KEYS];
    uint32_t nk = play.nkeys, i, j, total, at, cyc;
    memcpy(k, play.key, nk);
    if (play.arp_mode != AM_ORDER)
        for (i = 1; i < nk; i++)          /* by pitch */
            for (j = i; j && k[j - 1] > k[j]; j--) {
                uint8_t t = k[j];
                k[j] = k[j - 1];
                k[j - 1] = t;
            }
    total = nk * (play.arp_oct ? play.arp_oct : 1u);
    switch (play.arp_mode) {
    case AM_DOWN: at = total - 1u - n % total; break;
    case AM_INCL: cyc = 2u * total; at = n % cyc; at = at < total ? at : cyc - 1u - at; break;
    case AM_EXCL: cyc = total > 1u ? 2u * total - 2u : 1u; at = n % cyc; at = at < total ? at : cyc - at; break;
    case AM_RANDOM: play.rnd = play.rnd * 1664525u + 1013904223u; at = (play.rnd >> 16) % total; break;
    case AM_REPEAT: at = (n / 2u) % total; break;
    default: at = n % total; break;
    }
    *place = at;
    i = (uint32_t)k[at % nk] + 12u * (at / nk);
    return i > 127u ? 127u : i;
}

/* the audio context: AUDIO_BLOCK samples on */
static void play_block(void)
{
    uint32_t rate, gate, beat_q8, pair, on;
    if (play.mode == PM_OFF || (play.mode == PM_SEQ && !play.playing) ||
        (play.mode == PM_ARP && (!play.nkeys || play.arp_stop))) {
        if (play.nsound || play.pos_q8 || play.step) {
            play_release();
            play.pos_q8 = play.len_q8 = 0;
            play.step = 0;
        }
        return;
    }
    rate = play.mode == PM_ARP ? play.arp_rate : play.seq_rate;
    gate = play.mode == PM_ARP ? play.arp_gate : play.seq_gate;
    if (play.pos_q8 >= play.len_q8) {     /* a step starts */
        play.pos_q8 -= play.len_q8;
        play_release();
        beat_q8 = AUDIO_FS * 60u * 256u / play.tempo;
        pair = 2u * beat_q8 * RATE_NUM[rate % 6u] / RATE_DEN[rate % 6u];
        on = pair * play.swing / 100u;    /* SWING: the first of two steps the longer */
        play.len_q8 = play.step & 1u ? pair - on : on;
        if (play.mode == PM_ARP) {
            uint32_t place;
            play.sounding[0] = play_shifted(arp_note(play.step, &place));
            play.nsound = 1;
            play.now = (uint8_t)place;
            syn_event(play.sounding[0], 100);
        } else {
            const seq_pattern_t *pt = &play.pat[play.pattern % SEQ_PATTERNS];
            const seq_step_t *st = &pt->step[play.step % (pt->len ? pt->len : 1u)];
            uint32_t i;
            play.now = (uint8_t)(play.step % (pt->len ? pt->len : 1u));
            for (i = 0; i < st->n && !st->off; i++) {
                play.sounding[i] = play_shifted(st->note[i]);
                syn_event(play.sounding[i], 100);
            }
            play.nsound = st->off ? 0 : st->n;
        }
        play.step++;
        play.gate_done = 0;
    }
    play.pos_q8 += AUDIO_BLOCK * 256u;
    if (!play.gate_done && play.pos_q8 >= play.len_q8 / 100u * gate && gate < 100u) {
        play_release();
        play.gate_done = 1;
    }
}

/* the main loop: a key (note) down or up while the arpeggiator is on. Without HOLD the notes are the keys
 * held. With HOLD the keys collect: a key pressed adds its note at the end, pressed again takes it out, and
 * letting go does nothing */
static void play_arp_key(uint32_t note, int down)
{
    uint32_t s = hal_lock(), i, k = 0;
    int in = 0;
    for (i = 0; i < play.nkeys; i++)
        in |= play.key[i] == note;
    if (down && !in) {                    /* a new note: at the end */
        if (play.nkeys < ARP_KEYS)
            play.key[play.nkeys++] = (uint8_t)note;
    } else if (play.hold ? down : !down) {   /* HOLD: a key pressed again takes its note out; else: the key let go */
        /* (LOOP never comes here: its keys play, app.c) */
        for (i = 0; i < play.nkeys; i++)
            if (play.key[i] != note)
                play.key[k++] = play.key[i];
        play.nkeys = (uint8_t)k;
    }
    hal_unlock(s);
}
