/* SPDX-License-Identifier: GPL-3.0-only */
/* What the firmware asks of the machine under it. Two backends: web/hal_web.c (the browser emulator) and
 * fm1/hal_fm1.c (the M-VAVE FM-1 through felucca-bsp). The app never touches hardware itself. */
#ifndef HAL_H
#define HAL_H
#include <stdint.h>

#define ORBIT_VERSION "0.1"               /* shown under the name at start-up */
#define SCR_W 240
#define SCR_H 240
#define AUDIO_FS 44100
#define AUDIO_BLOCK 32                    /* frames a render call makes (the FM core's block) */

/* buttons and encoders by their printed labels */
enum { B_FX, B_SEL, B_ENV, B_LFO, B_EDIT, B_GLO, B_HOME, B_SAVE, B_ARP, B_SEQ, B_PLAY, B_REC, B_OCTDN, B_OCTUP, NB };
enum { EN_SELECT, EN_ALGO, EN_PRESET, EN_K1, EN_K2, EN_K3, EN_K4, NE };
#define NKEYS 27                          /* F3 .. G5 */
#define KEY_LOWEST 53                     /* MIDI note of the leftmost key */

typedef struct {
    uint32_t keys;                        /* bit k: key k is down */
    uint32_t buttons;                     /* bit b: the button labelled b is down */
    int32_t enc[NE];                      /* detents turned since the last hal_input (clockwise +) */
    uint32_t master;                      /* the MASTER pot, 0..1023 */
    uint32_t battery;                     /* 0 (nearly empty) .. 3 (full) */
    uint32_t usb_power;                   /* 1: a computer is connected and powers it */
} hal_input_t;

/* provided by the backend */
static void hal_input(hal_input_t *in);
static uint32_t hal_ms(void);
static uint32_t hal_lock(void);           /* audio cannot run between lock and unlock */
static void hal_unlock(uint32_t state);
static void hal_present(const uint16_t *frame);   /* SCR_W x SCR_H, RGB565 */
/* what the instrument keeps while it is off: one block of bytes. read: n bytes of it from byte `from` (0
 * when read; they may be anything on a new device: the app checks them). write: the block is `total` bytes
 * at `base`; the part from byte `from`, n bytes long, has changed and is stored (whole 4096-byte pieces of the
 * block, so that a small change is quick); 0 when stored. Main loop only */
static int hal_store_read(void *dst, uint32_t from, uint32_t n);
static int hal_store_write(const void *base, uint32_t total, uint32_t from, uint32_t n);
static void hal_leds(uint32_t buttons, uint32_t keys);
/* a note out to a computer or another instrument (USB-MIDI): status, two data bytes. Called from the audio
 * context, or from the main loop inside hal_lock */
static void hal_midi_out(uint32_t status, uint32_t d1, uint32_t d2);
/* a SysEx message to the computer: its bytes between F0 and F7 (n <= 200) */
static void hal_sysex_out(const uint8_t *p, uint32_t n);
/* how much of its time the audio takes, in percent: the average in the low byte, the highest of the last two
 * seconds in the next (the emulator: 0) */
static uint32_t hal_load(void);   /* lit: bit b the button labelled b, bit k key k */

/* provided by the app */
static void app_init(void);
static void app_tick(void);               /* the main loop, about every 15 ms */
static void app_audio(int32_t *out);      /* AUDIO_BLOCK stereo frames, interleaved, signed Q23; audio context */
#endif
