/* SPDX-License-Identifier: GPL-3.0-only */
/* Drawing into one full frame (RGB565), handed to the screen by hal_present. Thin lines, circles, discs,
 * rectangles and anti-aliased text (the fonts: tools/gen_font.py). Everything clips to the frame. */
#define RGB(r, g, b) ((uint16_t)((((r) >> 3) << 11) | (((g) >> 2) << 5) | ((b) >> 3)))
#define C_BLACK RGB(0, 0, 0)
#define C_WHITE RGB(255, 255, 255)
#define C_GREY RGB(120, 120, 126)        /* labels */
#define C_DARK RGB(64, 64, 68)           /* guides, tracks, what is off */
#define C_BLUE RGB(64, 150, 255)
#define C_GREEN RGB(70, 220, 130)
#define C_ORANGE RGB(255, 122, 40)
#define C_TIE RGB(36, 84, 150)           /* the blue, quieter */
#define C_RED RGB(255, 70, 60)           /* recording */
static const uint16_t KNOB_COL[4] = {C_BLUE, C_GREEN, C_WHITE, C_ORANGE};   /* KNOB 1..4, left to right */

typedef struct { uint16_t off; uint8_t w, h; int8_t x, y; uint8_t adv; } glyph_t;
typedef struct { const glyph_t *g; const uint8_t *data; uint8_t line, cap_y, cap_h; } font_t;
#include "fonts.h"

static uint16_t fb[SCR_W * SCR_H];

static void g_clear(uint16_t c)
{
    uint32_t i;
    for (i = 0; i < SCR_W * SCR_H; i++)
        fb[i] = c;
}
static inline void g_pset(int32_t x, int32_t y, uint16_t c)
{
    if ((uint32_t)x < SCR_W && (uint32_t)y < SCR_H)
        fb[y * SCR_W + x] = c;
}
static void g_rect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c)
{
    int32_t i, j;
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > SCR_W) w = SCR_W - x;
    if (y + h > SCR_H) h = SCR_H - y;
    for (j = 0; j < h; j++)
        for (i = 0; i < w; i++)
            fb[(y + j) * SCR_W + x + i] = c;
}
/* ink c over what is there, coverage a (0..15) */
static inline uint16_t g_mix(uint16_t bg, uint16_t c, uint32_t a)
{
    uint32_t r = ((bg >> 11) * (15u - a) + (c >> 11) * a + 7u) / 15u;
    uint32_t g = (((bg >> 5) & 63u) * (15u - a) + ((c >> 5) & 63u) * a + 7u) / 15u;
    uint32_t b = ((bg & 31u) * (15u - a) + (c & 31u) * a + 7u) / 15u;
    return (uint16_t)(r << 11 | g << 5 | b);
}
static inline void g_blend(int32_t x, int32_t y, uint16_t c, uint32_t a)
{
    if (a && (uint32_t)x < SCR_W && (uint32_t)y < SCR_H)
        fb[y * SCR_W + x] = a >= 15u ? c : g_mix(fb[y * SCR_W + x], c, a);
}
/* a line a pixel wide with soft edges (Wu): along its long axis every step inks the two pixels it passes
 * between, each by how near it is */
static void g_line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c)
{
    int32_t dx = x1 > x0 ? x1 - x0 : x0 - x1, dy = y1 > y0 ? y1 - y0 : y0 - y1, t, grad, at, i;
    if (!dx || !dy) {                     /* straight: plain */
        if (x0 > x1) { t = x0; x0 = x1; x1 = t; }
        if (y0 > y1) { t = y0; y0 = y1; y1 = t; }
        g_rect(x0, y0, x1 - x0 + 1, y1 - y0 + 1, c);
        return;
    }
    if (dx >= dy) {
        if (x0 > x1) { t = x0; x0 = x1; x1 = t; t = y0; y0 = y1; y1 = t; }
        grad = (y1 - y0) * 65536 / (x1 - x0);
        for (i = x0, at = y0 * 65536; i <= x1; i++, at += grad) {
            uint32_t f = ((uint32_t)at >> 12) & 15u;
            g_blend(i, at >> 16, c, 15u - f);
            g_blend(i, (at >> 16) + 1, c, f);
        }
    } else {
        if (y0 > y1) { t = x0; x0 = x1; x1 = t; t = y0; y0 = y1; y1 = t; }
        grad = (x1 - x0) * 65536 / (y1 - y0);
        for (i = y0, at = x0 * 65536; i <= y1; i++, at += grad) {
            uint32_t f = ((uint32_t)at >> 12) & 15u;
            g_blend(at >> 16, i, c, 15u - f);
            g_blend((at >> 16) + 1, i, c, f);
        }
    }
}
static uint32_t g_sqrt(uint32_t v)        /* floor of the square root */
{
    uint32_t r = 0, b = 1u << 30;
    while (b > v)
        b >>= 2;
    for (; b; b >>= 2) {
        if (v >= r + b) {
            v -= r + b;
            r = (r >> 1) + b;
        } else {
            r >>= 1;
        }
    }
    return r;
}
/* sine of a 32-bit phase (2^32 = a turn), Q15 */
static int32_t g_sin(uint32_t ph)
{
    uint32_t i = ph >> 22;
    int32_t a = SINE[i], b = SINE[i + 1u];
    return a + (((b - a) * (int32_t)((ph >> 7) & 0x7FFFu)) >> 15);
}
/* the point r px from (cx, cy) at phase ph (0: up, clockwise) */
static void g_polar(int32_t cx, int32_t cy, int32_t r, uint32_t ph, int32_t *x, int32_t *y)
{
    *x = cx + ((g_sin(ph) * r + 16384) >> 15);
    *y = cy - ((g_sin(ph + 0x40000000u) * r + 16384) >> 15);
}
/* a circle a pixel wide with soft edges: an eighth of it worked out, a sixteenth of a pixel fine, and
 * mirrored */
static void g_circle(int32_t cx, int32_t cy, int32_t r, uint16_t c)
{
    int32_t x;
    if (r < 1)
        return;
    for (x = 0; x * x * 2 <= r * r + r; x++) {
        uint32_t yq = g_sqrt((uint32_t)(r * r - x * x) << 8), f = yq & 15u;
        int32_t y = (int32_t)(yq >> 4), k;
        for (k = 0; k < 2; k++) {
            int32_t yy = y + k;
            uint32_t a = k ? f : 15u - f;
            g_blend(cx + x, cy + yy, c, a); g_blend(cx + x, cy - yy, c, a);
            g_blend(cx + yy, cy + x, c, a); g_blend(cx - yy, cy + x, c, a);
            if (x) {
                g_blend(cx - x, cy + yy, c, a); g_blend(cx - x, cy - yy, c, a);
                g_blend(cx + yy, cy - x, c, a); g_blend(cx - yy, cy - x, c, a);
            }
        }
    }
}
/* a part of a circle: from phase a to phase b (0: up, clockwise; b > a) */
static void g_arc(int32_t cx, int32_t cy, int32_t r, uint32_t a, uint32_t b, uint16_t c)
{
    int32_t px, py, x, y;
    uint32_t ph, step = 0xFFFFFFFFu / 96u;
    g_polar(cx, cy, r, a, &px, &py);
    for (ph = a; ph < b; ) {
        ph = b - ph > step ? ph + step : b;
        g_polar(cx, cy, r, ph, &x, &y);
        g_line(px, py, x, y, c);
        px = x;
        py = y;
    }
}

/* a filled circle, its edge soft at the sides */
static void g_disc(int32_t cx, int32_t cy, int32_t r, uint16_t c)
{
    int32_t dy;
    if (r <= 8) {                         /* a small one: every pixel by its distance from the middle, so it is round */
        int32_t dx;
        for (dy = -r - 1; dy <= r + 1; dy++)
            for (dx = -r - 1; dx <= r + 1; dx++) {
                int32_t a = r * 16 + 8 - (int32_t)g_sqrt((uint32_t)(dx * dx + dy * dy) << 8);
                g_blend(cx + dx, cy + dy, c, a < 0 ? 0u : a > 15 ? 15u : (uint32_t)a);
            }
        return;
    }
    for (dy = -r; dy <= r; dy++) {
        uint32_t wq = g_sqrt((uint32_t)(r * r - dy * dy) << 8), f = wq & 15u;
        int32_t w = (int32_t)(wq >> 4);
        g_rect(cx - w, cy + dy, 2 * w + 1, 1, c);
        g_blend(cx - w - 1, cy + dy, c, f);
        g_blend(cx + w + 1, cy + dy, c, f);
    }
}

/* UI_LOWERCASE: every capital letter drawn small (the labels are written in capitals). The look: Space Mono,
 * lowercase; -DUI_UPPERCASE for capitals */
#ifndef UI_UPPERCASE
#define UI_LOWERCASE 1
#endif
#ifdef UI_LOWERCASE
#define G_CH(c) ((c) >= 'A' && (c) <= 'Z' ? (c) + 32 : (c))
#else
#define G_CH(c) (c)
#endif
static int32_t g_text_w(const font_t *f, const char *s)
{
    int32_t w = 0;
    for (; *s; s++)
        if (*s >= 32 && *s < 127)
            w += f->g[G_CH(*s) - 32].adv;
    return w;
}
/* s with its capitals' top at y; returns the pen's x after it */
static int32_t g_text(int32_t x, int32_t y, const font_t *f, const char *s, uint16_t c)
{
    for (; *s; s++) {
        const glyph_t *g;
        uint32_t i, j, row;
        if (*s < 32 || *s >= 127)
            continue;
        g = &f->g[G_CH(*s) - 32];
        row = (g->w + 1u) / 2u;
        for (j = 0; j < g->h; j++)
            for (i = 0; i < g->w; i++) {
                uint32_t a = f->data[g->off + j * row + i / 2u];
                int32_t px = x + g->x + (int32_t)i, py = y - f->cap_y + g->y + (int32_t)j;
                a = i & 1u ? a & 15u : a >> 4;
                if (a && (uint32_t)px < SCR_W && (uint32_t)py < SCR_H)
                    fb[py * SCR_W + px] = g_mix(fb[py * SCR_W + px], c, a);
            }
        x += g->adv;
    }
    return x;
}
/* s with the middle of what is inked of it (not of its advances and its line) at (cx, cy) */
static void g_text_mid(int32_t cx, int32_t cy, const font_t *f, const char *s, uint16_t c)
{
    int32_t pen = 0, x0 = 0, x1 = 0, y0 = 0, y1 = 0, any = 0;
    const char *t;
    for (t = s; *t; t++) {
        const glyph_t *g;
        if (*t < 32 || *t >= 127)
            continue;
        g = &f->g[G_CH(*t) - 32];
        if (g->w && g->h) {
            int32_t gy = (int32_t)g->y - (int32_t)f->cap_y;
            if (!any || pen + g->x < x0)
                x0 = pen + g->x;
            if (!any || pen + g->x + (int32_t)g->w > x1)
                x1 = pen + g->x + (int32_t)g->w;
            if (!any || gy < y0)
                y0 = gy;
            if (!any || gy + (int32_t)g->h > y1)
                y1 = gy + (int32_t)g->h;
            any = 1;
        }
        pen += g->adv;
    }
    g_text(cx - (x0 + x1) / 2, cy - (y0 + y1) / 2, f, s, c);
}
static void g_text_r(int32_t xr, int32_t y, const font_t *f, const char *s, uint16_t c)
{
    g_text(xr - g_text_w(f, s), y, f, s, c);
}
/* a signed integer into b (holds 12) */
static void g_int(char *b, int32_t v)
{
    char t[12];
    uint32_t n = 0, u = v < 0 ? (uint32_t)-v : (uint32_t)v;
    if (v < 0)
        *b++ = '-';
    do {
        t[n++] = (char)('0' + u % 10u);
        u /= 10u;
    } while (u);
    while (n)
        *b++ = t[--n];
    *b = 0;
}
