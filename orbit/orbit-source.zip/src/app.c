/* SPDX-License-Identifier: GPL-3.0-only */
/* The firmware's one loop: read the panel, play, draw. One FM sound. The screen is three fixed zones:
 *   top     the four values of KNOB 1..4, left to right, each in its knob's colour
 *   middle  the page's picture
 *   bottom  the page's name (left), the sound's number and name (right)
 * A page is a row of PAGES: its name, its button, its four values, its picture. A value is a row of VALUES:
 * its label and range; val_get / val_set say where it lives.
 *   HOME  TONE FEED ATTACK RELEASE     the sound as a whole
 *   EDIT  RATIO FINE LEVEL DETUNE      the operator SELECT picks
 *   ENV   ATTACK DECAY SUSTAIN RELEASE that operator's envelope
 *   LFO   RATE SHAPE PITCH LEVEL       the slow wave that moves the pitch (vibrato) and the level (tremolo)
 *   FX    three values of the effect SELECT picks (six in a chain); SEL switches it on and off
 *   ARP   MODE OCTAVES RATE GATE       the arpeggiator: the button turns it on, again off
 *   SEQ   PATTERN RATE GATE LENGTH     the sequencer: the button turns it on, again off; PLAY, REC
 *   GLO   TEMPO SWING GLIDE TRANSPOSE  the instrument, whatever the sound (GLIDE on: one note at a time)
 * On every page: PRESETS the sound, ALGORITHM the algorithm (its picture shown for a second where the page
 * has another), OCT- / OCT+ the keys' octave (both: back to the middle; shown for a second). SELECT picks which one a page is
 * about (the operator, the step); SEL switches that one off and on (ARP: HOLD, the keys collect notes; again,
 * LOOP, they go round while the keys play over them). ARP and SEQ go on under the other pages: held, off.
 * PLAY / STOP starts and stops whichever of the two is on (the arpeggiator keeps its notes). FX is lit while
 * any effect is on; held, it switches them all off. SEQ, stopped: REC held empties the pattern. SAVE held
 * while switching on: the factory's sounds again. SAVE held: the sound, with its effects, into a place of
 * place (a factory sound: your first empty one of 129..256; PRESETS picks any of the 256), the patterns and
 * GLO's settings with it.
 * At power-on the start-up screen for two seconds, or until the first touch. The battery: bottom right. */
#define Y_LABEL 8                         /* the values' labels (capitals' top) */
#define Y_VALUE 24
#define Y_GAUGE 46
#define Y_FOOT 222
#define PIC_CX 120                        /* the picture's centre */
#define PIC_CY 132

enum { PG_HOME, PG_EDIT, PG_ENV, PG_LFO, PG_FX, PG_ARP, PG_SEQ, PG_GLO, NPAGES };
enum { V_TONE, V_FEED, V_ATTACK, V_RELEASE,        /* the sound */
       V_RATIO, V_FINE, V_LEVEL, V_DETUNE,          /* the selected operator */
       V_OATK, V_ODEC, V_OSUS, V_OREL,              /* its envelope */
       V_LRATE, V_LSHAPE, V_LPITCH, V_LLEVEL,       /* the LFO */
       V_AMODE, V_AOCT, V_ARATE, V_AGATE,           /* the arpeggiator */
       V_SPAT, V_SRATE, V_SGATE, V_SLEN,            /* the sequencer */
       V_TEMPO, V_SWING, V_GLIDE, V_TRANS,          /* the instrument */
       V_FX1, V_FX2, V_FX3, NVALUES,                /* the selected effect's three (their names: FX_INFO) */
       V_NONE = 255 };                              /* a knob with nothing on this page */
typedef struct { const char *label; int16_t lo, hi; uint8_t sign; const char *const *names; } value_t;
static const char *const N_SHAPE[] = {"TRI", "SAW-", "SAW+", "SQR", "SIN", "S&H"};
static const value_t VALUES[NVALUES] = {
    {"TONE", -64, 63, 1}, {"FEED", 0, 7, 0}, {"ATTACK", -50, 50, 1}, {"RELEASE", -50, 50, 1},
    {"RATIO", 0, 31, 0}, {"FINE", 0, 99, 0}, {"LEVEL", 0, 99, 0}, {"DETUNE", -7, 7, 1},
    {"ATTACK", 0, 99, 0}, {"DECAY", 0, 99, 0}, {"SUSTAIN", 0, 99, 0}, {"RELEASE", 0, 99, 0},
    {"RATE", 0, 99, 0}, {"SHAPE", 0, 5, 0, N_SHAPE}, {"PITCH", 0, 99, 0}, {"LEVEL", 0, 99, 0},
    {"MODE", 0, AM_COUNT - 1, 0, N_AMODE}, {"OCT", 1, 4, 0}, {"RATE", 0, 5, 0, N_RATE}, {"GATE", 20, 100, 0},
    {"PATTERN", 1, SEQ_PATTERNS, 0}, {"RATE", 0, 5, 0, N_RATE}, {"GATE", 20, 100, 0}, {"LENGTH", 1, SEQ_STEPS, 0},
    {"TEMPO", 30, 300, 0}, {"SWING", 50, 75, 0}, {"GLIDE", 0, 99, 0}, {"TRANSP", -12, 12, 1},
    {"", 0, 100, 0}, {"", 0, 100, 0}, {"", 0, 100, 0},
};
static void draw_sound(void);
static void draw_env(void);
static void draw_lfo(void);
static void draw_glo(void);
static void draw_fx(void);
/* the effects, in the chain's order: the name, the short name under its point, its three values' names; a
 * first value that is a type has its three names */
static const char *const N_FTYPE[] = {"LOW", "BAND", "HIGH"}, *const N_RTYPE[] = {"ROOM", "HALL", "PLATE"};
static const struct { const char *name, *tag, *label[3]; const char *const *types; } FX_INFO[FX_N] = {
    {"DISTORTION", "DIST", {"GAIN", "TONE", "LEVEL"}, 0},
    {"FILTER", "FILT", {"TYPE", "CUTOFF", "RESO"}, N_FTYPE},
    {"PHASER", "PHAS", {"RATE", "DEPTH", "MIX"}, 0},
    {"CHORUS", "CHOR", {"RATE", "DEPTH", "MIX"}, 0},
    {"DELAY", "DLY", {"TIME", "REPEAT", "MIX"}, 0},
    {"REVERB", "REV", {"TYPE", "DECAY", "MIX"}, N_RTYPE},
};
static void draw_arp(void);
static void draw_seq(void);
typedef struct { const char *name; uint8_t button; uint8_t value[4]; void (*picture)(void); } page_t;
static const page_t PAGES[NPAGES] = {
    {"HOME", B_HOME, {V_TONE, V_FEED, V_ATTACK, V_RELEASE}, draw_sound},
    {"EDIT", B_EDIT, {V_RATIO, V_FINE, V_LEVEL, V_DETUNE}, draw_sound},
    {"ENV", B_ENV, {V_OATK, V_ODEC, V_OSUS, V_OREL}, draw_env},
    {"LFO", B_LFO, {V_LRATE, V_LSHAPE, V_LPITCH, V_LLEVEL}, draw_lfo},
    {"FX", B_FX, {V_FX1, V_FX2, V_FX3, V_NONE}, draw_fx},
    {"ARP", B_ARP, {V_AMODE, V_AOCT, V_ARATE, V_AGATE}, draw_arp},
    {"SEQ", B_SEQ, {V_SPAT, V_SRATE, V_SGATE, V_SLEN}, draw_seq},
    {"GLO", B_GLO, {V_TEMPO, V_SWING, V_GLIDE, V_TRANS}, draw_glo},
};

/* what is kept while the instrument is off: the instrument's settings, the patterns, and 256 places for
 * sounds: 1..128 start as the factory bank; 129..256 are yours, empty until a sound is put there. Any of the
 * 256 can be replaced (SAVE with PRESETS, or from a computer); a computer can also put a factory sound back.
 * The settings and the patterns come first, the sounds after them, so that saving a sound changes only the
 * piece it lies in. */
#define NSLOTS 256u
typedef struct {
    uint8_t patch[FP_SIZE];
    int8_t tone, attack, release;
    uint8_t fx_on;                        /* bit f: effect f is on */
    uint8_t fx_p[FX_N][3];
    uint8_t used;                         /* one of yours that holds a sound (the factory's: always) */
} sound_t;
#define STORE_MAGIC 0x4F524232u           /* "ORB2": another layout takes another number */
static struct {
    uint32_t magic;
    uint16_t tempo;
    uint8_t swing, glide;
    int8_t transpose;
    uint8_t arp_mode, arp_oct, arp_rate, arp_gate, seq_rate, seq_gate, voice;
    seq_pattern_t pat[SEQ_PATTERNS];
    sound_t sound[NSLOTS];
} store;
/* the layout before ("ORB1": 128 places, a saved sound took the factory's place), read once to carry it over */
#define STORE1_MAGIC 0x4F524231u
typedef struct {
    uint8_t patch[FP_SIZE];
    int8_t tone, attack, release;
    uint8_t fx_on;
    uint8_t fx_p[FX_N][3];
} sound1_t;
typedef struct {
    uint16_t tempo;
    uint8_t swing, glide;
    int8_t transpose;
    uint8_t arp_mode, arp_oct, arp_rate, arp_gate, seq_rate, seq_gate, voice;
} tail1_t;
typedef struct {
    uint32_t magic;
    sound1_t sound[STOCK_VOICES];
    seq_pattern_t pat[SEQ_PATTERNS];
    tail1_t tail;
} store1_t;

static struct {
    uint8_t base[FP_SIZE];                /* the sound as loaded and edited (the macros not in it) */
    uint8_t voice;                        /* the place the sound is from: 0..127 the factory's, 128..255 yours */
    uint8_t page;
    uint8_t op;                           /* the operator SELECT picked, 0..5 = OP 1..6 */
    int8_t octave;
    int8_t tone, attack, release;         /* HOME's macros */
    uint8_t glide;
    int8_t transpose;                     /* semitones */
    uint8_t op_off;                       /* bit i: OP i + 1 is switched off (SEL) */
    uint8_t fx_sel;                       /* FX: the effect SELECT picked */
    uint8_t cursor;                       /* SEQ: the step SELECT picked */
    uint8_t rec, rec_open;                /* SEQ: recording; a step is taking the keys held now */
    uint32_t alg_until;                   /* ALGORITHM turned: the sound's picture until then (ms) */
    uint32_t oct_until;                   /* OCT- / OCT+ pressed: the octave in the picture's place until then */
    uint8_t hot;                          /* the knob (0..3) turned last; until hot_until (ms) it counts as being */
    uint32_t hot_until;                   /* turned: its value and its part of the picture stand out */
    uint8_t still;                        /* (the tests) what moves by itself stands still: the moon, the drift */
    uint32_t touched;                     /* when the panel was last touched (ms) */
    int32_t drift;                        /* HOME, untouched for a while: how far round the operators have drifted (a phase) */
    uint8_t battery, usb_power;           /* 0 .. 3; a computer powers it */
    uint32_t low_until;                   /* the battery just ran low: said in the picture's place until then (ms) */
    uint32_t boot_until;                  /* the start-up screen until then (ms); a key or a button ends it */
    uint32_t mode_t0;                     /* ARP or SEQ: when it went down (0: up, 1: done) */
    uint32_t fx_t0;                       /* FX: the same */
    uint32_t boot_ms;                     /* when it was switched on */
    uint8_t reset_watch;                  /* SAVE has been down since then: held 1.5 s, the factory's sounds come back */
    uint32_t note_until;                  /* a word in the footer until then (ms): */
    const char *note;                     /* "cleared", "factory reset" */
    uint32_t rec_t0;                      /* REC: when it went down (0: up, 1: done) */
    uint8_t save_full;                    /* SAVE on a factory sound with every place of yours taken: nothing is saved
                                           * until PRESETS has chosen which sound gives way */
    uint8_t save_armed, save_dst;         /* SAVE held long enough: the place it will go to */
    uint8_t bank_hi, bank_lo;             /* bank select from MIDI, CC 0 and CC 32: either at 1 is the places 129..256 */
    uint32_t imp_until;                   /* sounds just came from a computer: said in the picture's place until then */
    uint8_t imp_msg, imp_n, imp_lo, imp_hi; /* 0 loaded (how many, the first and last place), 1 failed, 2 no room, 3 heard */
    int8_t env_dr[6], env_dl[6];          /* each operator's envelope as the sound came: how its second decay differs from
                                           * its first (rate), and the level between them from the held one (app_env_keep) */
    uint32_t pre_t0;                      /* PRESETS just chose another sound: its picture arrives from then (ms; 0: none) */
    uint32_t save_t0, saved_until;        /* SAVE: when it went down (0: up, 1: done); "SAVED" until then */
    uint8_t key_note[NKEYS];              /* the note each held key started */
    uint8_t key_live[NKEYS];              /* that key plays its note itself (not the arpeggiator's) */
    uint32_t keys;
    uint32_t buttons;
    uint32_t frame;
} app;

static int32_t clampi(int32_t v, int32_t lo, int32_t hi) { return v < lo ? lo : v > hi ? hi : v; }

/* operator i (0: OP 1) of a patch: its 21 bytes (the patch holds the sixth first) */
static uint8_t *op_bytes(uint8_t *p, uint32_t i) { return p + (5u - i) * FP_OP; }
static uint32_t carriers(uint32_t alg)    /* bit i: OP i + 1 is a carrier */
{
    uint32_t c = fm6_carriers(alg), r = 0, i;
    for (i = 0; i < 6u; i++)
        r |= ((c >> (5u - i)) & 1u) << i;
    return r;
}
/* m[i]: the operators (bit j: OP j + 1) that modulate OP i + 1 in algorithm alg; returns the operator
 * with the feedback loop (0..5) */
static uint32_t routes(uint32_t alg, uint8_t *m)
{
    const uint8_t *f = FM6_ALG[alg & 31u];
    uint8_t bus[4] = {0, 0, 0, 0};
    uint32_t k, fb = 0;
    for (k = 0; k < 6u; k++) {
        uint32_t op = 5u - k, in = (f[k] >> 4) & 3u, o = f[k] & 3u;
        m[op] = in ? bus[in] : 0u;
        bus[o] = (uint8_t)(((f[k] & FM6_OADD) ? bus[o] : 0u) | 1u << op);
        if ((f[k] & 0xC0u) == 0xC0u)      /* (the operator the core feeds back: fm6_core_render tests the same two bits) */
            fb = op;
    }
    return fb;
}

/* a value: where it lives. The envelope's times are shown as times (0 at once .. 99 slowest): the patch
 * holds rates, the other way round. DECAY is rates 2 and 3, SUSTAIN levels 2 and 3: one slope, one level */
static int32_t val_get(uint32_t id)
{
    const uint8_t *o = op_bytes(app.base, app.op);
    switch (id) {
    case V_TONE: return app.tone;
    case V_FEED: return app.base[FP_FB] & 7;
    case V_ATTACK: return app.attack;
    case V_RELEASE: return app.release;
    case V_RATIO: return o[FP_FC] & 31;
    case V_FINE: return o[FP_FF] % 100;
    case V_LEVEL: return o[FP_OL] % 100;
    case V_DETUNE: return (int32_t)(o[FP_DET] & 15) - 7;
    case V_OATK: return 99 - o[FP_R1] % 100;
    case V_ODEC: return 99 - o[FP_R1 + 1] % 100;
    case V_OSUS: return o[FP_L1 + 2] % 100;
    case V_OREL: return 99 - o[FP_R1 + 3] % 100;
    case V_LRATE: return app.base[FP_LFS] % 100;
    case V_LSHAPE: return app.base[FP_LFW] % 6;
    case V_LPITCH: return app.base[FP_LPMD] % 100;
    case V_LLEVEL: return app.base[FP_LAMD] % 100;
    case V_AMODE: return play.arp_mode;
    case V_AOCT: return play.arp_oct;
    case V_ARATE: return play.arp_rate;
    case V_AGATE: return play.arp_gate;
    case V_SPAT: return play.pattern + 1;
    case V_SRATE: return play.seq_rate;
    case V_SGATE: return play.seq_gate;
    case V_SLEN: return play.pat[play.pattern].len;
    case V_TEMPO: return play.tempo;
    case V_SWING: return play.swing;
    case V_GLIDE: return app.glide;
    case V_TRANS: return app.transpose;
    default: return fx.p[app.fx_sel][id - V_FX1];
    }
}
static void val_set(uint32_t id, int32_t v)
{
    uint8_t *o = op_bytes(app.base, app.op);
    v = clampi(v, VALUES[id].lo, id == V_FX1 && FX_INFO[app.fx_sel].types ? 2 : id == V_FX2 && app.fx_sel == FX_FILTER ? 99 : VALUES[id].hi);
    switch (id) {
    case V_TONE: app.tone = (int8_t)v; break;
    case V_FEED: app.base[FP_FB] = (uint8_t)v; break;
    case V_ATTACK: app.attack = (int8_t)v; break;
    case V_RELEASE: app.release = (int8_t)v; break;
    case V_RATIO: o[FP_FC] = (uint8_t)v; break;
    case V_FINE: o[FP_FF] = (uint8_t)v; break;
    case V_LEVEL: o[FP_OL] = (uint8_t)v; break;
    case V_DETUNE: o[FP_DET] = (uint8_t)(v + 7); break;
    case V_OATK: o[FP_R1] = (uint8_t)(99 - v); break;
    /* a DX7 envelope decays in two steps, by way of a level between (that step makes the echoes and swells some
     * sounds have). DECAY and SUSTAIN move both steps together and keep what the sound has between them */
    case V_ODEC:
        o[FP_R1 + 1] = (uint8_t)(99 - v);
        o[FP_R1 + 2] = (uint8_t)clampi(99 - v + app.env_dr[app.op], 0, 99);
        break;
    case V_OSUS:
        o[FP_L1 + 2] = (uint8_t)v;
        o[FP_L1 + 1] = (uint8_t)clampi(v + app.env_dl[app.op], 0, 99);
        break;
    case V_OREL: o[FP_R1 + 3] = (uint8_t)(99 - v); break;
    case V_LRATE: app.base[FP_LFS] = (uint8_t)v; break;
    case V_LSHAPE: app.base[FP_LFW] = (uint8_t)v; break;
    case V_LPITCH:                        /* a depth only sounds through the patch's sensitivities: if the sound */
        app.base[FP_LPMD] = (uint8_t)v;   /* has none set, give it some, so the knob always does something */
        if (v && !(app.base[FP_LPMS] & 7u))
            app.base[FP_LPMS] = 3;
        break;
    case V_LLEVEL: {
        uint32_t i, any = 0, car = carriers(app.base[FP_ALG]);
        app.base[FP_LAMD] = (uint8_t)v;
        for (i = 0; i < 6u; i++)
            any |= op_bytes(app.base, i)[FP_AMS] & 3u;
        for (i = 0; i < 6u && v && !any; i++)   /* (none: the carriers, so it is a tremolo) */
            if ((car >> i) & 1u)
                op_bytes(app.base, i)[FP_AMS] = 2;
        break;
    }
    case V_AMODE: play.arp_mode = (uint8_t)v; break;
    case V_AOCT: play.arp_oct = (uint8_t)v; break;
    case V_ARATE: play.arp_rate = (uint8_t)v; break;
    case V_AGATE: play.arp_gate = (uint8_t)v; break;
    case V_SPAT: play.pattern = (uint8_t)(v - 1); app.cursor = 0; break;
    case V_SRATE: play.seq_rate = (uint8_t)v; break;
    case V_SGATE: play.seq_gate = (uint8_t)v; break;
    case V_SLEN:
        play.pat[play.pattern].len = (uint8_t)v;
        if (app.cursor >= v)
            app.cursor = (uint8_t)(v - 1);
        break;
    case V_TEMPO: play.tempo = (uint16_t)v; break;
    case V_SWING: play.swing = (uint8_t)v; break;
    case V_GLIDE: app.glide = (uint8_t)v; break;
    case V_TRANS: app.transpose = (int8_t)v; break;
    default: fx.p[app.fx_sel][id - V_FX1] = (uint8_t)v; break;
    }
}
/* as shown (b holds 12): RATIO 0 is a half, a fixed-frequency operator shows its decade in Hz */
static void val_text(uint32_t id, char *b)
{
    int32_t v = val_get(id);
    if (id == V_RATIO && op_bytes(app.base, app.op)[FP_MODE]) {
        static const char *const HZ[4] = {"1Hz", "10Hz", "100Hz", "1kHz"};
        strcpy(b, HZ[v & 3]);
    } else if (id == V_RATIO && !v) {
        strcpy(b, "0.5");
    } else if (id == V_FX1 && FX_INFO[app.fx_sel].types) {
        strcpy(b, FX_INFO[app.fx_sel].types[v > 2 ? 2 : v]);
    } else if (id == V_FX2 && app.fx_sel == FX_FILTER) {      /* the cutoff in Hz: "850", "2.4k", "12k" */
        uint32_t hz = fx_cut_hz((uint32_t)v);
        if (hz < 1000u) {
            g_int(b, (int32_t)hz);
        } else {
            g_int(b, (int32_t)(hz / 1000u));
            if (hz < 10000u) {
                strcat(b, ".");
                g_int(b + strlen(b), (int32_t)(hz % 1000u / 100u));
            }
            strcat(b, "k");
        }
    } else if (VALUES[id].names) {
        strcpy(b, VALUES[id].names[v - VALUES[id].lo]);
    } else {
        b[0] = VALUES[id].sign && v > 0 ? '+' : 0;
        g_int(b + (VALUES[id].sign && v > 0), v);
    }
}

/* the sound that plays: the edited patch, ATTACK and RELEASE on its carriers, TONE on its modulators */
static void app_apply(void)
{
    uint8_t p[FP_SIZE];
    uint32_t i, car;
    memcpy(p, app.base, FP_SIZE);
    car = carriers(p[FP_ALG]);
    for (i = 0; i < 6u; i++) {
        uint8_t *o = op_bytes(p, i);
        if ((car >> i) & 1u) {
            o[FP_R1] = (uint8_t)clampi(o[FP_R1] - app.attack, 0, 99);
            o[FP_R1 + 3] = (uint8_t)clampi(o[FP_R1 + 3] - app.release, 0, 99);
        }
        if ((app.op_off >> i) & 1u) {     /* switched off: no level at any stage (level 0 alone still ticks) */
            o[FP_OL] = 0;
            memset(o + FP_L1, 0, 4);
        }
    }
    syn_set_patch(p, app.tone * 24);
    syn.glide = app.glide;
}

/* a sound has just become the one being played: remember the shape of each operator's envelope between its
 * two decay steps, for DECAY and SUSTAIN to keep */
static void app_env_keep(void)
{
    uint32_t k;
    for (k = 0; k < 6u; k++) {
        const uint8_t *o = op_bytes(app.base, k);
        app.env_dr[k] = (int8_t)((int32_t)(o[FP_R1 + 2] % 100) - (int32_t)(o[FP_R1 + 1] % 100));
        app.env_dl[k] = (int8_t)((int32_t)(o[FP_L1 + 1] % 100) - (int32_t)(o[FP_L1 + 2] % 100));
    }
}

static void app_load(uint32_t voice)
{
    const sound_t *sd;
    uint32_t f;
    app.voice = (uint8_t)(voice % NSLOTS);
    if (app.voice >= STOCK_VOICES && !store.sound[app.voice].used)
        app.voice = 0;                    /* (an empty place: nothing to load) */
    sd = &store.sound[app.voice];
    memcpy(app.base, sd->patch, FP_SIZE);
    app.tone = sd->tone;
    app.attack = sd->attack;
    app.release = sd->release;
    for (f = 0; f < FX_N; f++)
        fx.on[f] = (sd->fx_on >> f) & 1u;
    memcpy(fx.p, sd->fx_p, sizeof fx.p);
    app.op_off = 0;
    app_env_keep();
    syn_cut();                            /* (the notes of the sound before end with it) */
    app_apply();
}

#define SPLASH_MS 2200u

/* the instrument's settings and the patterns into the store (not yet written) */
static void store_settings(void)
{
    memcpy(store.pat, play.pat, sizeof store.pat);
    store.tempo = play.tempo;
    store.swing = play.swing;
    store.glide = app.glide;
    store.transpose = app.transpose;
    store.arp_mode = play.arp_mode;
    store.arp_oct = play.arp_oct;
    store.arp_rate = play.arp_rate;
    store.arp_gate = play.arp_gate;
    store.seq_rate = play.seq_rate;
    store.seq_gate = play.seq_gate;
    store.voice = app.voice;
    store.magic = STORE_MAGIC;
}

/* SAVE: the sound, with its effects, into place dst, and that is where we are from now on; the
 * settings and the patterns with it. Only the pieces of the store those lie in are written */
static void app_save(uint32_t dst)
{
    sound_t *sd;
    uint32_t f;
    if (dst >= NSLOTS)
        return;
    sd = &store.sound[dst];
    if (dst != app.voice) {               /* a copy in another place: "alt" after its name (ten letters: the name gives way) */
        uint8_t *nm = app.base + FP_NAME;
        uint32_t k = 10;
        while (k && nm[k - 1] == ' ')
            k--;
        if (!(k >= 4u && nm[k - 4] == ' ' && nm[k - 3] == 'A' && nm[k - 2] == 'L' && nm[k - 1] == 'T')) {
            if (k > 6u)
                k = 6;
            while (k && nm[k - 1] == ' ')
                k--;
            memcpy(nm + k, " ALT      ", 10u - k);
        }
    }
    memcpy(sd->patch, app.base, FP_SIZE);
    sd->tone = app.tone;
    sd->attack = app.attack;
    sd->release = app.release;
    sd->fx_on = 0;
    for (f = 0; f < FX_N; f++)
        sd->fx_on |= (uint8_t)((fx.on[f] & 1u) << f);
    memcpy(sd->fx_p, fx.p, sizeof fx.p);
    sd->used = 1;
    app.voice = (uint8_t)dst;
    store_settings();
    if (!hal_store_write(&store, sizeof store, 0, (uint32_t)((uint8_t *)store.sound - (uint8_t *)&store)) &&
        !hal_store_write(&store, sizeof store, (uint32_t)((uint8_t *)sd - (uint8_t *)&store), sizeof *sd))
        app.saved_until = hal_ms() + 1000u;
}

/* where SAVE would put the sound if PRESETS is left alone: where it is, if that is one of yours; else the
 * first of yours that is empty (none empty: the first) */
static uint32_t save_default(void)
{
    uint32_t i;
    if (app.voice >= STOCK_VOICES)
        return app.voice;
    for (i = STOCK_VOICES; i < NSLOTS; i++)
        if (!store.sound[i].used)
            return i;
    return app.voice;
}

/* the 128 factory sounds, every effect off at its usual settings; none of yours, no patterns */
static void store_factory(void)
{
    uint32_t i;
    memset(&store, 0, sizeof store);
    fx_init();
    for (i = 0; i < STOCK_VOICES; i++) {
        syn_unpack(store.sound[i].patch, STOCK_VMEM[i]);
        memcpy(store.sound[i].fx_p, fx.p, sizeof fx.p);
        store.sound[i].used = 1;
    }
}

/* what the layout before left: every sound that is not the factory's any more goes to a place of yours, in
 * the order found; the patterns and the settings as they are. Returns 0 when carried over (and written) */
#define OLD_AT(field) ((uint32_t)((const uint8_t *)&((const store1_t *)0)->field - (const uint8_t *)0))
static int store_migrate(void)
{
    sound1_t old;
    tail1_t tail;
    uint32_t i, next = STOCK_VOICES, from = 0;
    if (hal_store_read(&tail, OLD_AT(tail), sizeof tail))
        return -1;
    store_factory();
    for (i = 0; i < STOCK_VOICES && next < NSLOTS; i++) {
        if (hal_store_read(&old, OLD_AT(sound) + i * (uint32_t)sizeof old, sizeof old))
            return -1;
        if (!memcmp(&old, &store.sound[i], sizeof old))
            continue;                     /* the factory's still */
        memcpy(&store.sound[next], &old, sizeof old);
        store.sound[next].used = 1;
        if (i == tail.voice)
            from = next;                  /* (where it was switched off) */
        next++;
    }
    if (hal_store_read(store.pat, OLD_AT(pat), sizeof store.pat))
        return -1;
    store.tempo = tail.tempo;
    store.swing = tail.swing;
    store.glide = tail.glide;
    store.transpose = tail.transpose;
    store.arp_mode = tail.arp_mode;
    store.arp_oct = tail.arp_oct;
    store.arp_rate = tail.arp_rate;
    store.arp_gate = tail.arp_gate;
    store.seq_rate = tail.seq_rate;
    store.seq_gate = tail.seq_gate;
    store.voice = (uint8_t)(from ? from : tail.voice % STOCK_VOICES);
    store.magic = STORE_MAGIC;
    return hal_store_write(&store, sizeof store, 0, sizeof store);
}

/* A channel message over USB-MIDI, any channel: notes with their velocity; program change picks a sound, place
 * bank * 128 + program + 1, the bank from bank select (CC 0 and CC 32 added: 0 the places 1..128, 1 the places
 * 129..256, kept until the next one). An empty place, a bank there is none of, SAVE held: the sound stays.
 * PRESETS sends the same three messages out, channel 1; a program change that came in is not sent back. */
static void app_midi(uint32_t status, uint32_t d1, uint32_t d2)
{
    uint32_t st = status & 0xF0u, v;
    d1 &= 127u;
    d2 &= 127u;
    if (st == 0x90u)
        syn_note_in(d1, d2);
    else if (st == 0x80u)
        syn_note_in(d1, 0);
    else if (st == 0xB0u && d1 == 0u)
        app.bank_hi = (uint8_t)d2;
    else if (st == 0xB0u && d1 == 32u)
        app.bank_lo = (uint8_t)d2;
    else if (st == 0xC0u) {
        v = ((uint32_t)app.bank_hi + app.bank_lo) * 128u + d1;   /* (a DAW sends both, one of them 0) */
        if (v >= NSLOTS || app.save_armed || v == app.voice || (v >= STOCK_VOICES && !store.sound[v].used))
            return;
        if (!app.still) {                 /* it arrives as with PRESETS, from the side its number lies on */
            app.pre_t0 = hal_ms() | 1u;
            app.drift = v > app.voice ? -0x2AAAAAAA : 0x2AAAAAAA;
        }
        app_load(v);
    }
}

/* Sounds from a computer (tools/orbit_load.py) come as SysEx under the id anybody may use. Between F0 and F7:
 *   7D 'o' 'r' 'b' cmd ...
 *   00                  a load begins (what was waiting is dropped)
 *   01 v[128] cs        hear it: the voice (a DX7's packed 128 bytes) is the sound being played; SAVE keeps it
 *   02 ih il ph pl v cs wait for the end: voice number ih << 7 | il of this load (0, 1, 2 .. in order; one that
 *                       is there already is not taken twice), for place ph << 7 | pl (0..255), or 7F 7F:
 *                       your next empty place
 *   03 n                the end: n voices were sent (128: 0). All there and room for them: into their places,
 *                       stored, and the first of them plays. Else nothing changes and the screen says so
 *   07 ..as 02.. x[22] xs  the same with the sound's own settings after the voice: TONE, ATTACK, RELEASE (each
 *                       + 64), the effects that are on (bit f: effect f), every effect's three values; xs: their
 *                       check, as cs
 *   05 ph pl            that place as it was at first: one of 129..256 empty, one of 1..128 the factory's sound
 *   06                  nothing: only the answer
 *   09 i                what is pattern i (0..15), or with i = 7F the instrument's settings? Answered with
 *                         7D 'o' 'r' 'b' 7D i d[..] cs    a pattern: its 16 steps (notes n, silenced, four notes)
 *                         and its length, 97 bytes; the settings: TEMPO (two sevens), SWING, GLIDE, TRANSP + 64,
 *                         the arpeggiator's MODE OCT RATE GATE, the sequencer's RATE GATE, 11 bytes
 *   0A i d[..] cs       that pattern, or those settings, from now on (what is out of range is brought in)
 *   0B                  the patterns and settings as they are now: stored
 *   08 ph pl            what is in that place? Answered with the sound itself, for a backup:
 *                         7D 'o' 'r' 'b' 7E ph pl used [v[128] cs x[22] xs]   (the part in brackets: a place in use;
 *                         v and x as 07 takes them, so what comes back can be sent again as it is)
 * cs: with the voice's bytes it sums to 0 in seven bits, as a DX7's does.
 * Every message is answered, so the computer can wait for each and send it again if nothing came:
 *   7D 'o' 'r' 'b' 7F cmd ok nh nl ah al bh bl
 * ok: 1 done, 0 not (2 at the end: no room). n: voices waiting (after 03: voices loaded; after 06: places of
 * yours in use). a, b: after 03 the first and the last place they went to; after 06, a: the place playing. */
#define IMP_MAX 128u
#define IMP_NEXT 0xFFFFu
static struct {
    uint16_t n;                           /* voices waiting */
    uint16_t dst[IMP_MAX];
    uint8_t v[IMP_MAX][128];
    uint8_t has_x[IMP_MAX], x[IMP_MAX][22];   /* (07: the sound's settings) */
} imp;

static void imp_say(uint32_t msg)
{
    app.imp_msg = (uint8_t)msg;
    app.imp_until = hal_ms() + 3000u;
}
static void imp_answer(uint32_t cmd, uint32_t ok, uint32_t n, uint32_t a, uint32_t b)
{
    uint8_t r[13];
    r[0] = 0x7D; r[1] = 'o'; r[2] = 'r'; r[3] = 'b'; r[4] = 0x7F;
    r[5] = (uint8_t)cmd; r[6] = (uint8_t)ok;
    r[7] = (uint8_t)(n >> 7); r[8] = (uint8_t)(n & 127u);
    r[9] = (uint8_t)(a >> 7); r[10] = (uint8_t)(a & 127u);
    r[11] = (uint8_t)(b >> 7); r[12] = (uint8_t)(b & 127u);
    hal_sysex_out(r, sizeof r);
}
static int imp_voice_ok(const uint8_t *v)   /* 128 bytes and their check */
{
    uint32_t i, s = 0;
    for (i = 0; i < 129u; i++)
        s += v[i];
    return !(s & 127u);
}
static int imp_x_ok(const uint8_t *x)       /* 22 bytes and their check */
{
    uint32_t i, s = 0;
    for (i = 0; i < 23u; i++)
        s += x[i];
    return !(s & 127u);
}
static uint32_t imp_end(uint32_t n)       /* 1 loaded, 0 failed, 2 no room */
{
    uint32_t i, k, room = 0, need = 0, first = NSLOTS;
    if (!n || imp.n != n) {
        imp.n = 0;
        imp_say(1);                       /* something was lost on the way: nothing changes */
        return 0;
    }
    for (i = STOCK_VOICES; i < NSLOTS; i++)
        room += !store.sound[i].used;
    for (i = 0; i < n; i++)
        need += imp.dst[i] == IMP_NEXT;
    if (need > room) {
        imp.n = 0;
        imp_say(2);
        return 2;
    }
    app.imp_lo = 255;
    app.imp_hi = 0;
    for (i = 0; i < n; i++) {
        sound_t *sd;
        k = imp.dst[i];
        if (k == IMP_NEXT)
            for (k = STOCK_VOICES; store.sound[k].used; k++)
                ;
        sd = &store.sound[k];
        memset(sd, 0, sizeof *sd);
        syn_unpack(sd->patch, imp.v[i]);
        syn_tidy(sd->patch);
        memcpy(sd->fx_p, FX_USUAL, sizeof sd->fx_p);
        if (imp.has_x[i]) {
            const uint8_t *x = imp.x[i];
            uint32_t f, j;
            sd->tone = (int8_t)clampi((int32_t)x[0] - 64, VALUES[V_TONE].lo, VALUES[V_TONE].hi);
            sd->attack = (int8_t)clampi((int32_t)x[1] - 64, VALUES[V_ATTACK].lo, VALUES[V_ATTACK].hi);
            sd->release = (int8_t)clampi((int32_t)x[2] - 64, VALUES[V_RELEASE].lo, VALUES[V_RELEASE].hi);
            sd->fx_on = x[3] & ((1u << FX_N) - 1u);
            for (f = 0; f < FX_N; f++)
                for (j = 0; j < 3u; j++)
                    sd->fx_p[f][j] = (uint8_t)clampi(x[4u + f * 3u + j], 0,
                                                     !j && (f == FX_FILTER || f == FX_REVERB) ? 2 : 100);
        }
        sd->used = 1;
        if (first == NSLOTS)
            first = k;
        if (k < app.imp_lo)
            app.imp_lo = (uint8_t)k;
        if (k > app.imp_hi)
            app.imp_hi = (uint8_t)k;
    }
    imp.n = 0;
    app.imp_n = (uint8_t)n;
    app_load(first);
    store.voice = app.voice;
    if (hal_store_write(&store, sizeof store, 0, sizeof store)) {
        imp_say(1);
        return 0;
    }
    imp_say(0);
    return 1;
}
static void app_sysex(const uint8_t *p, uint32_t n)
{
    uint32_t k, i, ok = 0;
    if (n < 5u || p[0] != 0x7Du || p[1] != 'o' || p[2] != 'r' || p[3] != 'b')
        return;
    switch (p[4]) {
    case 0:
        imp.n = 0;
        imp_answer(0, 1, 0, 0, 0);
        break;
    case 1:
        if (n == 5u + 129u && imp_voice_ok(p + 5)) {
            syn_unpack(app.base, p + 5);
            syn_tidy(app.base);
            app.tone = app.attack = app.release = 0;
            app.op_off = 0;
            app_env_keep();
            syn_cut();
            app_apply();
            imp_say(3);
            ok = 1;
        }
        imp_answer(1, ok, imp.n, 0, 0);
        break;
    case 2:
    case 7:
        if ((p[4] == 2u && n == 9u + 129u && imp_voice_ok(p + 9)) ||
            (p[4] == 7u && n == 9u + 129u + 23u && imp_voice_ok(p + 9) && imp_x_ok(p + 9 + 129))) {
            i = (uint32_t)p[5] << 7 | p[6];
            k = (uint32_t)p[7] << 7 | p[8];
            if (k == 0x3FFFu)
                k = IMP_NEXT;
            if (i < imp.n)
                ok = 1;                   /* (sent again: it is there) */
            else if (i == imp.n && imp.n < IMP_MAX && (k == IMP_NEXT || k < NSLOTS)) {
                imp.dst[imp.n] = (uint16_t)k;
                memcpy(imp.v[imp.n], p + 9, 128);
                imp.has_x[imp.n] = p[4] == 7u;
                if (p[4] == 7u)
                    memcpy(imp.x[imp.n], p + 9 + 129, 22);
                imp.n++;
                ok = 1;
            }
        }
        imp_answer(p[4], ok, imp.n, 0, 0);
        break;
    case 3:
        if (n == 6u) {
            ok = imp_end(p[5] ? p[5] : 128u);
            imp_answer(3, ok, ok == 1u ? app.imp_n ? app.imp_n : 128u : 0, app.imp_lo, app.imp_hi);
        }
        break;
    case 5:
        if (n == 7u) {
            k = (uint32_t)p[5] << 7 | p[6];
            if (k < NSLOTS) {
                ok = 1;
                if (k < STOCK_VOICES) {   /* one of the first 128: the factory's sound again */
                    sound_t *sd = &store.sound[k];
                    memset(sd, 0, sizeof *sd);
                    syn_unpack(sd->patch, STOCK_VMEM[k]);
                    memcpy(sd->fx_p, FX_USUAL, sizeof sd->fx_p);
                    sd->used = 1;
                    if (app.voice == k)
                        app_load(k);
                    ok = !hal_store_write(&store, sizeof store, (uint32_t)((uint8_t *)sd - (uint8_t *)&store), sizeof *sd);
                } else if (store.sound[k].used) {
                    store.sound[k].used = 0;
                    if (app.voice == k)
                        app_load(0);
                    ok = !hal_store_write(&store, sizeof store, (uint32_t)((uint8_t *)&store.sound[k] - (uint8_t *)&store), sizeof store.sound[k]);
                }
            }
        }
        imp_answer(5, ok, imp.n, 0, 0);
        break;
    case 8:
        if (n == 7u && ((uint32_t)p[5] << 7 | p[6]) < NSLOTS) {
            static uint8_t r[8 + 129 + 23];
            const sound_t *sd = &store.sound[(uint32_t)p[5] << 7 | p[6]];
            uint32_t f, j, s = 0, len = 8;
            r[0] = 0x7D; r[1] = 'o'; r[2] = 'r'; r[3] = 'b'; r[4] = 0x7E;
            r[5] = p[5]; r[6] = p[6];
            r[7] = sd->used;
            if (sd->used) {
                uint8_t *v = r + 8, *x = r + 8 + 129;
                syn_pack(v, sd->patch);
                for (i = 0; i < 128u; i++)
                    s += v[i];
                v[128] = (uint8_t)((0u - s) & 127u);
                x[0] = (uint8_t)(sd->tone + 64);
                x[1] = (uint8_t)(sd->attack + 64);
                x[2] = (uint8_t)(sd->release + 64);
                x[3] = sd->fx_on & ((1u << FX_N) - 1u);
                for (f = 0; f < FX_N; f++)
                    for (j = 0; j < 3u; j++)
                        x[4u + f * 3u + j] = sd->fx_p[f][j] & 127u;
                for (i = 0, s = 0; i < 22u; i++)
                    s += x[i];
                x[22] = (uint8_t)((0u - s) & 127u);
                len = sizeof r;
            }
            hal_sysex_out(r, len);
        }
        break;
    case 9:
        if (n == 6u && (p[5] < SEQ_PATTERNS || p[5] == 0x7Fu)) {
            static uint8_t r[6 + sizeof(seq_pattern_t) + 1];
            uint32_t len, s = 0;
            r[0] = 0x7D; r[1] = 'o'; r[2] = 'r'; r[3] = 'b'; r[4] = 0x7D;
            r[5] = p[5];
            if (p[5] == 0x7Fu) {
                uint8_t *d = r + 6;
                d[0] = (uint8_t)(play.tempo >> 7); d[1] = (uint8_t)(play.tempo & 127u);
                d[2] = play.swing; d[3] = app.glide; d[4] = (uint8_t)(app.transpose + 64);
                d[5] = play.arp_mode; d[6] = play.arp_oct; d[7] = play.arp_rate; d[8] = play.arp_gate;
                d[9] = play.seq_rate; d[10] = play.seq_gate;
                len = 11;
            } else {
                memcpy(r + 6, &play.pat[p[5]], sizeof(seq_pattern_t));
                len = sizeof(seq_pattern_t);
            }
            for (i = 0; i < len; i++) {
                r[6 + i] &= 127u;
                s += r[6 + i];
            }
            r[6 + len] = (uint8_t)((0u - s) & 127u);
            hal_sysex_out(r, 7u + len);
        }
        break;
    case 0x0A:
        if (n >= 7u && (p[5] < SEQ_PATTERNS || p[5] == 0x7Fu) &&
            n == 7u + (p[5] == 0x7Fu ? 11u : (uint32_t)sizeof(seq_pattern_t))) {
            const uint8_t *d = p + 6;
            uint32_t len = n - 7u, s = 0;
            for (i = 0; i <= len; i++)
                s += d[i];
            if (!(s & 127u)) {
                if (p[5] == 0x7Fu) {
                    play.tempo = (uint16_t)clampi((int32_t)d[0] << 7 | d[1], 30, 300);
                    play.swing = (uint8_t)clampi(d[2], 50, 75);
                    app.glide = (uint8_t)clampi(d[3], 0, 99);
                    app.transpose = (int8_t)clampi((int32_t)d[4] - 64, -12, 12);
                    play.arp_mode = d[5] % AM_COUNT;
                    play.arp_oct = (uint8_t)clampi(d[6], 1, 4);
                    play.arp_rate = d[7] % 6u;
                    play.arp_gate = (uint8_t)clampi(d[8], 20, 100);
                    play.seq_rate = d[9] % 6u;
                    play.seq_gate = (uint8_t)clampi(d[10], 20, 100);
                    app_apply();
                } else {
                    seq_pattern_t pt;
                    uint32_t lk;
                    memcpy(&pt, d, sizeof pt);
                    for (i = 0; i < SEQ_STEPS; i++) {
                        pt.step[i].n = (uint8_t)clampi(pt.step[i].n, 0, 4);
                        pt.step[i].off &= 1u;
                    }
                    pt.len = (uint8_t)clampi(pt.len, 1, SEQ_STEPS);
                    lk = hal_lock();
                    play.pat[p[5]] = pt;
                    hal_unlock(lk);
                    if (app.cursor >= pt.len && p[5] == play.pattern)
                        app.cursor = 0;
                }
                ok = 1;
            }
        }
        imp_answer(0x0A, ok, imp.n, 0, 0);
        break;
    case 0x0B:
        store_settings();
        ok = !hal_store_write(&store, sizeof store, 0, (uint32_t)((uint8_t *)store.sound - (uint8_t *)&store));
        imp_answer(0x0B, ok, imp.n, 0, 0);
        break;
    case 6:
        for (i = STOCK_VOICES, k = 0; i < NSLOTS; i++)
            k += store.sound[i].used;
        imp_answer(6, 1, k, app.voice, 0);
        break;
    }
}

static void app_init(void)
{
    uint32_t i;
    memset(&app, 0, sizeof app);
    memset(&syn, 0, sizeof syn);
    syn.master = 700;
    play_init();
    fx_init();
    if (hal_store_read(&store.magic, 0, sizeof store.magic))
        store.magic = 0;
    if (store.magic == STORE1_MAGIC && store_migrate())
        store.magic = 0;                  /* (not carried over: the factory's, and the old store stays as it is) */
    if (store.magic != STORE_MAGIC || hal_store_read(&store, 0, sizeof store) || store.magic != STORE_MAGIC) {
        store_factory();                  /* nothing kept: the factory's */
    } else {
        memcpy(play.pat, store.pat, sizeof play.pat);
        for (i = 0; i < SEQ_PATTERNS; i++)
            play.pat[i].len = (uint8_t)clampi(play.pat[i].len, 1, SEQ_STEPS);
        play.tempo = (uint16_t)clampi(store.tempo, 30, 300);
        play.swing = (uint8_t)clampi(store.swing, 50, 75);
        app.glide = (uint8_t)clampi(store.glide, 0, 99);
        app.transpose = (int8_t)clampi(store.transpose, -12, 12);
        play.arp_mode = store.arp_mode % AM_COUNT;
        play.arp_oct = (uint8_t)clampi(store.arp_oct, 1, 4);
        play.arp_rate = store.arp_rate % 6u;
        play.arp_gate = (uint8_t)clampi(store.arp_gate, 20, 100);
        play.seq_rate = store.seq_rate % 6u;
        play.seq_gate = (uint8_t)clampi(store.seq_gate, 20, 100);
    }
    app_load(store.magic == STORE_MAGIC ? store.voice : 0);
    app.boot_until = hal_ms() + SPLASH_MS;
    app.boot_ms = hal_ms();
    app.reset_watch = 1;
}

/* ------------------------------------------------------------------ input --- */
/* a mode (the arpeggiator, the sequencer) on or off: nothing left sounding, the transport stopped */
static void app_mode(uint32_t mode)
{
    uint32_t s = hal_lock();
    play.mode = (uint8_t)mode;
    play.playing = 0;
    play.nkeys = 0;
    play.hold = 0;
    play.arp_stop = 0;
    hal_unlock(s);
    play_restart();
    app.rec = app.rec_open = 0;
}

/* SEQ, recording: a key into the step (stopped: the cursor's; playing: the one playing). The first key of
 * a chord empties the step; all keys up: the step is done and, stopped, the cursor moves on */
static void app_record(uint32_t note)
{
    seq_pattern_t *pt = &play.pat[play.pattern];
    seq_step_t *st = &pt->step[(play.playing ? play.now : app.cursor) % SEQ_STEPS];
    if (!app.rec_open) {
        st->n = 0;
        st->off = 0;
        app.rec_open = 1;
    }
    if (st->n < 4u)
        st->note[st->n++] = (uint8_t)note;
}

static void app_input(void)
{
    hal_input_t in;
    uint32_t k, pressed, changed = 0;
    hal_input(&in);
    syn.master = in.master;
    if (!in.battery && app.battery && !in.usb_power)
        app.low_until = hal_ms() + 2500u; /* it just ran low: said once, large */
    app.battery = (uint8_t)in.battery;
    app.usb_power = (uint8_t)in.usb_power;
    pressed = in.buttons & ~app.buttons;
    app.buttons = in.buttons;
    if (pressed || (in.keys & ~app.keys))
        app.boot_until = hal_ms();        /* (the start-up screen: over at the first touch) */
    for (k = 0, changed = 0; k < NE; k++)
        changed |= in.enc[k] != 0;
    if (changed || in.keys || in.buttons)
        app.touched = hal_ms();           /* (HOME's slow turn waits for the panel to be left alone) */
    changed = 0;
    if (pressed & (1u << B_OCTDN))
        app.octave = (int8_t)clampi(app.octave - 1, -3, 3);
    if (pressed & (1u << B_OCTUP))
        app.octave = (int8_t)clampi(app.octave + 1, -3, 3);
    if ((pressed & (1u << B_OCTDN | 1u << B_OCTUP)) && (in.buttons & (1u << B_OCTDN)) && (in.buttons & (1u << B_OCTUP)))
        app.octave = 0;                   /* both: the middle */
    if (pressed & (1u << B_OCTDN | 1u << B_OCTUP))
        app.oct_until = hal_ms() + 1000u; /* (no LED says it: the screen does, for a second) */

    if (app.reset_watch) {                /* SAVE held while switching on, and 1.5 s on: the factory's sounds and */
        app.save_t0 = 1;                  /* no patterns, stored (the instrument's settings stay as they are) */
        if (!(in.buttons & (1u << B_SAVE))) {
            app.reset_watch = 0;
        } else if (hal_ms() - app.boot_ms > 1500u) {
            app.reset_watch = 0;
            store_factory();
            memset(play.pat, 0, sizeof play.pat);
            for (k = 0; k < SEQ_PATTERNS; k++)
                play.pat[k].len = SEQ_STEPS;
            app_load(0);
            store_settings();
            hal_store_write(&store, sizeof store, 0, sizeof store);
            app.note = "FACTORY RESET";
            app.note_until = hal_ms() + 2500u;
        }
    }
    if (play.mode == PM_SEQ && app.page == PG_SEQ && !play.playing) {   /* SEQ, stopped: REC held 0.7 s empties the pattern */
        if (!(in.buttons & (1u << B_REC))) {
            app.rec_t0 = 0;
        } else if (!app.rec_t0) {
            app.rec_t0 = hal_ms() | 2u;
        } else if (app.rec_t0 != 1u && (int32_t)(hal_ms() - app.rec_t0) > 700) {
            seq_pattern_t *pt = &play.pat[play.pattern];
            app.rec_t0 = 1;
            memset(pt->step, 0, sizeof pt->step);
            app.cursor = 0;
            app.rec = 1;                  /* (and ready to be filled again) */
            app.rec_open = 0;
            app.note = "CLEARED";
            app.note_until = hal_ms() + 1200u;
        }
    }
    /* SAVE: held 0.7 s, the screen says where the sound will go: where it is if that is one of yours, else
     * your first empty place; PRESETS, with SAVE still down, picks another of yours. Let go: saved there */
    if (!(in.buttons & (1u << B_SAVE))) {
        if (app.save_armed && !app.save_full)
            app_save(app.save_dst);
        app.save_armed = 0;
        app.save_full = 0;
        app.save_t0 = 0;
    } else if (!app.save_t0) {
        app.save_t0 = hal_ms() | 2u;
    } else if (app.save_t0 != 1u && !app.save_armed && (int32_t)(hal_ms() - app.save_t0) > 700) {
        app.save_armed = 1;
        app.save_dst = (uint8_t)save_default();
        app.save_full = app.voice < STOCK_VOICES && app.save_dst == app.voice;   /* (no empty place was found) */
    }
    if (app.save_armed && in.enc[EN_PRESET]) {
        app.save_dst = (uint8_t)((app.save_dst + (in.enc[EN_PRESET] > 0 ? 1u : NSLOTS - 1u)) % NSLOTS);
        app.save_full = 0;
        in.enc[EN_PRESET] = 0;
    }

    /* the page buttons. ARP and SEQ also switch their mode on (and the other off); only holding the button
     * switches it off again, so it goes on running under the other pages */
    for (k = 0; k < NPAGES; k++) {
        if (!(pressed & (1u << PAGES[k].button)))
            continue;
        if (k == PG_ARP || k == PG_SEQ) {
            uint32_t mode = k == PG_ARP ? PM_ARP : PM_SEQ;
            if (play.mode != mode)
                app_mode(mode);
            app.mode_t0 = hal_ms() | 2u;
        }
        app.page = (uint8_t)k;
    }
    if (!(in.buttons & (1u << B_FX))) {   /* FX held 0.7 s: every effect off */
        app.fx_t0 = 0;
    } else if (!app.fx_t0) {
        app.fx_t0 = hal_ms() | 2u;
    } else if (app.fx_t0 != 1u && (int32_t)(hal_ms() - app.fx_t0) > 700) {
        app.fx_t0 = 1;
        memset(fx.on, 0, sizeof fx.on);
    }
    if (!(in.buttons & (1u << B_ARP | 1u << B_SEQ))) {   /* ARP or SEQ held 0.7 s: that mode off, and HOME */
        app.mode_t0 = 0;
    } else if (app.mode_t0 > 1u && (int32_t)(hal_ms() - app.mode_t0) > 700) {
        uint32_t mode = in.buttons & (1u << B_ARP) ? PM_ARP : PM_SEQ;
        app.mode_t0 = 1;
        if (play.mode == mode) {
            app_mode(PM_OFF);
            app.page = PG_HOME;
        }
    }
    if (play.mode == PM_ARP && (pressed & (1u << B_PLAY))) {   /* PLAY / STOP: the arpeggiator stops with its notes */
        play.arp_stop = !play.arp_stop;                        /* kept, and starts again from the first */
        play_restart();
    }
    if (play.mode == PM_SEQ) {            /* the transport */
        if (pressed & (1u << B_PLAY)) {
            play.playing = !play.playing;
            play_restart();
        }
        if (pressed & (1u << B_REC)) {
            app.rec = !app.rec;
            app.rec_open = 0;
        }
    }

    /* SELECT: which one the page is about; SEL: that one off and on */
    if (in.enc[EN_SELECT] && (app.page == PG_EDIT || app.page == PG_ENV))
        app.op = (uint8_t)clampi(app.op + (in.enc[EN_SELECT] > 0 ? 1 : -1), 0, 5);
    if (in.enc[EN_SELECT] && app.page == PG_SEQ) {
        uint32_t len = play.pat[play.pattern].len;
        app.cursor = (uint8_t)((app.cursor + len + (in.enc[EN_SELECT] > 0 ? 1u : len - 1u)) % len);
        app.rec_open = 0;
    }
    if (in.enc[EN_SELECT] && app.page == PG_FX)
        app.fx_sel = (uint8_t)clampi(app.fx_sel + (in.enc[EN_SELECT] > 0 ? 1 : -1), 0, FX_N - 1);
    if (pressed & (1u << B_SEL)) {
        if (app.page == PG_FX) {
            fx.on[app.fx_sel] ^= 1u;
        } else if (app.page == PG_EDIT || app.page == PG_ENV) {
            app.op_off ^= (uint8_t)(1u << app.op);
            changed = 1;
        } else if (app.page == PG_ARP) {
            play.hold = play.hold == 1u ? 2u : 1u;   /* HOLD: the keys collect notes; again, LOOP: the notes go
                                                      * round and the keys play over them; again, HOLD: to change them */
        } else if (app.page == PG_SEQ) {
            play.pat[play.pattern].step[app.cursor].off ^= 1u;
        }
    }

    /* the keys: to the arpeggiator when it is on, else they play (and, recording, go into the pattern). The
     * arpeggiator and the pattern get the key itself: the octave and TRANSP are added as they play, so both
     * move what is running */
    if (play.shift != (int8_t)(12 * app.octave + app.transpose)) {
        play.shift = (int8_t)(12 * app.octave + app.transpose);
        for (k = 0; k < NKEYS; k++)       /* the notes held under the keys move with it */
            if (((app.keys >> k) & 1u) && app.key_live[k]) {
                uint8_t to = (uint8_t)clampi(KEY_LOWEST + (int32_t)k + play.shift, 0, 127);
                syn_move(app.key_note[k], to);
                app.key_note[k] = to;
            }
    }
    for (k = 0; k < NKEYS; k++) {
        uint32_t bit = 1u << k;
        if ((in.keys & bit) && !(app.keys & bit)) {
            app.key_note[k] = (uint8_t)clampi(KEY_LOWEST + (int32_t)k + play.shift, 0, 127);
            app.key_live[k] = !(play.mode == PM_ARP && play.hold != 2u);
            if (!app.key_live[k]) {
                play_arp_key(KEY_LOWEST + k, 1);
            } else {
                syn_note(app.key_note[k], 100);
                if (play.mode == PM_SEQ && app.rec)
                    app_record(KEY_LOWEST + k);
            }
        } else if (!(in.keys & bit) && (app.keys & bit)) {
            if (!app.key_live[k])
                play_arp_key(KEY_LOWEST + k, 0);
            else
                syn_note(app.key_note[k], 0);
        }
    }
    if (app.keys && !in.keys) {           /* the last key up */
        if (app.rec_open) {
            app.rec_open = 0;
            if (!play.playing)
                app.cursor = (uint8_t)((app.cursor + 1u) % play.pat[play.pattern].len);
        }
    }
    app.keys = in.keys;

    if (in.enc[EN_PRESET]) {              /* PRESETS: the next place that holds a sound (yours come after the factory's) */
        uint32_t v = app.voice;
        do
            v = (v + (in.enc[EN_PRESET] > 0 ? 1u : NSLOTS - 1u)) % NSLOTS;
        while (v >= STOCK_VOICES && !store.sound[v].used);
        app_load(v);
        hal_midi_out(0xB0u, 0, app.voice >> 7);   /* and outside: bank select and program change, as they come in (app_midi) */
        hal_midi_out(0xB0u, 32, 0);
        hal_midi_out(0xC0u, app.voice & 127u, 0);
        if (!app.still) {                 /* the new sound arrives: its operators open out from the middle, swinging in */
            app.pre_t0 = hal_ms() | 1u;   /* the way the knob went, and its number stands in the ring for a moment */
            app.drift = in.enc[EN_PRESET] > 0 ? -0x2AAAAAAA : 0x2AAAAAAA;
        }
    }
    if (in.enc[EN_ALGO]) {
        app.base[FP_ALG] = (uint8_t)(((app.base[FP_ALG] & 31u) + (in.enc[EN_ALGO] > 0 ? 1u : 31u)) % 32u);   /* round: 32 is next to 1 */
        app.alg_until = hal_ms() + 1000u;
        if (!app.still) {                 /* the operators swing round by a place into the new wiring, the way the knob went */
            int32_t d = app.drift / 4 + (in.enc[EN_ALGO] > 0 ? -0x0AAAAAAA : 0x0AAAAAAA);   /* (a quarter of the phase: no overflow) */
            app.drift = clampi(d, -0x15555555, 0x15555555) * 4;
        }
        changed = 1;
    }
    for (k = 0; k < 4u; k++)
        if (in.enc[EN_K1 + k]) {
            uint32_t id = PAGES[app.page].value[k];
            if (id == V_NONE)
                continue;
            val_set(id, val_get(id) + in.enc[EN_K1 + k]);
            app.hot = (uint8_t)k;
            app.hot_until = hal_ms() + 700u;
            changed = 1;
        }
    if (changed)
        app_apply();
}

/* ------------------------------------------------------------------- draw --- */
/* KNOB k + 1 is being turned (or was a moment ago) */
static int hot(uint32_t k) { return app.hot == k && (int32_t)(app.hot_until - hal_ms()) > 0; }

/* value column c: its label, its value, a gauge (a signed value: from the middle). While its knob is turned
 * the label is white and the gauge thick */
static void draw_value(uint32_t c, uint32_t id)
{
    const value_t *d = &VALUES[id];
    char b[14];
    int32_t v = val_get(id), x = 8 + 58 * (int32_t)c, gw = 46;
    int32_t at, mid = (0 - d->lo) * gw / (d->hi - d->lo);
    const char *label = id >= V_FX1 && id <= V_FX3 ? FX_INFO[app.fx_sel].label[id - V_FX1] : d->label;
    int32_t hi = id == V_FX1 && FX_INFO[app.fx_sel].types ? 2 : id == V_FX2 && app.fx_sel == FX_FILTER ? 99 : d->hi;
    uint16_t col = app.page == PG_FX && !fx.on[app.fx_sel] ? C_DARK : KNOB_COL[c];   /* an effect that is off: dimmed */
    at = (v - d->lo) * gw / (hi - d->lo);
    val_text(id, b);
    int32_t th = hot(c) ? 5 : 3;
    g_text(x, Y_LABEL, &font_s, label, hot(c) ? C_WHITE : C_GREY);
    if (g_text_w(&font_m, b) > 46)        /* a long name: smaller, so it stays in its column */
        g_text(x, Y_VALUE + 4, &font_s, b, col);
    else
        g_text(x, Y_VALUE, &font_m, b, col);
    g_rect(x, Y_GAUGE, gw, 1, C_DARK);
    if (d->sign)
        g_rect(x + (at < mid ? at : mid), Y_GAUGE - th / 2, (at < mid ? mid - at : at - mid) + 1, th, col);
    else
        g_rect(x, Y_GAUGE - th / 2, at + 1, th, col);
}

/* top left of the picture: the operator SELECT picked; top right: its frequency against the note */
static void draw_op_title(void)
{
    char b[14] = "OP ";
    g_int(b + 3, app.op + 1);
    g_text(8, 62, &font_s, b, C_WHITE);
    if (app.page == PG_EDIT) {            /* the frequency in its knobs' colours: "x2" (RATIO), "+25" (FINE) */
        char f[8] = "+";
        int32_t fine = val_get(V_FINE), xr = 232;
        if (fine) {
            g_int(f + 1, fine);
            xr -= g_text_w(&font_s, f);
            g_text(xr, 62, &font_s, f, KNOB_COL[1]);
            xr -= 4;
        }
        b[0] = 'x';                       /* a fixed operator: "100Hz" */
        val_text(V_RATIO, b + 1);
        g_text_r(xr, 62, &font_s, b + (op_bytes(app.base, app.op)[FP_MODE] != 0), KNOB_COL[0]);
        return;
    }
    b[0] = 'x';
    val_text(V_RATIO, b + 1);
    g_text_r(232, 62, &font_s, b + (op_bytes(app.base, app.op)[FP_MODE] != 0), C_GREY);
}

/* the picture of the sound: the output wrapped round a circle in the middle (silence: a plain circle), the
 * six operators round it, OP 1 top left and on clockwise. A ring as wide as the operator's level: a carrier
 * white and tied to the centre, a modulator blue and tied to what it modulates, a silent one dark, the
 * operator that feeds itself with a green moon going round it (FEED: faster and closer the more). Inside each ring a dot that follows the operator's
 * envelope while notes sound. HOME: TONE's modulators are the blue rings; ATTACK and RELEASE are seen in how
 * the ring in the middle starts and stops moving (below). EDIT: the picked operator has a dial of its own: LEVEL white, DETUNE an orange mark. */
#define PIC_R 30                          /* the centre circle at rest */
#define PIC_AMP 13                        /* the wave's reach in and out of it */
#define PIC_PTS 120u
static void draw_sound(void)
{
    static int16_t snap[SCOPE_N];
    uint8_t *p = app.base, m[6];
    uint32_t alg = p[FP_ALG] & 31u, car = carriers(alg), fbop = routes(alg, m), i, j, w = syn.scope_w, trig = 0;
    int32_t sx[6], sy[6], rad[6], peak = 0, px = 0, py = 0, fx = 0, fy = 0, x, y;
    /* PRESETS chose this sound a moment ago: how far it has arrived, 0..256 over 0.3 s, fast first */
    int32_t since = app.pre_t0 ? (int32_t)(hal_ms() - app.pre_t0) : 100000, in = since < 300 ? since * 256 / 300 : 256;
    in = 256 - (((256 - in) * (256 - in)) >> 8);
    if (since > 900)
        app.pre_t0 = 0;

    for (i = 0; i < 6u; i++) {            /* the ties first: the discs drawn after cut them off */
        int32_t lvl = op_bytes(p, i)[FP_OL];
        if (!((car >> i) & 1u))
            lvl = clampi(lvl + app.tone / 2, 0, 99);   /* (TONE moves the modulators: shown roughly) */
        {                                 /* on an oval, OP 1 top left; HOME left alone: they drift round it */
            uint32_t ph = (uint32_t)(i * 0x2AAAAAAAu - 0x15555555u) + (uint32_t)app.drift;
            sx[i] = PIC_CX + g_sin(ph) * 94 / 32768 * (116 + in * 140 / 256) / 256;
            sy[i] = PIC_CY - g_sin(ph + 0x40000000u) * 58 / 32768 * (116 + in * 140 / 256) / 256;
        }
        rad[i] = 3 + lvl * lvl * 11 / 9801;   /* 3 .. 14 px, by the square: the top of the range is where it is heard */
        rad[i] = 2 + (rad[i] - 2) * in / 256;
    }
    for (i = 0; i < 6u; i++)
        for (j = 0; j < 6u; j++)
            if (((m[i] >> j) & 1u) && j != i && in > 150)   /* (the ties once the operators are nearly there) */
                g_line(sx[j], sy[j], sx[i], sy[i], C_TIE);
    for (i = 0; i < 6u; i++)
        if ((car >> i) & 1u)
            g_line(sx[i], sy[i], PIC_CX, PIC_CY, C_DARK);
    g_disc(PIC_CX, PIC_CY, PIC_R + PIC_AMP + 4, C_BLACK);
    for (i = 0; i < 6u; i++) {
        int off = (app.op_off >> i) & 1u, silent = off || !op_bytes(p, i)[FP_OL];
        uint16_t c = silent ? C_DARK : ((car >> i) & 1u) ? C_WHITE : C_BLUE;
        int32_t live = (syn.op_level[5u - i] >> 20) - 120;       /* the top ~45 dB of the envelope */
        g_disc(sx[i], sy[i], rad[i] + 2, C_BLACK);
        g_circle(sx[i], sy[i], rad[i], c);
        if (app.page == PG_HOME && hot(0) && !silent && !((car >> i) & 1u))   /* TONE: the modulators stand out */
            g_circle(sx[i], sy[i], rad[i] + 1, c);
        if (live > 0 && !silent)
            g_disc(sx[i], sy[i], clampi(live * (rad[i] - 2) / 110, 1, rad[i] - 2), c);
        if (app.page == PG_EDIT && i == app.op) {         /* EDIT: the operator picked: a dial round it, */
            int32_t lv = op_bytes(p, i)[FP_OL] % 100, dt = (int32_t)(op_bytes(p, i)[FP_DET] & 15) - 7, dx, dy, k;
            g_circle(sx[i], sy[i], rad[i] + 5, C_DARK);
            for (k = 0; k < (hot(2) ? 2 : 1); k++)        /* its LEVEL as far round as it is up (white), */
                g_arc(sx[i], sy[i], rad[i] + 5 + k, 0u, (uint32_t)lv * 43383508u + 1u, KNOB_COL[2]);
            g_polar(sx[i], sy[i], rad[i] + 5, (uint32_t)(dt * 102261126), &dx, &dy);   /* DETUNE a mark off the top */
            g_disc(dx, dy, hot(3) ? 4 : 3, C_BLACK);
            g_disc(dx, dy, hot(3) ? 3 : 2, KNOB_COL[3]);
        }
        if (off) {                        /* switched off: struck through */
            g_line(sx[i] - rad[i] + 1, sy[i] + rad[i] - 1, sx[i] + rad[i] - 1, sy[i] - rad[i] + 1, C_GREY);
        }
        if (i == fbop && (p[FP_FB] & 7u)) {           /* FEED: the operator that feeds itself has a moon (green): */
            static uint32_t moon, last;               /* the more feedback, the faster and the closer it goes round, */
            uint32_t fbk = p[FP_FB] & 7u, now = hal_ms(), dt = now - last > 200u ? 0u : now - last, t;   /* from 5 on with a trail */
            int32_t mx, my, orbit = rad[i] + 9 - (int32_t)fbk / 2, big = app.page == PG_HOME && hot(1);
            last = now;
            moon = app.still ? 0u : moon + dt * (1073742u + (fbk - 1u) * 1245540u);   /* a turn in 4 s .. half a second */
            for (t = fbk >= 5u ? fbk - 3u : 0u; t > 0u; t--) {
                g_polar(sx[i], sy[i], orbit, moon - t * 0x06000000u, &mx, &my);
                g_disc(mx, my, 1, RGB(70 - t * 12, 220 - t * 40, 130 - t * 24));
            }
            g_polar(sx[i], sy[i], orbit, moon, &mx, &my);
            g_disc(mx, my, big ? 4 : 3, C_BLACK);
            g_disc(mx, my, big ? 3 : 2, KNOB_COL[1]);
        }
    }

    /* the centre: the scope's snapshot from a rising zero crossing, wrapped round the circle; the wave
     * fades to nothing at the seam so the loop closes */
    for (i = 0; i < SCOPE_N; i++) {
        snap[i] = syn.scope[(w + i) & (SCOPE_N - 1u)];
        if (snap[i] > peak)
            peak = snap[i];
        else if (-snap[i] > peak)
            peak = -snap[i];
    }
    for (i = 1; i < SCOPE_N - 2u * PIC_PTS; i++)
        if (snap[i - 1] < 0 && snap[i] >= 0) {
            trig = i;
            break;
        }
    /* The ring moves as much as the sound is loud, not as much as fits: its waves are measured against the
     * loudest the sound has lately been (a ceiling that sinks slowly). So a slow ATTACK is seen: a note hit
     * makes the ring wavy little by little; and the RELEASE: with the keys up the waves hold on as long as
     * the sound does, in orange, RELEASE's colour, and calm down into the plain circle. */
    {
        static int32_t ceiling = 3000;
        uint16_t c = !syn.any_held && peak > 900 ? KNOB_COL[3] : KNOB_COL[2];
        ceiling -= ceiling / 256;
        if (peak > ceiling)
            ceiling = peak;
        if (ceiling < 2000)
            ceiling = 2000;
        for (i = 0; i <= PIC_PTS; i++) {
            uint32_t k = i % PIC_PTS, edge = k < PIC_PTS - k ? k : PIC_PTS - k;
            int32_t a = snap[trig + 2u * k] * PIC_AMP / ceiling;
            if (edge < 8u)
                a = a * (int32_t)edge / 8;
            g_polar(PIC_CX, PIC_CY, PIC_R + a, (0xFFFFFFFFu / PIC_PTS) * k, &x, &y);
            if (!i) {
                fx = x;
                fy = y;
            } else if (i == PIC_PTS) {
                x = fx;
                y = fy;
            }
            if (i) {
                g_line(px, py, x, y, c);
                g_line(px + 1, py, x + 1, y, c);
            }
            px = x;
            py = y;
        }
    }
    if (since < 800) {                    /* the place's number in the ring while the sound arrives, then fading */
        char nb[8];
        g_int(nb, (int32_t)app.voice + 1);
        g_text_mid(PIC_CX + 1, PIC_CY, &font_m, nb, since < 550 ? C_WHITE : since < 680 ? C_GREY : C_DARK);   /* (the ring is 2 px thick, to the right) */
    }
    if (app.page == PG_EDIT)
        draw_op_title();
}

/* ARP's picture: the notes of one pass, left to right in the order they are played, as high as their pitch;
 * the one sounding large; notes collected with HOLD solid, keys held down hollow; the octaves added green.
 * The line from each note to the next is orange for as much of the way as GATE lets the note last. No note:
 * a hint */
static void draw_arp(void)
{
    uint8_t k[ARP_KEYS];
    uint32_t nk = play.nkeys, i, j, total, lo, hi;
    int32_t px = 0, py = 0;
    if (nk > ARP_KEYS)
        nk = 0;
    memcpy(k, play.key, nk);
    if (!nk) {
        const char *hint = play.hold == 2u ? "NO NOTES" : play.hold ? "PRESS KEYS" : "HOLD KEYS";
        g_text(PIC_CX - g_text_w(&font_s, hint) / 2, PIC_CY - 4, &font_s, hint, C_DARK);
        return;
    }
    if (play.arp_mode != AM_ORDER)
        for (i = 1; i < nk; i++)
            for (j = i; j && k[j - 1] > k[j]; j--) {
                uint8_t t = k[j];
                k[j] = k[j - 1];
                k[j - 1] = t;
            }
    total = nk * play.arp_oct;
    lo = hi = k[0];
    for (i = 0; i < nk; i++) {
        lo = k[i] < lo ? k[i] : lo;
        hi = k[i] > hi ? k[i] : hi;
    }
    hi += 12u * (play.arp_oct - 1u);
    for (i = 0; i < total; i++) {
        uint32_t note = (uint32_t)k[i % nk] + 12u * (i / nk);
        int32_t x = total > 1u ? 24 + (int32_t)i * 192 / (int32_t)(total - 1u) : PIC_CX;
        int32_t y = hi > lo ? 188 - (int32_t)(note - lo) * 104 / (int32_t)(hi - lo) : PIC_CY;
        if (i) {                          /* the way from a note to the next: orange as far as the note lasts (GATE), */
            int32_t gx = px + (x - px) * play.arp_gate / 100, gy = py + (y - py) * play.arp_gate / 100;   /* then faint */
            g_line(gx, gy, x, y, C_DARK);
            g_line(px, py, gx, gy, KNOB_COL[3]);
            if (hot(3))
                g_line(px, py + 1, gx, gy + 1, KNOB_COL[3]);
        }
        px = x;
        py = y;
    }
    for (i = 0; i < total; i++) {
        uint32_t note = (uint32_t)k[i % nk] + 12u * (i / nk);
        int32_t x = total > 1u ? 24 + (int32_t)i * 192 / (int32_t)(total - 1u) : PIC_CX;
        int32_t y = hi > lo ? 188 - (int32_t)(note - lo) * 104 / (int32_t)(hi - lo) : PIC_CY;
        int now = i == play.now && play.nsound;
        g_disc(x, y, now ? 9 : 4, C_BLACK);
        if (now) {
            g_circle(x, y, 8, C_BLUE);
            g_disc(x, y, 4, C_BLUE);
        } else if (play.hold) {           /* collected: solid; a key held down: hollow. The octaves added: green */
            g_disc(x, y, 3, i < nk ? C_BLUE : KNOB_COL[1]);
        } else {
            g_circle(x, y, 3, i < nk ? C_BLUE : KNOB_COL[1]);
        }
    }
}

/* SEQ's picture: the pattern's steps round a ring, the first at the top: a step with notes a green dot, an
 * empty one a faint point, one switched off a dark ring; the cursor a white ring round its step, the step
 * playing green, an orange mark outside the last step. In the middle the pattern's number (blue); under it REC
 * while recording */
static void draw_seq(void)
{
    const seq_pattern_t *pt = &play.pat[play.pattern];
    char b[12];
    uint32_t i;
    int32_t x, y;
    for (i = 0; i < pt->len; i++) {
        const seq_step_t *st = &pt->step[i];
        g_polar(PIC_CX, PIC_CY, 58, i * (0xFFFFFFFFu / pt->len), &x, &y);
        if (st->off)
            g_circle(x, y, 4, C_DARK);
        else if (st->n)
            g_disc(x, y, 3 + (st->n > 1u), C_WHITE);
        else
            g_disc(x, y, 1, C_GREY);
        if (i == app.cursor)
            g_circle(x, y, 8, app.rec ? C_RED : C_WHITE);
        if (play.playing && i == play.now) {
            g_disc(x, y, 6, C_BLACK);
            g_disc(x, y, 5, KNOB_COL[1]);
        }
    }
    g_polar(PIC_CX, PIC_CY, 70, (pt->len - 1u) * (0xFFFFFFFFu / pt->len), &x, &y);   /* LENGTH: where it ends */
    g_disc(x, y, 2, KNOB_COL[3]);
    g_int(b, play.pattern + 1);
    g_text(PIC_CX - g_text_w(&font_l, b) / 2, PIC_CY - 16, &font_l, b, KNOB_COL[0]);
    if (app.rec)
        g_text(PIC_CX - g_text_w(&font_s, "REC") / 2, PIC_CY + 16, &font_s, "REC", C_RED);
}

/* ENV's picture: the selected operator's envelope, a segment a knob in the knob's colour: the attack up to
 * the top (blue), the decay down to the sustain level (green), the sustain while the key is held (white),
 * the release after it (orange). The slower a stage the wider its segment. A dot rides the curve at the
 * place the newest note's envelope is. A key let go before the sustain is reached: the envelope falls from
 * where it was, off the curve; that fall is drawn as a thin line under the dot while it lasts. */
#define EV_X0 14
#define EV_X1 226
#define EV_TOP 84
#define EV_BOT 196
static void draw_env(void)
{
    const uint8_t *o = op_bytes(app.base, app.op);
    int32_t a = val_get(V_OATK), d = val_get(V_ODEC), r = val_get(V_OREL);
    int32_t top = EV_BOT - (o[FP_L1] % 100) * (EV_BOT - EV_TOP) / 99;
    int32_t sus = EV_BOT - val_get(V_OSUS) * (EV_BOT - EV_TOP) / 99;
    int32_t end = EV_BOT - (o[FP_L1 + 3] % 100) * (EV_BOT - EV_TOP) / 99;
    int32_t mid = EV_BOT - (o[FP_L1 + 1] % 100) * (EV_BOT - EV_TOP) / 99;   /* the level between the two decay steps */
    int32_t x[5], y[5], k, t, xm;
    uint32_t st = syn.op_stage[5u - app.op];
    x[0] = EV_X0;                         /* each of attack, decay, release: 6 .. 56 px; the sustain: the rest */
    x[1] = x[0] + 6 + a * 50 / 99;
    x[2] = x[1] + 6 + d * 50 / 99;
    x[4] = EV_X1;
    x[3] = x[4] - 6 - r * 50 / 99;
    y[0] = EV_BOT;
    y[1] = top;
    y[2] = y[3] = sus;
    y[4] = end;
    g_rect(EV_X0, EV_BOT + 3, EV_X1 - EV_X0 + 1, 1, C_DARK);
    xm = (x[1] + x[2]) / 2;
    for (k = 0; k < 4; k++)
        for (t = 0; t < (hot((uint32_t)k) ? 4 : 2); t++) {  /* 2 px; the one whose knob is turned: 4 */
            if (k == 1 && mid != sus) {   /* the decay by way of its level between: the sound's own bend */
                g_line(x[1], y[1] + t, xm, mid + t, KNOB_COL[1]);
                g_line(xm, mid + t, x[2], y[2] + t, KNOB_COL[1]);
            } else
                g_line(x[k], y[k] + t, x[k + 1], y[k + 1] + t, KNOB_COL[k]);
        }
    for (k = 1; k < 4; k++)               /* a guide down from each corner */
        for (t = y[k] + 5; t < EV_BOT; t += 4)
            g_pset(x[k], t, C_DARK);
    if (st < 4u) {                        /* the dot: on the stage's segment, as far along as the envelope is */
        int32_t pr = syn.op_prog[5u - app.op];
        static int32_t last_y = EV_BOT;   /* the dot's height before the key was let go */
        int32_t lx = x[st] + (x[st + 1] - x[st]) * pr / 255, ly = y[st] + (y[st + 1] - y[st]) * pr / 255;
        if (st == 1u && mid != sus)       /* (along the bend) */
            ly = lx < xm ? y[1] + (mid - y[1]) * (lx - x[1]) / (xm - x[1] > 0 ? xm - x[1] : 1)
                         : mid + (y[2] - mid) * (lx - xm) / (x[2] - xm > 0 ? x[2] - xm : 1);
        if (st == 3u)                     /* released: the dot falls from the height it had, wherever on the curve that */
            ly = last_y + (y[4] - last_y) * pr / 255;       /* was (the curve itself stays as it is, as on other synths) */
        else
            last_y = ly;
        g_disc(lx, ly, 5, C_BLACK);
        g_disc(lx, ly, 3, KNOB_COL[st]);
    }
    draw_op_title();
}

/* LFO's picture: the wave scrolling past a fixed dot in the middle, at the LFO's own speed (the dot is now:
 * what is left of it has happened). The shape itself thin and green; over it the same wave as tall as the
 * PITCH depth (white) and as tall as the LEVEL depth (orange). The dot blue: RATE. */
static int32_t lfo_wave(uint32_t shape, uint32_t ph, uint32_t cycle)   /* -256 .. 256 at phase ph (2^32 a cycle) */
{
    int32_t t = (int32_t)(ph >> 23);      /* 0..511 */
    switch (shape) {
    case 0: return t < 256 ? 2 * t - 256 : 767 - 2 * t;
    case 1: return 256 - t;
    case 2: return t - 256;
    case 3: return t < 256 ? 256 : -256;
    case 4: return g_sin(ph) >> 7;
    default: return (int32_t)((cycle * 2654435761u) >> 23) - 256;   /* a level a cycle */
    }
}
static void draw_lfo(void)
{
    static uint32_t last_ph, cycles;
    uint32_t shape = app.base[FP_LFW] % 6u, ph = syn.lfo.phase;
    int32_t dp = app.base[FP_LPMD] % 100, da = app.base[FP_LAMD] % 100, x, k;
    int32_t prev[3] = {0, 0, 0};
    if (ph < last_ph)
        cycles++;                         /* (S&H: a new level each time round) */
    last_ph = ph;
    g_rect(14, PIC_CY, 213, 1, C_DARK);
    for (x = 14; x <= 226; x++) {         /* 80 px a cycle */
        /* the phase x - PIC_CX pixels from now, and how many cycles from now that is (32-bit sums only) */
        uint32_t at = ph + (uint32_t)(x - PIC_CX) * 53687091u;                       /* 2^32 / 80 */
        uint32_t cyc = cycles + (uint32_t)(((int32_t)(ph >> 8) + (x - PIC_CX) * 209715) >> 24);
        int32_t w = lfo_wave(shape, at, cyc);
        int32_t y[3] = {PIC_CY - w * 52 / 256, PIC_CY - w * 52 * dp / (256 * 99), PIC_CY - w * 52 * da / (256 * 99)};
        const uint16_t col[3] = {hot(1) ? C_GREEN : RGB(30, 96, 56), C_WHITE, C_ORANGE};
        for (k = 0; k < 3; k++) {
            if (x > 14 && (k == 0 || (k == 1 ? dp : da))) {
                g_line(x - 1, prev[k], x, y[k], col[k]);
                if (k && hot((uint32_t)k + 1u))
                    g_line(x - 1, prev[k] + 1, x, y[k] + 1, col[k]);
            }
            prev[k] = y[k];
        }
    }
    k = PIC_CY - lfo_wave(shape, ph, cycles) * 52 / 256;
    g_disc(PIC_CX, k, hot(0) ? 7 : 5, C_BLACK);
    g_disc(PIC_CX, k, hot(0) ? 5 : 3, C_BLUE);
}

/* GLO's picture: a pendulum that swings a beat each way at the TEMPO (blue), over a scale whose middle is
 * no transposition: an orange mark shows where TRANSP is, a green one inside it SWING; GLIDE gives the weight
 * a white trail */
static void draw_glo(void)
{
    uint32_t ph = (uint32_t)((hal_ms() % 120000u) * play.tempo % 120000u) * 35791u;   /* a turn: two beats (2^32 / 120000) */
    int32_t sw = g_sin(ph) * 28 / 32768, x, y, k;                   /* degrees, about */
    for (k = -5; k <= 5; k++) {
        int32_t x0, y0;
        g_polar(PIC_CX, 78, 112, (uint32_t)(0x80000000u + k * 0x2000000), &x, &y);
        g_polar(PIC_CX, 78, k ? 116 : 122, (uint32_t)(0x80000000u + k * 0x2000000), &x0, &y0);
        g_line(x, y, x0, y0, k ? C_DARK : C_GREY);
    }
    g_polar(PIC_CX, 78, 128, (uint32_t)(0x80000000u - app.transpose * (5 * 0x2000000 / 12)), &x, &y);   /* up: to the right */
    g_disc(x, y, 2, C_ORANGE);
    g_polar(PIC_CX, 78, 104, (uint32_t)(0x80000000u + (play.swing - 50) * (5 * 0x2000000 / 25)), &x, &y);   /* SWING: off the middle */
    g_disc(x, y, 2, KNOB_COL[1]);
    for (k = app.glide / 14; k > 0; k--) {   /* GLIDE: the weight leaves a trail, longer as it rises (white) */
        int32_t lag = g_sin(ph - (uint32_t)k * 0x05000000u) * 28 / 32768;
        g_polar(PIC_CX, 78, 96, 0x80000000u + (uint32_t)(lag * 11930465), &x, &y);
        g_disc(x, y, 2, RGB(255 - k * 28, 255 - k * 28, 255 - k * 28));
    }
    g_polar(PIC_CX, 78, 96, 0x80000000u + (uint32_t)(sw * 11930465), &x, &y);
    g_line(PIC_CX, 78, x, y, C_GREY);
    g_disc(PIC_CX, 78, 2, C_GREY);
    g_disc(x, y, 9, C_BLACK);
    g_circle(x, y, 8, C_BLUE);
    g_disc(x, y, 3, C_BLUE);
    {                                     /* top left, small: how busy the audio keeps the processor (now, lately at most) */
        char b[40] = "LOAD ";
        uint32_t ld = hal_load();
        g_int(b + 5, (int32_t)(ld & 255u));
        strcat(b, " / ");
        g_int(b + strlen(b), (int32_t)(ld >> 8 & 255u));
        strcat(b, "   VOICES ");
        g_int(b + strlen(b), syn.limit ? syn.limit : SYN_VOICES);
        g_text(8, 62, &font_s, b, C_DARK);
    }
}

/* FX's picture: a scene for the effect SELECT picked, drawn from its three values in their knobs' colours
 * (all dark while the effect is off); its name above, ON or OFF beside it; under it the chain, the sound
 * going through it from left to right: an effect that is on a white point, one that is off a dark ring, the
 * picked one ringed. */
#define FS_X0 22
#define FS_X1 218
#define FS_CY 118
static uint16_t fx_col(uint32_t k) { return fx.on[app.fx_sel] ? KNOB_COL[k] : C_DARK; }

/* DIST: a sine pushed against its ceiling. The ceiling: two rails (GAIN, blue: the harder, the squarer the
 * wave under them). The wave as clipped, faint, and as it leaves, after TONE has rounded it (green) and
 * LEVEL sized it (white) */
static void fx_scene_dist(const uint8_t *p)
{
    int32_t x, lp = 0, py = 0, pr = 0;
    for (x = FS_X0; x <= FS_X1; x += 6)
        g_rect(x, FS_CY - 36, 3, 1, fx_col(0)), g_rect(x, FS_CY + 36, 3, 1, fx_col(0));
    for (x = FS_X0; x <= FS_X1; x++) {
        int32_t sn = g_sin((uint32_t)(x - FS_X0) * 32870000u);       /* a cycle and a half across */
        int32_t c = clampi(sn * (64 + p[0] * 5) / 64, -32767, 32767);
        int32_t y = (3 * c - (((c * c) >> 15) * c >> 15)) / 2;
        lp += (y - lp) * (2500 + p[1] * 290) / 32768;
        if (x > FS_X0) {
            g_line(x - 1, FS_CY - pr * 34 / 32768, x, FS_CY - y * 34 / 32768, fx.on[app.fx_sel] ? RGB(30, 96, 56) : C_DARK);
            g_line(x - 1, py, x, FS_CY - lp * 34 / 32768 * p[2] / 100, fx_col(2));
        }
        pr = y;
        py = FS_CY - lp * 34 / 32768 * p[2] / 100;
    }
}
/* FILTER: what it lets through, low notes left, high right: the curve's shape is the TYPE (blue), where it
 * turns the CUTOFF (a green mark under it), the peak there the RESO (white) */
static void fx_scene_filter(const uint8_t *p)
{
    int32_t cx = FS_X0 + (p[1] > 99 ? 99 : p[1]) * (FS_X1 - FS_X0) / 99, x, py = 0, peak = p[2] * 26 / 100;
    for (x = FS_X0; x <= FS_X1; x++) {
        int32_t d = x - cx, a = d < 0 ? -d : d, fall, y;
        fall = p[0] == 0 ? (d > 0 ? d * 2 : 0) : p[0] == 2 ? (d < 0 ? -d * 2 : 0) : a * 3 / 2;
        y = FS_CY + 2 + clampi(fall, 0, 40) - (a < 14 ? peak * (14 - a) / 14 : 0);
        if (x > FS_X0)
            g_line(x - 1, py, x, y, fx_col(0));
        py = y;
    }
    g_rect(FS_X0, FS_CY + 44, FS_X1 - FS_X0, 1, C_DARK);
    g_rect(cx - 1, FS_CY + 40, 3, 9, fx_col(1));
    g_disc(cx, FS_CY + 2 - peak, 2 + p[2] / 40, fx_col(2));
}
/* PHASER: a band with four notches cut into it, sweeping from side to side as the effect does: how fast, the
 * RATE (the blue point under it); how far, the DEPTH (the green line it runs on); how deep the notches, the
 * MIX (white) */
static void fx_scene_phaser(const uint8_t *p)
{
    int32_t t = (int32_t)(fx.ph_lfo >> 16), range = 10 + p[1] * 50 / 100, pos, x, py = 0, j;
    t = t < 32768 ? t : 65535 - t;
    pos = PIC_CX + (t - 16384) * range / 16384;
    for (x = FS_X0; x <= FS_X1; x++) {
        int32_t y = FS_CY - 18, best = 99;
        for (j = 0; j < 4; j++) {
            int32_t d = x - (pos + (2 * j - 3) * 13);
            d = d < 0 ? -d : d;
            best = d < best ? d : best;
        }
        if (best < 7)
            y += (7 - best) * (p[2] * 34 / 100) / 7;
        if (x > FS_X0)
            g_line(x - 1, py, x, y, fx_col(2));
        py = y;
    }
    g_rect(PIC_CX - range, FS_CY + 34, 2 * range + 1, 1, fx_col(1));
    g_disc(pos, FS_CY + 34, 3, fx_col(0));
}
/* CHORUS: the sound (white) and its copy (green) drifting apart and back: how far, the DEPTH; how fast, the
 * RATE (the blue point under them); how much of the copy, the MIX (its height) */
static void fx_scene_chorus(const uint8_t *p)
{
    int32_t x, pa = 0, pb = 0, drift = g_sin(fx.ch_lfo) * (p[1] * 26 / 100) / 32768;
    for (x = FS_X0; x <= FS_X1; x++) {
        int32_t a = FS_CY - 6 - g_sin((uint32_t)(x - FS_X0) * 43827000u) * 20 / 32768;
        int32_t b = FS_CY - 6 - g_sin((uint32_t)(x - FS_X0 - drift) * 43827000u) * (20 * p[2] / 100) / 32768;
        if (x > FS_X0) {
            g_line(x - 1, pb, x, b, fx_col(1));
            g_line(x - 1, pa, x, a, fx_col(2));
        }
        pa = a;
        pb = b;
    }
    g_rect(FS_X0, FS_CY + 34, FS_X1 - FS_X0, 1, C_DARK);
    g_disc(FS_X0 + (int32_t)(fx.ch_lfo >> 24) * (FS_X1 - FS_X0) / 256, FS_CY + 34, 3, fx_col(0));
}
/* DELAY: the note and its echoes: how far apart, the TIME (blue marks under them, and a point that takes that
 * long from one to the next); how slowly they fade, the REPEAT (the green line over them); how loud the first
 * one, the MIX (white) */
static void fx_scene_delay(const uint8_t *p)
{
    int32_t gap = 16 + p[0] * 44 / 100, ms = (1300 + p[0] * 314) * 10 / 441, x = FS_X0 + 10, rq = 8 * 16, k, px = 0, py = 0;
    g_rect(FS_X0, FS_CY + 30, FS_X1 - FS_X0, 1, C_DARK);
    for (k = 0; x < FS_X1 && rq >= 12; k++) {   /* (the size in sixteenths of a pixel: small echoes still shrink) */
        int32_t r = rq / 16;
        g_disc(x, FS_CY - 4, r, k ? fx_col(2) : (fx.on[app.fx_sel] ? C_GREY : C_DARK));
        g_rect(x, FS_CY + 27, 1, 7, fx_col(0));
        if (k > 1)
            g_line(px, py, x, FS_CY - 4 - r - 4, fx_col(1));
        px = x;
        py = FS_CY - 4 - r - 4;
        x += gap;
        rq = k ? rq * (20 + p[1] * 3 / 4) / 100 : (2 + 6 * p[2] / 100) * 16;
    }
    g_disc(FS_X0 + 10 + (int32_t)(hal_ms() % (uint32_t)ms) * gap / ms, FS_CY + 30, 2, fx_col(0));
}
/* REVERB: a room and a sound in the middle of it: the room's shape, the TYPE (blue); the rings that spread
 * from the sound, as far as the DECAY (green, fainter the further out); the sound itself, the MIX (white) */
static void fx_scene_reverb(const uint8_t *p)
{
    static const uint8_t W[3] = {44, 86, 96}, H[3] = {30, 40, 18};
    uint32_t ty = p[0] > 2 ? 2 : p[0];
    int32_t far = 10 + p[1] * 70 / 100, ph = (int32_t)(hal_ms() / 40u % 18u), j, w = W[ty], h = H[ty];
    for (j = 0; j < 5; j++) {
        int32_t r = 6 + j * 18 + ph, v;
        if (r >= far)
            break;
        v = 200 * (far - r) / far;
        g_circle(PIC_CX, FS_CY, r, fx.on[app.fx_sel] ? RGB(v * 70 / 255, v * 220 / 255, v * 130 / 255) : RGB(v / 6, v / 6, v / 6));
    }
    g_rect(PIC_CX - w, FS_CY - h, 2 * w + 1, 1, fx_col(0));
    g_rect(PIC_CX - w, FS_CY + h, 2 * w + 1, 1, fx_col(0));
    g_rect(PIC_CX - w, FS_CY - h, 1, 2 * h + 1, fx_col(0));
    g_rect(PIC_CX + w, FS_CY - h, 1, 2 * h + 1, fx_col(0));
    g_disc(PIC_CX, FS_CY, 2 + p[2] * 5 / 100, fx_col(2));
}

static void draw_fx(void)
{
    static void (*const SCENE[FX_N])(const uint8_t *) = {fx_scene_dist, fx_scene_filter, fx_scene_phaser,
                                                        fx_scene_chorus, fx_scene_delay, fx_scene_reverb};
    uint32_t i, on = fx.on[app.fx_sel];
    g_text(8, 62, &font_s, FX_INFO[app.fx_sel].name, on ? C_WHITE : C_GREY);
    g_text_r(232, 62, &font_s, on ? "ON" : "OFF", on ? C_GREEN : C_DARK);
    SCENE[app.fx_sel](fx.p[app.fx_sel]);
    g_rect(72, 190, 97, 1, C_DARK);
    for (i = 0; i < FX_N; i++) {
        int32_t cx = 72 + (int32_t)i * 19, cy = 190;
        g_disc(cx, cy, 7, C_BLACK);
        if (fx.on[i])
            g_disc(cx, cy, 3, C_WHITE);
        else
            g_circle(cx, cy, 3, C_GREY);
        if (i == app.fx_sel)
            g_circle(cx, cy, 6, C_WHITE);
    }
}

/* the start-up screen: a circle that draws itself, a body going round it, the name coming up under them, the
 * version under the name. t: 0 .. 1000 through it */
static void draw_splash(uint32_t t)
{
    static const char name[] = "orbit", ver[] = "v" ORBIT_VERSION;
    uint32_t draw = t < 450u ? t * 1000u / 450u : 1000u;              /* the circle: drawn in the first 45 % */
    uint32_t e = 1000u - t, turn = 1000u - e * e / 1000u * e / 1000u;  /* the body: fast, then settling (cubic) */
    uint32_t fade = t < 350u ? 0u : t > 750u ? 255u : (t - 350u) * 255u / 400u;
    int32_t cx = PIC_CX, cy = 92, x, y;
    g_arc(cx, cy, 46, 0u, 0xFFFFFFFEu, RGB(40, 40, 44));               /* its path */
    if (draw)
        for (y = 0; y < 2; y++)
            g_arc(cx, cy, 28 - y, 0u, (uint32_t)(0xFFFFFFFEu / 1000u * draw), C_WHITE);
    g_polar(cx, cy, 46, 4294967u * (turn * 5u / 4u % 1000u), &x, &y);  /* a turn and a quarter */
    g_disc(x, y, 7, C_BLACK);
    g_disc(x, y, 4, C_ORANGE);
    g_text(cx - g_text_w(&font_l, name) / 2, 164, &font_l, name, RGB(fade, fade, fade));
    fade = fade * 120u / 255u;
    g_text(cx - g_text_w(&font_s, ver) / 2, 204, &font_s, ver, RGB(fade, fade, fade + fade / 20u));
}

/* the battery, bottom right: an outline with up to three bars. Quiet (grey) while there is plenty; one bar
 * left: orange; none: red and blinking; a computer powering it: green, full */
static void draw_battery(void)
{
    uint32_t lv = app.usb_power ? 3u : app.battery, k;
    uint16_t c = app.usb_power ? C_GREEN : lv == 0u ? C_RED : lv == 1u ? C_ORANGE : C_GREY;
    int32_t x = 215, y = Y_FOOT + 1;
    if (!app.usb_power && lv == 0u && (hal_ms() / 500u) & 1u)
        return;                           /* (blinking) */
    g_rect(x, y, 15, 1, c);
    g_rect(x, y + 7, 15, 1, c);
    g_rect(x, y, 1, 8, c);
    g_rect(x + 14, y, 1, 8, c);
    g_rect(x + 15, y + 2, 2, 4, c);
    for (k = 0; k < lv; k++)
        g_rect(x + 2 + (int32_t)k * 4, y + 2, 3, 4, c);
}

static void app_draw(void)
{
    char b[24], *s;
    uint32_t i;
    g_clear(C_BLACK);
    if (app.page == PG_HOME && hal_ms() - app.touched > 20000u && !play.nsound && !app.still)   /* 20 s alone: a slow turn */
        app.drift += 0x00280000;
    else
        app.drift -= app.drift / 5;       /* back to their places: after a touch, or after ALGORITHM swung them */
    if ((int32_t)(app.boot_until - hal_ms()) > 0) {
        draw_splash(1000u - (app.boot_until - hal_ms()) * 1000u / SPLASH_MS);
        hal_present(fb);
        return;
    }
    for (i = 0; i < 4u; i++)
        if (PAGES[app.page].value[i] != V_NONE)
            draw_value(i, PAGES[app.page].value[i]);
    if (app.save_armed) {                 /* SAVE held: where the sound will go, and what is there now */
        const sound_t *d = &store.sound[app.save_dst];
        char n[12], w[12];
        uint32_t k;
        int32_t x;
        g_int(n, (int32_t)app.save_dst + 1);
        for (k = 0; k < 10u; k++)
            w[k] = (char)d->patch[FP_NAME + k];
        for (k = 10; k && w[k - 1] == ' '; k--)
            ;
        w[k] = 0;
        if (app.save_full) {              /* every place of yours is taken: which sound gives way is for PRESETS to say */
            g_text(PIC_CX - g_text_w(&font_m, "BANK FULL") / 2, PIC_CY - 22, &font_m, "BANK FULL", C_ORANGE);
            g_text(PIC_CX - g_text_w(&font_s, "TURN PRESETS") / 2, PIC_CY + 8, &font_s, "TURN PRESETS", C_GREY);
            g_text(PIC_CX - g_text_w(&font_s, "TO CHOOSE A PLACE") / 2, PIC_CY + 24, &font_s, "TO CHOOSE A PLACE", C_GREY);
        } else {
        g_text(PIC_CX - g_text_w(&font_s, "SAVE TO") / 2, PIC_CY - 38, &font_s, "SAVE TO", C_GREEN);
        g_text(PIC_CX - g_text_w(&font_l, n) / 2, PIC_CY - 16, &font_l, n, C_WHITE);
        if (d->used) {
            x = PIC_CX - (g_text_w(&font_s, "OVER ") + g_text_w(&font_s, w)) / 2;
            x = g_text(x, PIC_CY + 22, &font_s, "OVER ", C_ORANGE);
            g_text(x, PIC_CY + 22, &font_s, w, C_GREY);
        } else {
            g_text(PIC_CX - g_text_w(&font_s, "FREE") / 2, PIC_CY + 22, &font_s, "FREE", C_GREY);
        }
        }
    } else if ((int32_t)(app.imp_until - hal_ms()) > 0) {    /* sounds just came from a computer */
        char a[16], b[8];
        uint32_t k;
        if (app.imp_msg == 0) {
            g_int(a, (int32_t)app.imp_n);
            g_text(PIC_CX - g_text_w(&font_s, app.imp_n == 1 ? "SOUND LOADED" : "SOUNDS LOADED") / 2, PIC_CY + 22, &font_s,
                   app.imp_n == 1 ? "SOUND LOADED" : "SOUNDS LOADED", C_GREEN);
            g_text(PIC_CX - g_text_w(&font_l, a) / 2, PIC_CY - 16, &font_l, a, C_WHITE);
            g_int(a, (int32_t)app.imp_lo + 1);
            if (app.imp_hi != app.imp_lo) {
                for (k = 0; a[k]; k++)
                    ;
                a[k++] = '-';
                g_int(b, (int32_t)app.imp_hi + 1);
                memcpy(a + k, b, 4);
                a[k + 4] = 0;
            }
            g_text(PIC_CX - g_text_w(&font_s, a) / 2, PIC_CY - 38, &font_s, a, C_GREY);
        } else {
            const char *m = app.imp_msg == 1 ? "LOAD FAILED" : app.imp_msg == 2 ? "NO FREE PLACE" : "FROM COMPUTER";
            g_text(PIC_CX - g_text_w(&font_m, m) / 2, PIC_CY - 8, &font_m, m, app.imp_msg == 3 ? C_GREEN : C_RED);
        }
    } else if ((int32_t)(app.low_until - hal_ms()) > 0) {    /* the battery just ran low */
        g_text(PIC_CX - g_text_w(&font_m, "LOW BATTERY") / 2, PIC_CY - 8, &font_m, "LOW BATTERY", C_RED);
    } else if ((int32_t)(app.oct_until - hal_ms()) > 0) {    /* OCT just pressed: the octave, large */
        char o[8];
        o[0] = app.octave > 0 ? '+' : 0;
        g_int(o + (app.octave > 0), app.octave);
        g_text(PIC_CX - g_text_w(&font_s, "OCTAVE") / 2, PIC_CY - 34, &font_s, "OCTAVE", C_GREY);
        g_text(PIC_CX - g_text_w(&font_l, o) / 2, PIC_CY - 12, &font_l, o, C_WHITE);
    } else if ((int32_t)(app.alg_until - hal_ms()) > 0)      /* ALGORITHM just turned: the sound's picture */
        draw_sound();
    else
        PAGES[app.page].picture();
    i = (uint32_t)g_text(8, Y_FOOT, &font_s, PAGES[app.page].name, C_GREY);
    if ((int32_t)(app.saved_until - hal_ms()) > 0)
        i = (uint32_t)g_text((int32_t)i + 8, Y_FOOT, &font_s, "SAVED", C_GREEN);
    if (app.note && (int32_t)(app.note_until - hal_ms()) > 0)
        i = (uint32_t)g_text((int32_t)i + 8, Y_FOOT, &font_s, app.note, C_ORANGE);
    if (app.page == PG_ARP && play.hold)
        i = (uint32_t)g_text((int32_t)i + 8, Y_FOOT, &font_s, play.hold == 2u ? "LOOP" : "HOLD", C_WHITE);
    if (app.page == PG_ARP && play.arp_stop)
        g_text((int32_t)i + 8, Y_FOOT, &font_s, "STOP", C_ORANGE);
    if (app.page == PG_SEQ && play.playing)
        g_text((int32_t)i + 8, Y_FOOT, &font_s, "PLAY", C_WHITE);
    g_int(b, (int32_t)app.voice + 1);     /* "12 syn pad 3": the number grey, the name white */
    s = b + strlen(b);
    *s++ = 0;
    for (i = 0; i < 10u; i++)
        s[i] = (char)app.base[FP_NAME + i];
    for (i = 10; i && s[i - 1] == ' '; i--)
        ;
    s[i] = 0;
    g_text_r(208, Y_FOOT, &font_s, s, C_WHITE);
    g_text_r(208 - g_text_w(&font_s, s) - 7, Y_FOOT, &font_s, b, C_GREY);
    draw_battery();
    hal_present(fb);
}

/* the LEDs: the page's button; ARP and SEQ while on; PLAY and REC as the transport is; SEL while the thing
 * SELECT picked is on. The keys: the ones held, and the note the arpeggiator or the sequencer is playing, on
 * the key that plays it (an octave the keys do not reach: the same note's key in reach). On SEQ, stopped and
 * no key down: the steps that have notes */
static void app_leds(void)
{
    uint32_t b = 1u << PAGES[app.page].button, k = app.keys, i;
    for (i = 0; i < FX_N; i++)            /* FX: lit as long as any effect is on, whatever the page */
        if (fx.on[i])
            b |= 1u << B_FX;
    if ((int32_t)(app.boot_until - hal_ms()) > 0) {   /* the start-up screen: a light runs up the keys */
        uint32_t at = (SPLASH_MS - (app.boot_until - hal_ms())) * (NKEYS + 6u) / SPLASH_MS;
        hal_leds(0, (7u << at >> 3) & ((1u << NKEYS) - 1u));
        return;
    }
    if (play.mode == PM_ARP) b |= 1u << B_ARP;
    if (play.mode == PM_SEQ) b |= 1u << B_SEQ;
    if (play.playing || (play.mode == PM_ARP && play.nkeys && !play.arp_stop)) {   /* PLAY: on the beat, a short flash, while it runs */
        uint32_t beat = (hal_ms() % 60000u) * play.tempo % 60000u;
        if (beat < 12000u) b |= 1u << B_PLAY;
    }
    if (app.rec) b |= 1u << B_REC;
    if ((app.page == PG_FX && fx.on[app.fx_sel]) || (app.page == PG_ARP && play.hold == 1u) ||   /* (HOLD: the keys are its; LOOP: yours again, dark) */
        ((app.page == PG_EDIT || app.page == PG_ENV) && !((app.op_off >> app.op) & 1u)))
        b |= 1u << B_SEL;
    for (i = 0; i < play.nsound && i < 4u; i++) {
        int32_t key = (int32_t)play.sounding[i] - play.shift - KEY_LOWEST;
        while (key >= NKEYS)
            key -= 12;
        while (key < 0)
            key += 12;
        k |= 1u << key;
    }
    if (app.page == PG_SEQ && !app.keys && !play.playing) {
        const seq_pattern_t *pt = &play.pat[play.pattern];
        for (i = 0; i < pt->len; i++)
            if (pt->step[i].n && !pt->step[i].off)
                k |= 1u << i;
    }
    hal_leds(b, k);
}

/* the processor running short (the audio above 85 % of its time): a note fewer may sound, and one more a
 * quarter of a second later if that was not enough; with room again (below 60 %) they come back one a second */
static void app_guard(void)
{
    static uint32_t last;
    uint32_t ld = hal_load() & 255u, now = hal_ms();
    if (!syn.limit)
        syn.limit = SYN_VOICES;
    if (ld > 85u && now - last > 250u && syn.limit > 4u) {
        syn.limit--;
        last = now;
    } else if (ld < 60u && now - last > 1000u && syn.limit < SYN_VOICES) {
        syn.limit++;
        last = now;
    }
}

static void app_tick(void)
{
    app_input();
    app_guard();
    app_leds();
    if (!(app.frame++ & 1u))              /* a frame every other tick: about 30 a second */
        app_draw();
}

static void app_audio(int32_t *out)
{
    play_block();
    syn_render(out);
}
