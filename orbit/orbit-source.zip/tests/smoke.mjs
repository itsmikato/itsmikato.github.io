// SPDX-License-Identifier: GPL-3.0-only
// A smoke test of the browser build:  node tests/smoke.mjs  (after ./build_web.sh)
// Boots the firmware, checks silence, holds a chord on every 16th factory voice and checks that sound
// comes out below full scale, then that the screen was drawn.
import fs from "node:fs";
import assert from "node:assert/strict";
import crypto from "node:crypto";
const { instance } = await WebAssembly.instantiate(fs.readFileSync(new URL("../build/emu/orbit.wasm", import.meta.url)), {});
const ex = instance.exports;
ex._initialize?.();
ex.web_boot();
ex.web_test_still(1);                            // (the moon and the idle drift would make every screen differ)
const peak = (blocks) => {
  let p = 0;
  for (let b = 0; b < blocks; b++) {
    ex.web_render(128);
    const l = new Float32Array(ex.memory.buffer, ex.web_out_l(), 128);
    for (const x of l) p = Math.max(p, Math.abs(x));
  }
  return p;
};
assert.equal(peak(50), 0, "silent before any key");
{ // the start-up screen: there at power-on, changing, gone after its time; a key ends it at once
  const scr = () => crypto.createHash("sha1").update(new Uint8Array(ex.memory.buffer, ex.web_screen(), 240 * 240 * 2)).digest("hex");
  const a = scr(); const led0 = ex.web_lit_keys(); peak(100); const b = scr();
  assert.ok(ex.web_lit_keys() !== led0, "a light runs up the keys meanwhile");
  assert.notEqual(a, b, "the start-up screen moves");
  peak(700); const home1 = scr(); peak(60);
  assert.equal(scr(), home1, "after it: the HOME page, still");
  const three = (await WebAssembly.instantiate(fs.readFileSync(new URL("../build/emu/orbit.wasm", import.meta.url)), {})).instance.exports;
  three._initialize?.(); three.web_boot(); three.web_test_still(1);
  for (let k = 0; k < 60; k++) three.web_render(128);
  three.web_keys(1); for (let k = 0; k < 30; k++) three.web_render(128); three.web_keys(0);
  for (let k = 0; k < 900; k++) three.web_render(128);
  const h3 = crypto.createHash("sha1").update(new Uint8Array(three.memory.buffer, three.web_screen(), 240 * 240 * 2)).digest("hex");
  assert.equal(h3, home1, "a key during it: straight to HOME");
}
// the envelope dot (ENV's picture): one note, the selected operator: attack, then decay, then after the
// key is let go the release, each run from its start towards its end, and nothing once the note is over
{
  const trace = [];
  const step = (n) => { for (let k = 0; k < n; k++) { ex.web_render(128); const v = ex.web_test_env(); trace.push([v >> 8, v & 255]); } };
  peak(700);
  assert.equal(ex.web_test_env() >> 8, 4, "no note: no dot");
  ex.web_keys(1); step(120); ex.web_keys(0); step(1500);
  const stages = trace.map((t) => t[0]).filter((s, i, a) => i === 0 || s !== a[i - 1]);
  console.log("envelope stages:", stages.join(" > "));
  while (stages[0] === 4) stages.shift();          // (the panel is read every 15 ms: a few blocks before the note)
  assert.ok(stages[0] <= 1, "it starts in the attack (or, a fast attack over within a block, the decay)");
  assert.equal(stages.at(-1), 4, "it ends with no dot");
  assert.ok(stages.includes(3), "the release is shown");
  for (const st of [0, 1, 3]) {
    const pr = trace.filter((t) => t[0] === st).map((t) => t[1]);
    for (let i = 1; i < pr.length; i++) assert.ok(pr[i] >= pr[i - 1], `stage ${st}: the dot only moves forward`);
    if (st === 3) assert.ok(pr.at(-1) - pr[0] > 100, `the release runs along its segment (${pr[0]} .. ${pr.at(-1)})`);
  }
}
let worst = 0;
for (let v = 0; v < 128; v += 16) {
  ex.web_keys(0b10010001);                       // three keys
  const loud = peak(200);                        // ~0.6 s held
  ex.web_keys(0);
  peak(700);                                     // let it ring out
  console.log(`voice ${String(v + 1).padStart(3)}: peak ${loud.toFixed(3)}`);
  assert.ok(loud > 0.01, `voice ${v + 1} makes sound`);
  worst = Math.max(worst, loud);
  for (let k = 0; k < 16; k++) { ex.web_enc(2, 1); peak(8); }   // PRESETS: a voice a tick
}
assert.ok(worst < 0.98, "no clipping on three notes");
assert.ok(ex.web_screen_draws() > 10, "the screen is drawn");
const fb = new Uint16Array(ex.memory.buffer, ex.web_screen(), 240 * 240);
assert.ok(fb.some((p) => p !== 0), "the frame is not black");
// ALGORITHM and KNOB 1 change the picture
const shot = () => { peak(30); return crypto.createHash("sha1").update(new Uint8Array(ex.memory.buffer, ex.web_screen(), 240 * 240 * 2)).digest("hex"); };
const before = shot();
ex.web_enc(1, 1); shot(); ex.web_enc(1, 1);     // (two steps: PIANO 1's algorithm 5 and the next are wired alike)
const alg = shot();
assert.notEqual(alg, before, "ALGORITHM redraws the operators");
ex.web_enc(3, 5);
assert.notEqual(shot(), alg, "KNOB 1 changes TONE");
// twelve notes at once: all of them sound, and the output bends over instead of breaking up
{
  for (let k = 0; k < 200 && peak(50) > 0; k++);
  const sum = (mask) => { ex.web_keys(mask); let e = 0, p = 0; for (let b = 0; b < 120; b++) { ex.web_render(128); for (const x of new Float32Array(ex.memory.buffer, ex.web_out_l(), 128)) { e += x * x; p = Math.max(p, Math.abs(x)); } } ex.web_keys(0); peak(1500); return { e, p }; };
  const six = sum(0b101010101010), twelve = sum(0b111111111111);
  console.log(`six notes: peak ${six.p.toFixed(2)}; twelve: peak ${twelve.p.toFixed(2)}, ${(twelve.e / six.e).toFixed(2)}x the energy`);
  assert.ok(twelve.e > six.e * 1.3, "twelve keys sound fuller than six (more than six notes play)");
  assert.ok(twelve.p < 0.999, "and stay under full scale");
}
// ALGORITHM goes round: 32 steps either way come back to the same algorithm
{
  for (let k = 0; k < 200 && peak(50) > 0; k++);   // (the last voice played is still ringing: the ring would move)
  peak(260); const start = shot();
  for (let k = 0; k < 32; k++) { ex.web_enc(1, -1); peak(8); }
  peak(400); assert.equal(shot(), start, "32 steps down: round to where it was");
  for (let k = 0; k < 32; k++) { ex.web_enc(1, 1); peak(8); }
  peak(400); assert.equal(shot(), start, "32 steps up: round again");
}
// pages: EDIT and ENV open on their buttons and show something else
const B = { ENV: 2, EDIT: 4, HOME: 6 }, EN = { SELECT: 0, K1: 3, K3: 5 };
const tap = (b) => { ex.web_buttons(1 << b); peak(10); ex.web_buttons(0); return shot(); };
const calm = () => { peak(260); return shot(); };   // (a knob just turned stands out for 0.7 s: let that pass)
const hold = (b, ms) => { ex.web_buttons(1 << b); peak(Math.ceil(ms * 44.1 / 128)); ex.web_buttons(0); peak(10); };
const home = tap(B.HOME);
const edit = tap(B.EDIT);
assert.notEqual(edit, home, "EDIT is another page");
const env = tap(B.ENV);
assert.notEqual(env, edit, "ENV is another page");
ex.web_enc(EN.K1, 30);
const up = shot();
ex.web_enc(EN.K1, -60);
assert.ok(up !== env || shot() !== env, "ENV: KNOB 1 moves the attack");
tap(B.HOME);
// EDIT: SELECT picks the operator, KNOB 3 its level: all six at 0 is silence
tap(B.EDIT);
ex.web_enc(EN.SELECT, -1); for (let k = 0; k < 6; k++) { shot(); ex.web_enc(EN.SELECT, -1); }
for (let op = 0; op < 6; op++) {
  ex.web_enc(EN.K3, -99); shot();
  ex.web_enc(EN.SELECT, 1); shot();
}
peak(700);
ex.web_keys(0b10010001);
const muted = peak(200);
ex.web_keys(0);
assert.ok(muted < 0.01, `every operator's LEVEL at 0: next to silence (${muted.toFixed(4)})`);   // (level 0 is not minus infinity in this engine)
// LFO and GLO: their pages, and what GLO does to the pitch. The pitch is measured by counting the upward
// zero crossings of one held note over a second, on a fresh sound.
B.LFO = 3; B.GLO = 5; EN.K4 = 6; EN.PRESET = 2;
ex.web_enc(EN.PRESET, 1); shot();                 // a fresh sound: every operator back at its level
const lfo = tap(B.LFO);
ex.web_enc(EN.K3, 40);
assert.notEqual(shot(), lfo, "LFO: KNOB 3 shows the pitch depth");
const crossings = (key, blocks) => {
  let n = 0, last = 0;
  ex.web_keys(1 << key);
  for (let b = 0; b < blocks; b++) {
    ex.web_render(128);
    for (const x of new Float32Array(ex.memory.buffer, ex.web_out_l(), 128)) { if (last <= 0 && x > 0) n++; last = x; }
  }
  ex.web_keys(0); peak(700);
  return n;
};
ex.web_enc(EN.K3, -99); shot();                   // no vibrato while measuring
// a plain sine to measure: algorithm 32 (six carriers), operator 1 alone, ratio 1, no detune
for (let k = 0; k < 32; k++) { ex.web_enc(1, 1); peak(8); }
tap(B.EDIT);
for (let k = 0; k < 6; k++) { ex.web_enc(EN.SELECT, -1); peak(8); }
EN.K2 = 4;
ex.web_enc(EN.K1, -40); shot(); ex.web_enc(EN.K1, 1); ex.web_enc(EN.K2, -99); ex.web_enc(EN.K3, 99); ex.web_enc(EN.K4, -20); shot();
ex.web_enc(EN.K4, 7); shot();
for (let op = 1; op < 6; op++) { ex.web_enc(EN.SELECT, 1); shot(); ex.web_enc(EN.K3, -99); shot(); }
tap(B.GLO);
const mid = crossings(0, 345);
ex.web_enc(EN.K4, 12); shot();
const upper = crossings(0, 345);
ex.web_enc(EN.K4, -24); shot();
const lower = crossings(0, 345);
console.log(`transpose: ${lower} / ${mid} / ${upper} crossings a second`);
assert.ok(Math.abs(mid - 174.6) < 2, "the lowest key is F3");
assert.ok(Math.abs(upper / mid - 2) < 0.03 && Math.abs(mid / lower - 2) < 0.03, "TRANSP: an octave up and down");
ex.web_enc(EN.K4, 12); shot();
// GLIDE (KNOB 3): a note an octave above the last one starts low and arrives: fewer crossings than without
const high = crossings(12, 100);
ex.web_enc(EN.K3, 99); shot();
crossings(0, 60);
const gliding = crossings(12, 100);
console.log(`glide: ${gliding} crossings while arriving, ${high} without`);
assert.ok(gliding < high * 0.95, "GLIDE: the next note slides up to its pitch");
ex.web_enc(EN.K3, -99); shot();

// SEL on EDIT: an operator off; all six off is silence, exactly
B.SEL = 1; B.ARP = 8; B.SEQ = 9; B.PLAY = 10; B.REC = 11;
tap(B.EDIT);
for (let k = 0; k < 6; k++) { ex.web_enc(EN.SELECT, -1); peak(8); }
ex.web_enc(EN.K3, 99); shot();                    // (the measured sine: operator 1 back up)
ex.web_keys(1); const one = peak(100); ex.web_keys(0); peak(400);
assert.ok(one > 0.02, "one operator sounds");
tap(B.SEL);
ex.web_keys(1); const off = peak(100); ex.web_keys(0); peak(100);
assert.equal(off, 0, "SEL: the operator off is silence");
tap(B.SEL);
ex.web_keys(1); assert.ok(peak(100) > 0.02, "SEL again: back on"); ex.web_keys(0); peak(400);

// ARP: on with its button; three keys make a run of single notes; LATCH keeps it going; off with the button
const st = () => { const v = ex.web_test_play(); return { mode: v & 3, playing: (v >> 2) & 1, now: (v >> 4) & 255, keys: (v >> 12) & 255, rec: (v >> 20) & 1, hold: (v >> 21) & 3, cursor: v >> 24 }; };
tap(B.ARP);
assert.equal(st().mode, 1, "ARP: the arpeggiator is on");
assert.equal(peak(100), 0, "no key: nothing plays");
ex.web_keys(0b10010001);
const places = new Set();
let arpPeak = 0;
for (let k = 0; k < 120; k++) { arpPeak = Math.max(arpPeak, peak(4)); places.add(st().now); }
assert.equal(st().keys, 3, "three keys held");
{ // the key of the note it plays is lit: over a while, each of the three keys and no other
  const lit = new Set();
  ex.web_keys(0); ex.web_keys(0b10010001);
  for (let k = 0; k < 300; k++) { peak(2); const m = ex.web_lit_keys(); for (let b = 0; b < 27; b++) if (m >> b & 1) lit.add(b); }
  assert.deepEqual([...lit].sort((a, b) => a - b), [0, 4, 7], "the arpeggiator lights the key of each note it plays");
}
assert.ok(arpPeak > 0.02 && places.size === 3, `it steps through the three notes (${[...places]})`);
ex.web_keys(0); peak(700);
assert.equal(peak(50), 0, "keys up: it stops");
// HOLD (SEL): the keys collect notes one at a time, in the order pressed; a key again takes its note out;
// SEL again clears them
tap(B.SEL);
assert.equal(st().hold, 1, "SEL: HOLD on");
peak(10); assert.equal(ex.web_lit_buttons() >> B.SEL & 1, 1, "HOLD: the SEL light is on");
for (const key of [7, 0, 4]) { ex.web_keys(1 << key); peak(20); ex.web_keys(0); peak(20); }
assert.equal(st().keys, 3, "three keys pressed one after the other: three notes collected");
const order = [];
for (let k = 0; k < 400; k++) { peak(2); const n = st().now; if (order.at(-1) !== n) order.push(n); }
assert.deepEqual(order.slice(1, 7).join(""), order.slice(4, 10).join(""), "it goes round them");
assert.ok(peak(200) > 0.02, "and plays on with the keys up");
// PLAY / STOP stops the arpeggiator with its notes kept, and starts it again
tap(B.PLAY); peak(700);
assert.ok(peak(100) === 0 && st().keys === 3, "PLAY / STOP: the arpeggiator stops, its notes stay");
tap(B.PLAY);
assert.ok(peak(200) > 0.02, "PLAY / STOP again: it runs again");
ex.web_keys(1 << 0); peak(20); ex.web_keys(0); peak(20);
assert.equal(st().keys, 2, "a collected key pressed again: its note is out");
// SEL again: LOOP: the notes go on round, and the keys play over them without joining them
tap(B.SEL);
assert.ok(st().hold === 2 && st().keys === 2, "SEL again: LOOP, the notes stay");
assert.equal(ex.web_lit_buttons() >> B.SEL & 1, 0, "LOOP: the SEL light is off (the keys play again)");
{
  const lit = new Set();
  ex.web_keys(1 << 16);
  for (let k = 0; k < 200; k++) { peak(2); const m = ex.web_lit_keys(); for (let b = 0; b < 27; b++) if (m >> b & 1) lit.add(b); }
  assert.equal(st().keys, 2, "a key played over the loop does not join it");
  assert.deepEqual([...lit].sort((a, b) => a - b), [4, 7, 16], "the loop's notes and the key played light up");
  ex.web_keys(0);
  assert.ok(peak(300) > 0.02, "the key up: the loop goes on");
}
tap(B.SEL);
assert.equal(st().hold, 1, "SEL once more: HOLD again, to change the notes");
tap(B.SEL);
tap(B.HOME);
assert.ok(st().mode === 1 && peak(200) > 0.02, "another page: it goes on running");
tap(B.ARP);
assert.ok(st().mode === 1 && st().keys === 2, "ARP pressed: its page, still running");
hold(B.ARP, 900);
assert.ok(st().mode === 0 && st().hold === 0, "ARP held: off, and nothing held");
peak(700);
assert.equal(peak(50), 0, "and silent");
peak(700);
assert.equal(peak(50), 0, "and silent");

// SEQ: REC and four keys one after the other fill four steps; PLAY plays them round; PLAY stops
tap(B.SEQ);
assert.equal(st().mode, 2, "SEQ: the sequencer is on");
tap(B.REC);
for (const key of [0, 4, 7, 12]) { ex.web_keys(1 << key); peak(30); ex.web_keys(0); peak(30); }
assert.deepEqual([0, 1, 2, 3, 4].map((i) => ex.web_test_step(i)), [1, 1, 1, 1, 0], "four steps recorded");
assert.equal(st().cursor, 4, "the cursor moved on");
tap(B.REC);
peak(700);
assert.equal(peak(50), 0, "stopped: silent");
tap(B.PLAY);
const steps = new Set();
let seqPeak = 0;
for (let k = 0; k < 800; k++) { seqPeak = Math.max(seqPeak, peak(4)); steps.add(st().now); }
assert.ok(seqPeak > 0.02, "PLAY: it sounds");
assert.equal(steps.size, 16, "it goes round all sixteen steps");
{ // playing: the keys of the recorded notes light as they play (keys 0, 4, 7, 12 were recorded)
  const lit = new Set();
  for (let k = 0; k < 800; k++) { peak(2); const m = ex.web_lit_keys(); for (let b = 0; b < 27; b++) if (m >> b & 1) lit.add(b); }
  assert.deepEqual([...lit].sort((a, b) => a - b), [0, 4, 7, 12], "the sequencer lights the key of each note it plays");
}
tap(B.PLAY);
peak(700);
assert.equal(peak(50), 0, "PLAY again: stopped and silent");
tap(B.SEQ);
assert.equal(st().mode, 2, "SEQ pressed again: still on");
hold(B.SEQ, 900);
assert.equal(st().mode, 0, "SEQ held: off");

// FX: each effect alone, switched on with SEL, changes the sound and stays in range; DELAY and REVERB ring on
B.FX = 0;
ex.web_enc(EN.PRESET, 1); shot();                 // a fresh, full sound
const energy = (blocks) => { let e = 0, p = 0; for (let b = 0; b < blocks; b++) { ex.web_render(128); for (const x of new Float32Array(ex.memory.buffer, ex.web_out_l(), 128)) { e += x * x; p = Math.max(p, Math.abs(x)); } } return { e, p }; };
const hit = () => { ex.web_keys(0b10010001); const held = energy(120); ex.web_keys(0); peak(100); const tail = energy(150); peak(1500); return { held, tail }; };
tap(B.FX);
for (let k = 0; k < 6; k++) { ex.web_enc(EN.SELECT, -1); peak(8); }
const dry = hit();
const names = ["DIST", "FILTER", "PHASER", "CHORUS", "DELAY", "REVERB"];
for (let f = 0; f < 6; f++) {
  tap(B.SEL);
  const wet = hit();
  tap(B.SEL);
  console.log(`${names[f].padEnd(6)} held ${(wet.held.e / dry.held.e).toFixed(2)}x  tail ${(wet.tail.e / (dry.tail.e + 1e-9)).toFixed(2)}x  peak ${wet.held.p.toFixed(2)}`);
  assert.ok(Number.isFinite(wet.held.e) && wet.held.p < 0.99, `${names[f]}: in range`);
  assert.ok(Math.abs(wet.held.e / dry.held.e - 1) > 0.02 || Math.abs(wet.tail.e / (dry.tail.e + 1e-9) - 1) > 0.05, `${names[f]}: it changes the sound`);
  if (f >= 4) assert.ok(wet.tail.e > dry.tail.e * 1.5, `${names[f]}: it rings on after the keys are up`);
  ex.web_enc(EN.SELECT, 1); peak(8);
}
const again = hit();
assert.ok(Math.abs(again.held.e / dry.held.e - 1) < 0.05, "all off again: the dry sound");
// the FX light: on while any effect is on, on every page; FX held: all effects off
assert.equal(ex.web_lit_buttons() >> B.FX & 1, 1, "on the FX page its button is lit (the page)");
tap(B.HOME);
assert.equal(ex.web_lit_buttons() >> B.FX & 1, 0, "another page, no effect on: FX dark");
tap(B.FX); tap(B.SEL); ex.web_enc(EN.SELECT, -1); peak(8); tap(B.SEL); tap(B.HOME);
assert.equal(ex.web_lit_buttons() >> B.FX & 1, 1, "two effects on: FX lit on HOME too");
hold(B.FX, 900);
ex.web_keys(0b10010001); const cleared = energy(120); ex.web_keys(0); peak(1500);
assert.ok(Math.abs(cleared.e / dry.held.e - 1) < 0.05, "FX held: every effect off, the dry sound");
tap(B.HOME);
assert.equal(ex.web_lit_buttons() >> B.FX & 1, 0, "and FX dark again");

// OCT+ and OCT-: an octave up and down for the keys pressed after it, shown; both: the middle again
B.OCTDN = 12; B.OCTUP = 13;
for (let k = 0; k < 32; k++) { ex.web_enc(1, 1); peak(8); }   // the plain sine again: algorithm 32, operator 1 alone
tap(B.EDIT);
for (let k = 0; k < 6; k++) { ex.web_enc(EN.SELECT, -1); peak(8); }
ex.web_enc(EN.K1, -40); shot(); ex.web_enc(EN.K1, 1); ex.web_enc(EN.K2, -99); ex.web_enc(EN.K3, 99); ex.web_enc(EN.K4, -20); shot();
ex.web_enc(EN.K4, 7); shot();
for (let op = 1; op < 6; op++) { ex.web_enc(EN.SELECT, 1); shot(); ex.web_enc(EN.K3, -99); shot(); }
tap(B.HOME); peak(400);
const o0 = crossings(0, 345), quiet = shot();
const o1shot = tap(B.OCTUP);
assert.notEqual(o1shot, quiet, "OCT+: the screen shows the octave");
const o1 = crossings(0, 345);
tap(B.OCTDN); tap(B.OCTDN);
const om = crossings(0, 345);
ex.web_buttons(1 << B.OCTDN | 1 << B.OCTUP); peak(10); ex.web_buttons(0); peak(400);
const oz = crossings(0, 345);
console.log(`octave: ${om} / ${o0} / ${o1} crossings a second, both pressed: ${oz}`);
assert.ok(Math.abs(o1 / o0 - 2) < 0.03 && Math.abs(o0 / om - 2) < 0.03 && Math.abs(oz - o0) <= 1, "OCT+ / OCT-: an octave each; both: back");
{ // DIST on the plain sine: it flattens the wave (peak over RMS: 1.41 for a sine, towards 1 for a square)
  const crest = () => {
    let p = 0, e = 0, n = 0;
    ex.web_keys(1); peak(80);
    for (let b = 0; b < 100; b++) { ex.web_render(128); for (const x of new Float32Array(ex.memory.buffer, ex.web_out_l(), 128)) { p = Math.max(p, Math.abs(x)); e += x * x; n++; } }
    ex.web_keys(0); peak(700);
    return { crest: p / Math.sqrt(e / n), peak: p };
  };
  const clean = crest();
  tap(B.FX);
  for (let k = 0; k < 6; k++) { ex.web_enc(EN.SELECT, -1); peak(8); }
  ex.web_enc(EN.K1, 20); ex.web_enc(EN.K2, 40); shot();          // GAIN 60, TONE 100
  tap(B.SEL);
  const driven = crest();
  tap(B.SEL); ex.web_enc(EN.K1, -20); ex.web_enc(EN.K2, -40); shot(); tap(B.HOME);
  console.log(`distortion on a sine: crest ${clean.crest.toFixed(2)} -> ${driven.crest.toFixed(2)}, peak ${clean.peak.toFixed(2)} -> ${driven.peak.toFixed(2)}`);
  assert.ok(clean.crest > 1.35 && driven.crest < 1.2, "DIST squares a sine off");
  assert.ok(driven.peak > clean.peak && driven.peak < clean.peak * 4, "and it comes out louder than one note went in, not wildly");
}
{ // PHASER on the plain sine: as its notches sweep past the note, the note dips and comes back
  const levels = (key) => {
    const out = [];
    ex.web_keys(1 << key); peak(80);
    for (let w = 0; w < 80; w++) { let e = 0, n = 0; for (let b = 0; b < 17; b++) { ex.web_render(128); for (const x of new Float32Array(ex.memory.buffer, ex.web_out_l(), 128)) { e += x * x; n++; } } out.push(Math.sqrt(e / n)); }
    ex.web_keys(0); peak(700);
    return Math.min(...out) / Math.max(...out);
  };
  const steady = levels(12);
  tap(B.FX);
  for (let k = 0; k < 6; k++) { ex.web_enc(EN.SELECT, -1); peak(8); }
  ex.web_enc(EN.SELECT, 1); peak(8); ex.web_enc(EN.SELECT, 1); peak(8);
  ex.web_enc(EN.K1, 30); ex.web_enc(EN.K2, 40); ex.web_enc(EN.K3, 50); shot();   // RATE 60, DEPTH 100, MIX 100
  tap(B.SEL);
  const swept = levels(12);
  tap(B.SEL); ex.web_enc(EN.K1, -30); ex.web_enc(EN.K2, -40); ex.web_enc(EN.K3, -50); shot(); tap(B.HOME);
  console.log(`phaser on a sine: quietest / loudest moment ${steady.toFixed(2)} -> ${swept.toFixed(2)}`);
  assert.ok(steady > 0.7 && swept < steady / 2, "PHASER: its notch passes through the note");
  // FILTER: low pass far below the note takes it away, far above leaves it; high pass the other way round
  const level = (key) => { ex.web_keys(1 << key); peak(80); const p = peak(60); ex.web_keys(0); peak(700); return p; };
  const open = level(12);
  tap(B.FX);
  for (let k = 0; k < 6; k++) { ex.web_enc(EN.SELECT, -1); peak(8); }
  ex.web_enc(EN.SELECT, 1); peak(8);
  ex.web_enc(EN.K2, -70); ex.web_enc(EN.K3, -20); shot();        // low pass, CUTOFF at the bottom (100 Hz), no resonance
  tap(B.SEL);
  const lowShut = level(12);
  ex.web_enc(EN.K2, 99); shot();
  const lowOpen = level(12);
  ex.web_enc(EN.K1, 2); shot();                                   // high pass, CUTOFF at the top
  const highShut = level(12);
  ex.web_enc(EN.K2, -99); shot();
  const highOpen = level(12);
  tap(B.SEL); ex.web_enc(EN.K1, -2); ex.web_enc(EN.K2, 70); ex.web_enc(EN.K3, 20); shot();
  console.log(`filter on a 349 Hz sine: low pass ${(lowShut / open).toFixed(2)} shut, ${(lowOpen / open).toFixed(2)} open; high pass ${(highShut / open).toFixed(2)} shut, ${(highOpen / open).toFixed(2)} open`);
  assert.ok(lowShut < open * 0.3 && lowOpen > open * 0.8, "FILTER low pass: shut below the note, open above it");
  assert.ok(highShut < open * 0.3 && highOpen > open * 0.7, "FILTER high pass: the other way round");
  assert.ok(lowOpen < open * 1.3, "and wide open it is no louder than without (it used to ring out of control up there)");
  // CHORUS: the copy drifting against the note makes the level waver
  ex.web_enc(EN.SELECT, 1); peak(8); ex.web_enc(EN.SELECT, 1); peak(8);
  ex.web_enc(EN.K1, 40); ex.web_enc(EN.K2, 50); ex.web_enc(EN.K3, 50); shot();   // RATE 70, DEPTH 100, MIX 100
  tap(B.SEL);
  const wavering = levels(12);
  tap(B.SEL); ex.web_enc(EN.K1, -40); ex.web_enc(EN.K2, -50); ex.web_enc(EN.K3, -50); shot(); tap(B.HOME);
  console.log(`chorus on a sine: quietest / loudest moment ${steady.toFixed(2)} -> ${wavering.toFixed(2)}`);
  assert.ok(wavering < steady * 0.8, "CHORUS: the note wavers");
}
const running = (blocks) => { let n = 0, last = 0; for (let b = 0; b < blocks; b++) { ex.web_render(128); for (const x of new Float32Array(ex.memory.buffer, ex.web_out_l(), 128)) { if (last <= 0 && x > 0) n++; last = x; } } return n; };
// the octave moves a note that is held, without starting it again; letting go still ends it
{
  ex.web_keys(1); peak(100);
  const h0 = running(345);
  ex.web_buttons(1 << B.OCTUP | 0); peak(10); ex.web_buttons(0);
  const h1 = running(345);
  ex.web_buttons(1 << B.OCTDN); peak(10); ex.web_buttons(0);
  const h2 = running(345);
  ex.web_keys(0); peak(700);
  console.log(`held note: ${h0} crossings, after OCT+ ${h1}, after OCT- ${h2}`);
  assert.ok(Math.abs(h1 / h0 - 2) < 0.05 && Math.abs(h2 - h0) <= 2, "OCT+ / OCT- move the held note");
  assert.equal(peak(50), 0, "key up: the moved note ends");
}
// the octave moves what is already running: the latched arpeggiator, the playing sequencer
tap(B.ARP); tap(B.SEL);                           // HOLD, one note
ex.web_keys(1); peak(30); ex.web_keys(0); peak(200);
const a0 = running(690);
tap(B.OCTUP); peak(200);
const a1 = running(690);
tap(B.OCTDN); hold(B.ARP, 900); peak(700);
console.log(`arpeggiator running: ${a0} crossings, after OCT+ ${a1}`);
assert.ok(Math.abs(a1 / a0 - 2) < 0.1, "OCT+ moves the running arpeggiator an octave up");
tap(B.SEQ); tap(B.PLAY); peak(200);
const s0 = running(1380);
tap(B.OCTUP); peak(200);
const s1 = running(1380);
tap(B.OCTDN); tap(B.PLAY); hold(B.SEQ, 900); peak(700);
console.log(`sequencer playing: ${s0} crossings, after OCT+ ${s1}`);
assert.ok(s0 > 20 && Math.abs(s1 / s0 - 2) < 0.1, "OCT+ moves the playing sequencer an octave up");
ex.web_enc(EN.PRESET, 1); shot(); ex.web_enc(EN.PRESET, -1); shot();

// another sound chosen under held keys: the notes of the one before end (they are not carried into the new
// sound's wiring, which howls); the keys sound again when pressed again
{
  tap(B.HOME); ex.web_keys(0); peak(1500);
  ex.web_keys(0b10010001); const held = peak(200);
  assert.ok(held > 0.02, "a chord held sounds");
  ex.web_enc(EN.PRESET, 1); const during = peak(12);
  assert.ok(during <= held * 1.2, `choosing another sound: nothing louder than the chord (${during.toFixed(3)} / ${held.toFixed(3)})`);
  const after = peak(300);
  assert.ok(after < 0.002, `and the old notes are out, the keys still down (${after.toFixed(4)})`);
  ex.web_keys(0); peak(20); ex.web_keys(0b10010001);
  assert.ok(peak(200) > 0.02, "pressed again: the new sound");
  ex.web_keys(0); ex.web_enc(EN.PRESET, -1); peak(1500);
}

// the battery: its picture follows the level; running low is said once, large; a computer: green
{
  tap(B.HOME); peak(400);
  const full = calm();
  ex.web_test_battery(2, 0); const two = calm();
  ex.web_test_battery(1, 0); const one = calm();
  assert.ok(new Set([full, two, one]).size === 3, "three bars, two, one: three pictures");
  ex.web_test_battery(0, 0); const low = shot();
  assert.notEqual(low, one, "running low: said on the screen");
  peak(1100); const after = shot();
  assert.notEqual(after, low, "and gone again after a moment (the battery's picture goes on blinking)");
  ex.web_test_battery(0, 1); assert.notEqual(calm(), full, "a computer connected: its own picture");
  ex.web_test_battery(3, 0); assert.equal(calm(), full, "full again: as at the start");
}

// SAVE: 256 places. 1..128 the factory's, which stay; 129..256 yours. SAVE held asks where; PRESETS, with
// SAVE down, picks another of yours; letting go saves there and that is where we are
B.SAVE = 7;
{
  const slot = () => ex.web_test_slot() & 255, dst = () => ex.web_test_slot() >> 8 & 255;
  const asked = () => ex.web_test_slot() >> 16 & 1, mine = () => ex.web_test_slot() >> 17;
  const down = ms => { ex.web_buttons(1 << B.SAVE); peak(Math.ceil(ms * 44.1 / 128)); };
  const up = () => { ex.web_buttons(0); peak(10); };
  tap(B.HOME);
  const home = slot(), factory = calm();
  assert.ok(home < 128 && mine() === 0, "on a factory sound, none of yours yet");
  ex.web_enc(EN.K1, 20); ex.web_enc(EN.K2, -7);     // TONE +20, FEED 0
  const edited = calm();
  assert.notEqual(edited, factory, "the edit shows");
  ex.web_enc(EN.PRESET, 1); shot(); ex.web_enc(EN.PRESET, -1);
  assert.equal(calm(), factory, "not saved: another sound and back, the edit is gone");
  assert.equal(slot(), home, "(with none of yours, PRESETS stays among the factory's)");
  ex.web_enc(EN.K1, 20); ex.web_enc(EN.K2, -7); shot();
  assert.equal(ex.web_flash_writes_count(), 0, "nothing stored yet");
  hold(B.SAVE, 300);
  assert.equal(ex.web_flash_writes_count(), 0, "a short press of SAVE stores nothing");
  const before = shot();
  down(900);
  assert.ok(asked() && dst() === 128, "SAVE held on a factory sound: it asks, your first empty place (129)");
  assert.notEqual(shot(), before, "and says so on the screen");
  assert.equal(ex.web_flash_writes_count(), 0, "nothing stored while it asks");
  up();
  assert.equal(ex.web_flash_writes_count(), 2, "let go: stored (the settings' piece and the sound's)");
  assert.ok(slot() === 128 && mine() === 1, "and that is where we are: 129, the one of yours");
  assert.equal(ex.web_test_tone(128), 20, "the edit is in 129");
  assert.equal(ex.web_test_tone(home), 0, "the factory's sound is as it was");
  const name = i => String.fromCharCode(...Array.from({ length: 10 }, (_, k) => ex.web_test_name(i, k))).trimEnd();
  assert.ok(name(128).endsWith(" ALT") && name(128).startsWith(name(home).slice(0, 4)), `the copy is named after it, with "alt": ${name(home)} -> ${name(128)}`);
  assert.ok(!name(home).endsWith(" ALT"), "the factory's keeps its name");
  peak(400);                                        // ("SAVED" off the screen again)
  const saved = calm();
  ex.web_enc(EN.PRESET, 1); peak(12);
  assert.equal(slot(), 0, "PRESETS on from your last: round to 1 (the empty places are passed over)");
  ex.web_enc(EN.PRESET, -1); peak(12);
  assert.equal(slot(), 128, "and back");
  assert.equal(calm(), saved, "another sound and back: as saved");
  // SAVE on one of yours: the same place, unless PRESETS says another
  ex.web_enc(EN.K1, -30); peak(12);
  down(900); assert.equal(dst(), 128, "SAVE held on one of yours: that place");
  ex.web_enc(EN.PRESET, 1); peak(12); ex.web_enc(EN.PRESET, 1); peak(12);
  assert.equal(dst(), 130, "PRESETS with SAVE down: another of yours (131)");
  assert.equal(slot(), 128, "(the sound playing stays)");
  ex.web_enc(EN.PRESET, -1); peak(12); ex.web_enc(EN.PRESET, -1); peak(12); ex.web_enc(EN.PRESET, -1); peak(12);
  assert.equal(dst(), 127, "back past 129: 128, a factory place: any of the 256 can be chosen");
  ex.web_enc(EN.PRESET, 1); peak(12); ex.web_enc(EN.PRESET, 1); peak(12); ex.web_enc(EN.PRESET, 1); peak(12);
  up();
  assert.ok(slot() === 130 && mine() === 2, "saved to 131, and there now");
  assert.equal(ex.web_test_tone(130), -10, "131 holds the new edit");
  assert.equal(name(130), name(128), "a copy of a copy: one alt, not two");
  assert.equal(ex.web_test_tone(128), 20, "129 as it was");
  assert.equal(ex.web_test_tone(129), -128, "130 still empty");
  ex.web_enc(EN.PRESET, -1); peak(12);
  assert.equal(slot(), 128, "PRESETS back from 131: 129 (130 is empty)");
  ex.web_enc(EN.PRESET, 1); peak(400);
  const left = calm();

  const flash = new Uint8Array(ex.memory.buffer, ex.web_nor(), ex.web_nor_size()).slice();
  const wasm = fs.readFileSync(new URL("../build/emu/orbit.wasm", import.meta.url));
  const fresh = async () => { const e = (await WebAssembly.instantiate(wasm, {})).instance.exports; e._initialize?.(); return e; };
  const pic = e => crypto.createHash("sha1").update(new Uint8Array(e.memory.buffer, e.web_screen(), 240 * 240 * 2)).digest("hex");
  const two = await fresh();
  new Uint8Array(two.memory.buffer, two.web_nor(), two.web_nor_size()).set(flash);
  two.web_boot(); two.web_test_still(1);
  for (let k = 0; k < 900; k++) two.web_render(128);   // (past the start-up screen)
  assert.equal(two.web_test_slot() & 255, 130, "after a restart: where it was left");
  assert.equal(pic(two), left, "and as it was left");
  // SAVE held while switching on: the factory's sounds again, yours gone, and that is stored
  const four = await fresh();
  new Uint8Array(four.memory.buffer, four.web_nor(), four.web_nor_size()).set(flash);
  four.web_buttons(1 << B.SAVE); four.web_boot(); four.web_test_still(1);
  for (let k = 0; k < 620; k++) four.web_render(128);            // 1.8 s with SAVE down
  four.web_buttons(0);
  assert.equal(four.web_flash_writes_count(), 1, "the factory's sounds are stored");
  assert.equal(four.web_test_slot() >> 16, 0, "none of yours left, and SAVE asks nothing");
  for (let k = 0; k < 1200; k++) four.web_render(128);           // (the word in the footer goes)
  const five = await fresh();
  five.web_boot(); five.web_test_still(1);                       // an instrument that never stored anything
  for (let k = 0; k < 1820; k++) five.web_render(128);
  assert.equal(pic(four), pic(five), "and it shows what a new instrument shows");
  // what the version before kept (128 places, a saved sound in the factory's place: here 3 with TONE +20 and
  // 6 with FEED 0, left on 6): the changed sounds move to yours, the factory's are the factory's again
  const six = await fresh();
  new Uint8Array(six.memory.buffer, six.web_nor(), six.web_nor_size()).set(fs.readFileSync(new URL("fixtures/orb1-store.bin", import.meta.url)), 0x97000);
  six.web_boot(); six.web_test_still(1);
  for (let k = 0; k < 900; k++) six.web_render(128);
  assert.equal(six.web_test_slot() >> 17, 2, "the store before: its two saved sounds are yours now");
  assert.equal(six.web_test_slot() & 255, 129, "and it starts on the one it was left on (now 130)");
  assert.equal(six.web_test_tone(128), 20, "129: the first, with its edit");
  assert.equal(six.web_test_tone(2), 0, "3 is the factory's again");
  assert.equal(six.web_flash_writes_count(), 1, "carried over once, and stored");
  const seven = await fresh();
  new Uint8Array(seven.memory.buffer, seven.web_nor(), seven.web_nor_size()).set(new Uint8Array(six.memory.buffer, six.web_nor(), six.web_nor_size()));
  seven.web_boot(); seven.web_test_still(1);
  for (let k = 0; k < 900; k++) seven.web_render(128);
  assert.equal(seven.web_flash_writes_count(), 0, "the next start: nothing to carry over");
  assert.equal(pic(seven), pic(six), "and the same picture");
}

// sounds from a computer (tools/orbit_load.py): heard without storing; a load into your places only when
// every voice arrived and there is room; the factory's places never; wild values do no harm
{
  const wasm = fs.readFileSync(new URL("../build/emu/orbit.wasm", import.meta.url));
  const e = (await WebAssembly.instantiate(wasm, {})).instance.exports;
  e._initialize?.(); e.web_boot(); e.web_test_still(1);
  const run = n => { for (let k = 0; k < n; k++) e.web_render(128); };
  run(900);
  const slot = () => e.web_test_slot() & 255, mine = () => e.web_test_slot() >> 17;
  const sx = bytes => { new Uint8Array(e.memory.buffer, e.web_sysex_buf(), 640).set(bytes); e.web_sysex(bytes.length); run(12); };
  const HEAD = [0x7D, 0x6F, 0x72, 0x62];
  const voice = (name, fill) => {
    const v = new Array(128).fill(fill ?? 0);
    if (fill === undefined) {
      for (let k = 0; k < 6; k++) { v.splice(k * 17, 8, 99, 99, 99, 60, 99, 99, 99, 0); v[k * 17 + 14] = 90; v[k * 17 + 15] = 2; }
      v.splice(102, 8, 99, 99, 99, 99, 50, 50, 50, 50); v[110] = 31; v[117] = 24;
    }
    for (let k = 0; k < 10; k++) v[118 + k] = (name.padEnd(10))[k].charCodeAt(0);
    return v;
  };
  const cs = v => (-v.reduce((a, b) => a + b, 0)) & 127;
  let seq = 0;
  const begin = () => { seq = 0; sx([...HEAD, 0]); };
  const wait = (v, place) => { sx([...HEAD, 2, seq >> 7, seq & 127, ...(place === undefined ? [0x7F, 0x7F] : [place >> 7, place & 127]), ...v, cs(v)]); seq++; };
  const answer = () => Array.from(new Uint8Array(e.memory.buffer, e.web_sysex_reply(), e.web_sysex_reply_n()));
  const pic = () => crypto.createHash("sha1").update(new Uint8Array(e.memory.buffer, e.web_screen(), 240 * 240 * 2)).digest("hex");
  const a = voice("TEST A"), b = voice("TEST B"), wild = voice("WILD\x01\x7f", 127);

  { // ENV on a sound whose envelope has a bend (a DX7's two decay steps by way of a level between): DECAY and
    // SUSTAIN move it and keep the bend, also out to the end of their range and back
    const bent = voice("BENT");
    for (let k = 0; k < 6; k++) bent.splice(k * 17, 8, 99, 80, 30, 60, 99, 40, 70, 0);
    sx([...HEAD, 1, ...bent, cs(bent)]);
    const eg = () => Array.from({ length: 8 }, (_, k) => e.web_test_eg(k));
    e.web_buttons(1 << 2); run(12); e.web_buttons(0); run(12);            // ENV
    assert.deepEqual(eg(), [99, 80, 30, 60, 99, 40, 70, 0], "as it came");
    e.web_enc(4, 5); run(12);
    assert.deepEqual(eg(), [99, 75, 25, 60, 99, 40, 70, 0], "DECAY longer: both steps, the second still slower by as much");
    e.web_enc(5, 10); run(12);
    assert.deepEqual(eg(), [99, 75, 25, 60, 99, 50, 80, 0], "SUSTAIN up: the level between goes with it");
    e.web_enc(5, -99); run(12);
    assert.deepEqual(eg().slice(4), [99, 0, 0, 0], "down to nothing");
    e.web_enc(5, 70); run(12);
    assert.deepEqual(eg().slice(4), [99, 40, 70, 0], "and back: the bend is as the sound had it");
    e.web_enc(4, -5); run(12);
    e.web_buttons(1 << 6); run(12); e.web_buttons(0); run(300);         // HOME
  }
  const before = pic();
  sx([...HEAD, 1, ...a, cs(a)]);
  assert.notEqual(pic(), before, "a voice to hear: the screen says it came");
  assert.ok(slot() < 128 && mine() === 0 && e.web_flash_writes_count() === 0, "heard only: nothing stored, the place as it was");
  sx([...HEAD, 1, ...a, (cs(a) + 1) & 127]); // (a wrong check: ignored)

  begin(); wait(a); wait(b); sx([...HEAD, 3, 3]);
  assert.ok(mine() === 0 && e.web_flash_writes_count() === 0, "one voice short at the end: nothing changes");
  begin(); wait(a); wait(b); wait(wild); sx([...HEAD, 3, 3]);
  assert.deepEqual(answer(), [...HEAD, 0x7F, 3, 1, 0, 3, 1, 0, 1, 2], "and the answer says so: 3 loaded, places 129..131");
  assert.equal(mine(), 3, "three voices, all there: three of yours");
  begin(); wait(a); seq = 0; wait(a); assert.deepEqual(answer().slice(5, 9), [2, 1, 0, 1], "a voice sent twice: taken once, and answered");
  seq = 3; wait(b); assert.deepEqual(answer().slice(5, 9), [2, 0, 0, 1], "a voice out of turn: not taken");
  sx([...HEAD, 6]); assert.deepEqual(answer().slice(5, 11), [6, 1, 0, 3, 1, 0], "asked how things are: 3 of yours, playing 129");
  assert.equal(slot(), 128, "and the first of them plays (129)");
  assert.equal(e.web_flash_writes_count(), 1, "stored once");
  assert.equal(e.web_test_tone(0), 0, "the factory's first place is the factory's");
  e.web_enc(2, 1); run(12); e.web_enc(2, 1); run(12);
  assert.equal(slot(), 130, "the wild one is there too (131)");
  e.web_keys(0b10010001); run(700); e.web_keys(0); run(700);   // and playing it harms nothing
  e.web_enc(2, 1); run(12);
  assert.equal(slot(), 0, "after it: round to 1");
  begin(); wait(b, 129); sx([...HEAD, 3, 1]);
  assert.ok(mine() === 3 && slot() === 129, "a voice for a place by its number: there (130), in place of what was");
  { // a voice with the sound's own settings: TONE, the effects that are on, their values (out of range: brought in)
    const x = [64 + 20, 64, 64 - 10, 0b001100, ...Array(18).fill(40)]; x[4 + 2 * 3] = 14; x[4 + 5 * 3] = 9;
    begin(); sx([...HEAD, 7, 0, 0, 1, 3, ...a, cs(a), ...x, cs(x)]); sx([...HEAD, 3, 1]);
    assert.ok(e.web_test_tone(131) === 20 && (e.web_test_fx(131, 6) & 255) === 0b001100, "its TONE and its effects on (phaser, chorus)");
    assert.ok(e.web_test_fx(131, 6) >> 8 === 14 && e.web_test_fx(131, 15) >> 8 === 2, "their values, a type kept to 0..2");
    // a place read back (for a backup): what was put there, in the form it can be sent again
    sx([...HEAD, 8, 1, 3]);
    const kept = x.slice(); kept[4 + 1 * 3] = 2; kept[4 + 5 * 3] = 2;   // (FILTER's and REVERB's types: 0..2)
    assert.deepEqual(answer(), [...HEAD, 0x7E, 1, 3, 1, ...a, cs(a), ...kept, cs(kept)], "read back: the voice and its settings");
    sx([...HEAD, 8, 1, 100]); assert.deepEqual(answer(), [...HEAD, 0x7E, 1, 100, 0], "an empty place: said so");
    for (const k of [0, 37, 127]) {           // the factory's sounds too: read, sent to another place, read again: the same
      sx([...HEAD, 8, 0, k]); const got = answer();
      assert.ok(got.length === 160 && got[7] === 1, "a factory place read");
      begin(); sx([...HEAD, 7, 0, 0, 1, 90, ...got.slice(8)]); sx([...HEAD, 3, 1]);
      sx([...HEAD, 8, 1, 90]); assert.deepEqual(answer().slice(8), got.slice(8), `factory sound ${k + 1}: the same after the round`);
      sx([...HEAD, 5, 1, 90]);
    }
    begin(); sx([...HEAD, 7, 0, 0, 1, 3, ...a, cs(a), ...x, (cs(x) + 1) & 127]);
    assert.deepEqual(answer().slice(5, 9), [7, 0, 0, 0], "a wrong check on the settings: not taken");
    sx([...HEAD, 5, 1, 3]);
  }
  sx([...HEAD, 5, 1, 1]); assert.ok(mine() === 2 && slot() === 0, "a place emptied: one fewer, and off it");
  const nm = i => String.fromCharCode(...Array.from({ length: 10 }, (_, k) => e.web_test_name(i, k))).trimEnd();
  const was = nm(3);
  begin(); wait(b, 3); sx([...HEAD, 3, 1]);
  assert.ok(nm(3) === "TEST B" && slot() === 3 && mine() === 2, "a voice for one of the first 128: it replaces the factory's (4)");
  sx([...HEAD, 5, 0, 3]);
  assert.ok(nm(3) === was && mine() === 2, "that place as at first: the factory's sound is back");
  begin(); for (let k = 0; k < 127; k++) wait(a); sx([...HEAD, 3, 127]);
  assert.equal(mine(), 2, "more voices than empty places: nothing changes");
  begin(); for (let k = 0; k < 126; k++) wait(a); sx([...HEAD, 3, 126]);
  assert.equal(mine(), 128, "exactly as many as there is room: all 128 of yours full");
  { // the patterns and the instrument's settings: read, set, stored, and there after a restart (for a backup)
    const pat = []; for (let k = 0; k < 16; k++) pat.push(k % 3 ? 1 : 2, k === 5 ? 1 : 0, 48 + k, 60, 0, 0); pat.push(12);
    sx([...HEAD, 9, 3]); const empty = answer();
    assert.ok(empty.length === 6 + 97 + 1 && empty[5] === 3 && empty[6 + 96] === 16, "a pattern read: 97 bytes, a new one 16 steps long");
    sx([...HEAD, 0x0A, 3, ...pat, cs(pat)]); assert.deepEqual(answer().slice(5, 7), [0x0A, 1], "a pattern set: taken");
    sx([...HEAD, 9, 3]); assert.deepEqual(answer(), [...HEAD, 0x7D, 3, ...pat, cs(pat)], "and read back as it was set");
    sx([...HEAD, 0x0A, 3, ...pat, (cs(pat) + 1) & 127]); assert.deepEqual(answer().slice(5, 7), [0x0A, 0], "a wrong check: not taken");
    const set = [0, 96, 60, 30, 64 + 5, 2, 3, 4, 80, 1, 55], wild = [2, 127, 127, 127, 127, 2, 9, 4, 127, 1, 0];
    sx([...HEAD, 0x0A, 0x7F, ...set, cs(set)]); sx([...HEAD, 9, 0x7F]);
    assert.deepEqual(answer(), [...HEAD, 0x7D, 0x7F, ...set, cs(set)], "the settings set and read back: tempo 96, swing 60, glide 30, transp +5 ..");
    sx([...HEAD, 0x0A, 0x7F, ...wild, cs(wild)]); sx([...HEAD, 9, 0x7F]);
    const tame = answer().slice(6, 17);
    assert.deepEqual(tame, [2, 44, 75, 99, 64 + 12, 2, 4, 4, 100, 1, 20], "out of range: brought in (tempo 300, swing 75, glide 99, transp +12, gates 100 and 20)");
    sx([...HEAD, 0x0A, 0x7F, ...set, cs(set)]);
    const w0 = e.web_flash_writes_count();
    sx([...HEAD, 0x0B]); assert.ok(answer()[6] === 1 && e.web_flash_writes_count() === w0 + 1, "stored, once");
    const two = (await WebAssembly.instantiate(wasm, {})).instance.exports; two._initialize?.();
    new Uint8Array(two.memory.buffer, two.web_nor(), two.web_nor_size()).set(new Uint8Array(e.memory.buffer, e.web_nor(), e.web_nor_size()));
    two.web_boot(); two.web_test_still(1); for (let k = 0; k < 900; k++) two.web_render(128);
    const ask2 = m => { new Uint8Array(two.memory.buffer, two.web_sysex_buf(), 640).set(m); two.web_sysex(m.length); return Array.from(new Uint8Array(two.memory.buffer, two.web_sysex_reply(), two.web_sysex_reply_n())); };
    assert.deepEqual(ask2([...HEAD, 9, 3]).slice(6, 6 + 97), pat, "after a restart: the pattern");
    assert.deepEqual(ask2([...HEAD, 9, 0x7F]).slice(6, 17), set, "and the settings");
  }
  { // SAVE on a factory sound with no place of yours empty: nothing is saved until PRESETS has chosen a place
    const nm = i => String.fromCharCode(...Array.from({ length: 10 }, (_, k) => e.web_test_name(i, k))).trimEnd();
    while (slot() !== 5) { e.web_enc(2, slot() > 5 && slot() < 128 ? -1 : 1); run(12); }
    const writes = e.web_flash_writes_count(), five = nm(5), six = nm(6);
    e.web_enc(3, 9); run(12);
    e.web_buttons(1 << 7); run(320);
    const said = pic();
    assert.equal(e.web_test_slot() >> 16 & 1, 1, "it asks");
    e.web_buttons(0); run(12);
    assert.ok(e.web_flash_writes_count() === writes && slot() === 5 && nm(5) === five, "let go without choosing: nothing saved, nothing replaced");
    e.web_buttons(1 << 7); run(320); e.web_enc(2, 1); run(12);
    assert.notEqual(pic(), said, "PRESETS turned: the screen says where it will go");
    e.web_buttons(0); run(12);
    assert.ok(e.web_flash_writes_count() > writes && slot() === 6 && nm(6) !== six && nm(6).endsWith(" ALT"), "and letting go saves there (7)");
    assert.equal(nm(5), five, "the sound it came from is as it was");
  }
}

// MIDI out: a key sends its note on and off; a note that comes in over MIDI is not sent out again
{
  const n0 = ex.web_test_midi_count();
  ex.web_keys(1 << 3); peak(20);
  assert.equal(ex.web_test_midi_count(), n0 + 1, "a key down: one message out");
  assert.equal(ex.web_test_midi_last() >> 16, 0x90, "a note on");
  const note = ex.web_test_midi_last() >> 8 & 127;
  ex.web_keys(0); peak(20);
  assert.equal(ex.web_test_midi_last(), 0x80 << 16 | note << 8, "the key up: that note off");
  ex.web_midi(0x90, 60, 100); peak(20); ex.web_midi(0x80, 60, 0); peak(700);
  assert.equal(ex.web_test_midi_count(), n0 + 2, "a note in over MIDI is played, not sent back");
  tap(B.ARP); ex.web_keys(0b10001); peak(300); ex.web_keys(0); peak(700);
  assert.ok(ex.web_test_midi_count() > n0 + 6, "the arpeggiator's notes go out too");
  hold(B.ARP, 900);
}

// SEQ, stopped: REC held empties the pattern and leaves it ready to record
{
  tap(B.SEQ); tap(B.REC);
  for (const key of [2, 5]) { ex.web_keys(1 << key); peak(30); ex.web_keys(0); peak(30); }
  tap(B.REC);
  const filled = [0, 1, 2, 3, 4, 5, 6, 7].filter((i) => ex.web_test_step(i)).length;
  assert.ok(filled >= 2, "steps recorded");
  hold(B.REC, 900);
  assert.equal([...Array(16).keys()].filter((i) => ex.web_test_step(i)).length, 0, "REC held: the pattern is empty");
  assert.ok(st().rec === 1 && st().cursor === 0, "and it records again from the first step");
  tap(B.REC); hold(B.SEQ, 900);
}
// program change over MIDI picks a sound; bank select (CC 0 or CC 32) reaches the places 129..256
{
  const wasm = fs.readFileSync(new URL("../build/emu/orbit.wasm", import.meta.url));
  const e = (await WebAssembly.instantiate(wasm, {})).instance.exports;
  e._initialize?.(); e.web_boot(); e.web_test_still(1);
  const run = n => { for (let k = 0; k < n; k++) e.web_render(128); };
  run(900);
  const slot = () => e.web_test_slot() & 255;
  e.web_midi(0xC0, 5, 0); run(20);
  assert.equal(slot(), 5, "program change 5: place 6");
  e.web_midi(0xC3, 127, 0); run(20);
  assert.equal(slot(), 127, "on any channel: place 128");
  e.web_midi(0xB0, 0, 1); e.web_midi(0xC0, 0, 0); run(20);
  assert.equal(slot(), 127, "bank 1, an empty place: the sound stays");
  e.web_midi(0xB0, 0, 0); e.web_midi(0xC0, 9, 0); run(20);
  e.web_buttons(1 << 7); run(320);
  e.web_midi(0xC0, 20, 0); run(20);
  assert.equal(slot(), 9, "SAVE held: a program change waits its turn (ignored)");
  e.web_buttons(0); run(40);
  assert.equal(slot(), 128, "place 10 saved: its copy in place 129");
  e.web_midi(0xC0, 3, 0); run(20);
  assert.equal(slot(), 3, "bank 0 still: place 4");
  e.web_midi(0xB0, 0, 1); e.web_midi(0xB0, 32, 0); e.web_midi(0xC0, 0, 0); run(20);
  assert.equal(slot(), 128, "bank 1 as a DAW sends it, CC 0 = 1 then CC 32 = 0: place 129");
  e.web_midi(0xB0, 0, 0); e.web_midi(0xC0, 3, 0); run(20);
  e.web_midi(0xB0, 32, 1); e.web_midi(0xC0, 0, 0); run(20);
  assert.equal(slot(), 128, "bank 1 by CC 32, program 0: place 129");
  e.web_midi(0xC0, 1, 0); run(20);
  assert.equal(slot(), 128, "the bank is kept: program 1 is the empty place 130, the sound stays");
  e.web_midi(0xB0, 0, 2); e.web_midi(0xC0, 0, 0); run(20);
  assert.equal(slot(), 128, "a bank there is none of: the sound stays");
  e.web_midi(0xB0, 0, 0); e.web_midi(0xB0, 32, 0); e.web_midi(0xC0, 0, 0); run(20);
  assert.equal(slot(), 0, "bank 0 again: place 1");
  e.web_midi(0x90, 60, 100); run(20); e.web_midi(0x80, 60, 0); run(20);   // (notes as before)
  // PRESETS on the FM-1 sends the place out: bank select (CC 0, CC 32), then the program change
  const n0 = e.web_test_midi_count();
  e.web_midi(0xC0, 126, 0); run(20);
  assert.equal(e.web_test_midi_count(), n0, "a program change that came in is not sent back");
  e.web_enc(2, 1); run(20);
  assert.equal(slot(), 127, "PRESETS up: place 128");
  assert.equal(e.web_test_midi_count(), n0 + 3, "three messages out");
  assert.equal(e.web_test_midi_last(), 0xC0 << 16 | 127 << 8, "the last one: program 127");
  e.web_enc(2, 1); run(20);
  assert.equal(slot(), 128, "PRESETS up again: place 129");
  assert.equal(e.web_test_midi_last(), 0xC0 << 16 | 0 << 8, "program 0 (in bank 1)");
}
console.log("ok");
