// SPDX-License-Identifier: GPL-3.0-only
// Screenshots of the browser build without a browser:  node tests/shot.mjs OUTDIR
// Writes home.png, edit.png, env.png (2x), with a chord held so the pictures move.
import fs from "node:fs";
import zlib from "node:zlib";
const out = process.argv[2] ?? "build/shots";
fs.mkdirSync(out, { recursive: true });
const { instance } = await WebAssembly.instantiate(fs.readFileSync(new URL("../build/emu/orbit.wasm", import.meta.url)), {});
const ex = instance.exports;
ex._initialize?.();
ex.web_boot();
const run0 = (ms) => { for (let k = 0; k < ms * 44.1 / 128; k++) ex.web_render(128); };
const run = (ms) => { for (let k = 0; k < ms * 44.1 / 128; k++) ex.web_render(128); };
const crc = (b) => { let c, r = ~0; for (const x of b) { c = (r ^ x) & 255; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xEDB88320 : c >>> 1; r = (r >>> 8) ^ c; } return ~r >>> 0; };
const chunk = (t, d) => { const b = Buffer.alloc(12 + d.length); b.writeUInt32BE(d.length, 0); b.write(t, 4); d.copy(b, 8); b.writeUInt32BE(crc(b.subarray(4, 8 + d.length)), 8 + d.length); return b; };
const png = (name) => {
  const fb = new Uint16Array(ex.memory.buffer, ex.web_screen(), 240 * 240), S = 2, W = 240 * S;
  const raw = Buffer.alloc((W * 3 + 1) * W);
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) {
    const v = fb[(y / S | 0) * 240 + (x / S | 0)], p = ((v & 255) << 8) | (v >> 8), o = y * (W * 3 + 1) + 1 + x * 3;
    raw[o] = (p >> 11) * 255 / 31; raw[o + 1] = ((p >> 5) & 63) * 255 / 63; raw[o + 2] = (p & 31) * 255 / 31;
  }
  const ih = Buffer.alloc(13); ih.writeUInt32BE(W, 0); ih.writeUInt32BE(W, 4); ih[8] = 8; ih[9] = 2;
  fs.writeFileSync(`${out}/${name}.png`, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ih), chunk("IDAT", zlib.deflateSync(raw)), chunk("IEND", Buffer.alloc(0))]));
};
run0(350); png("splash1"); run0(500); png("splash2"); run0(900); png("splash3"); run0(900);
const held = (b) => { ex.web_buttons(1 << b); run(900); ex.web_buttons(0); run(60); };
const tap = (b) => { ex.web_buttons(1 << b); run(60); ex.web_buttons(0); run(60); };
ex.web_keys(0b10010001); run(250); png("home");
run(900); ex.web_keys(0); run(2500); png("ring_default"); ex.web_enc(5, 50); ex.web_enc(6, 50); run(900); png("ring_slow"); ex.web_enc(5, -100); ex.web_enc(6, -100); run(900); png("ring_fast"); ex.web_enc(5, 90); ex.web_enc(6, 20); run(900); png("ring_slowattack"); ex.web_enc(5, -80); ex.web_enc(6, 50); run(900); png("ring_slowrelease"); ex.web_enc(5, 40); ex.web_enc(6, -60); run(60); ex.web_keys(0b10010001); run(250);
ex.web_enc(5, 30); ex.web_enc(6, -20); run(60); png("home_knob");
tap(4); ex.web_enc(0, 1); run(40); ex.web_enc(0, 1); run(200); png("edit");
ex.web_enc(6, 3); ex.web_enc(4, 25); run(60); png("edit_knob");
ex.web_enc(5, -25); run(60); png("edit_level74"); ex.web_enc(5, -30); run(60); png("edit_level44"); ex.web_enc(5, 55); run(60);
tap(2); run(120); png("env");
ex.web_keys(0); run(150); png("env_release");
tap(3); ex.web_enc(5, 45); ex.web_enc(6, 20); run(300); png("lfo");
ex.web_enc(4, 4); run(200); png("lfo_sh");
tap(5); ex.web_enc(6, 20); run(330); png("glo");
tap(0); run(40);
for (const n of ["dist", "filter", "phaser", "chorus", "delay", "reverb"]) { tap(1); run(900); png("fx_" + n); ex.web_enc(0, 1); run(60); }
for (let k = 0; k < 6; k++) { ex.web_enc(0, -1); run(30); } png("fx_dist_off_again");
for (let k = 0; k < 6; k++) { tap(1); ex.web_enc(0, 1); run(30); }
tap(8); ex.web_keys(0b100010010001); run(700); png("arp"); ex.web_keys(0);
tap(1); for (const key of [7, 0, 12, 4, 9]) { ex.web_keys(1 << key); run(60); ex.web_keys(0); run(60); } run(500); png("arp_hold"); ex.web_enc(6, 35); run(120); png("arp_gate85"); ex.web_enc(6, -60); run(400); png("arp_gate25"); ex.web_enc(6, 25); tap(1); run(300); png("arp_loop"); held(8);
tap(9); tap(11);
for (const key of [0, 4, 7, 12, 7, 4]) { ex.web_keys(1 << key); run(50); ex.web_keys(0); run(50); }
tap(11); tap(10); run(900); png("seq"); tap(10); held(9);
ex.web_enc(1, 1); tap(3); run(100); png("popup");
tap(6); run(26000); png("home_idle");
tap(6); run(900); png("feed6a"); run(130); png("feed6b"); ex.web_enc(4, -4); run(900); png("feed2"); ex.web_enc(4, 5); run(900); png("feed7"); ex.web_enc(4, -1); run(60);
ex.web_enc(1, 1); run(45); png("alg_a"); run(60); png("alg_b"); run(90); png("alg_c"); run(600); png("alg_d"); ex.web_enc(1, -1); run(900);
// the ring over a note: a slow attack and a slow release on a held sound (ORGAN 1)
ex.web_enc(2, 1); run(60); tap(6); ex.web_enc(5, 60); ex.web_enc(6, 60); run(1500);
ex.web_keys(0b10010001); run(120); png("t_attack1"); run(500); png("t_attack2"); run(1500); png("t_held");
ex.web_keys(0); run(150); png("t_release1"); run(900); png("t_release2"); run(2500); png("t_release3");
tap(6); ex.web_test_battery(3, 0); run(300); png("batt3"); ex.web_test_battery(1, 0); run(300); png("batt1"); ex.web_test_battery(0, 0); run(200); png("batt0"); run(3100); png("batt0b"); ex.web_test_battery(0, 1); run(300); png("battusb"); ex.web_test_battery(3, 0);
// SAVE held: where the sound goes (an empty place of yours), saved, then held again there (over itself)
tap(6); ex.web_buttons(1 << 7); run(900); png("save_free"); ex.web_buttons(0); run(100); png("save_done"); run(1500); png("save_home129");
ex.web_buttons(1 << 7); run(900); png("save_over"); ex.web_enc(2, 1); run(60); png("save_next"); ex.web_enc(2, -1); run(60); ex.web_buttons(0); run(1500);
console.log("shots:", out);
