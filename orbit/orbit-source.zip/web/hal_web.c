/* SPDX-License-Identifier: GPL-3.0-only */
/* The firmware in the browser: src/ compiled to WebAssembly against a simulated FM-1, for the page and audio
 * worklet in web/emu (the export names are those of Felucca's emulator, which that page comes from): the clock
 * advances with the audio the worklet asks for, a block of audio is rendered whenever one is due, and the main
 * loop runs every 15 ms. */
#include <stdint.h>
#include <string.h>
#include "../src/hal.h"

static uint32_t web_now;                  /* ms */
static hal_input_t web_in = {0, 0, {0, 0, 0, 0, 0, 0, 0}, 700, 3, 0};
static uint16_t web_fb[SCR_W * SCR_H];    /* as the panel takes it: high byte first */
static uint32_t web_draws;

static void hal_input(hal_input_t *in)
{
    *in = web_in;
    memset(web_in.enc, 0, sizeof web_in.enc);
}
static uint32_t hal_ms(void) { return web_now; }
static uint32_t hal_lock(void) { return 0; }
static void hal_unlock(uint32_t s) { (void)s; }
static uint8_t nor[0x100000];            /* the flash as the page keeps it between visits (Felucca's worklet: */
#define STORE_AT 0x97000u                 /* the sectors of its storage areas that hold something) */
static uint32_t web_writes;
static int hal_store_read(void *dst, uint32_t from, uint32_t n)
{
    if (from > 0x40000u || n > 0x40000u - from)
        return -1;
    memcpy(dst, nor + STORE_AT + from, n);
    return 0;
}
static int hal_store_write(const void *base, uint32_t total, uint32_t from, uint32_t n)
{
    uint32_t s;
    if (total > 0x40000u || from > total || n > total - from)
        return -1;
    for (s = from / 4096u; s * 4096u < from + n; s++) {   /* the pieces the change touches, each as a whole */
        uint32_t k = total - s * 4096u < 4096u ? total - s * 4096u : 4096u;
        memset(nor + STORE_AT + s * 4096u, 0xFF, 4096);
        memcpy(nor + STORE_AT + s * 4096u, (const uint8_t *)base + s * 4096u, k);
    }
    web_writes++;
    return 0;
}
static uint32_t web_led_btn, web_led_key;
static void hal_leds(uint32_t buttons, uint32_t keys) { web_led_btn = buttons; web_led_key = keys; }
static uint32_t web_midi_n, web_midi_last;   /* what went out over MIDI: how many messages, the last one */
static void hal_midi_out(uint32_t status, uint32_t d1, uint32_t d2)
{
    web_midi_n++;
    web_midi_last = status << 16 | d1 << 8 | d2;
}
static uint32_t hal_load(void) { return 0; }
static void hal_present(const uint16_t *f)
{
    uint32_t i;
    for (i = 0; i < SCR_W * SCR_H; i++)
        web_fb[i] = (uint16_t)((f[i] >> 8) | (f[i] << 8));
    web_draws++;
}

#include "../src/orbit.c"

#define RING 4096u
static float ring[RING * 2];
static uint32_t ring_w, ring_r, due, booted, last_tick;

static void web_ms(void)
{
    web_now++;
    due += AUDIO_FS;
    while (due >= 1000u * AUDIO_BLOCK) {
        int32_t o[AUDIO_BLOCK * 2];
        uint32_t k;
        due -= 1000u * AUDIO_BLOCK;
        app_audio(o);
        for (k = 0; k < AUDIO_BLOCK; k++) {
            uint32_t i = (ring_w++ % RING) * 2u;
            ring[i] = (float)o[2u * k] / 8388608.0f;
            ring[i + 1] = (float)o[2u * k + 1u] / 8388608.0f;
        }
    }
    if (booted && web_now - last_tick >= 15u) {
        last_tick = web_now;
        app_tick();
    }
}

#define EXPORT __attribute__((used, visibility("default")))
static float out_l[1024], out_r[1024];
EXPORT float *web_out_l(void) { return out_l; }
EXPORT float *web_out_r(void) { return out_r; }
EXPORT void web_render(uint32_t n)
{
    uint32_t k;
    if (n > 1024u)
        n = 1024u;
    while (ring_w - ring_r < n)
        web_ms();
    for (k = 0; k < n; k++) {
        uint32_t i = (ring_r++ % RING) * 2u;
        out_l[k] = ring[i];
        out_r[k] = ring[i + 1];
    }
}
EXPORT void web_boot(void)
{
    if (!booted) {
        app_init();
        booted = 1;
    }
}
EXPORT void web_buttons(uint32_t labels) { web_in.buttons = labels & ((1u << NB) - 1u); }
EXPORT void web_keys(uint32_t mask) { web_in.keys = mask & ((1u << NKEYS) - 1u); }
EXPORT void web_enc(uint32_t role, int32_t n) { if (role < NE) web_in.enc[role] += n; }
EXPORT void web_master(uint32_t v) { web_in.master = v > 1023u ? 1023u : v; }
EXPORT uint32_t web_midi(uint32_t status, uint32_t d1, uint32_t d2)   /* MIDI in through the page */
{
    app_midi(status, d1, d2);
    return 1;
}
static uint8_t web_sx_out[200];
static uint32_t web_sx_out_n;
static void hal_sysex_out(const uint8_t *p, uint32_t n) { web_sx_out_n = n > 200u ? 200u : n; memcpy(web_sx_out, p, web_sx_out_n); }
static uint8_t web_sx[640];               /* a SysEx message from the page or a test: its bytes between F0 and F7 */
EXPORT uint8_t *web_sysex_buf(void) { return web_sx; }
EXPORT uint8_t *web_sysex_reply(void) { return web_sx_out; }   /* the last answer, and its length (then forgotten) */
EXPORT uint32_t web_sysex_reply_n(void) { uint32_t n = web_sx_out_n; web_sx_out_n = 0; return n; }
EXPORT void web_sysex(uint32_t n) { if (n <= sizeof web_sx) app_sysex(web_sx, n); }
EXPORT uint16_t *web_screen(void) { return web_fb; }
EXPORT uint32_t web_screen_draws(void) { return web_draws; }
EXPORT uint32_t web_now_ms(void) { return web_now; }
EXPORT uint32_t web_sample_rate(void) { return AUDIO_FS; }
EXPORT uint32_t web_playing(void) { return 0; }
/* for the tests: the selected operator's envelope dot (stage << 8 | progress) */
EXPORT uint32_t web_test_env(void) { return (uint32_t)syn.op_stage[5u - app.op] << 8 | syn.op_prog[5u - app.op]; }
/* for the tests: MIDI out (the count of messages, the last one) */
EXPORT uint32_t web_test_midi_count(void) { return web_midi_n; }
EXPORT uint32_t web_test_midi_last(void) { return web_midi_last; }
/* for the tests: the battery as the device would report it */
EXPORT void web_test_battery(uint32_t level, uint32_t usb) { web_in.battery = level > 3u ? 3u : level; web_in.usb_power = usb != 0u; }
/* for the tests: what moves by itself on the screen stands still, so that two screens can be compared */
EXPORT void web_test_still(uint32_t on) { app.still = (uint8_t)on; }
/* for the tests: the player (mode, playing, the step, the arpeggiator's keys, recording, the cursor) */
EXPORT uint32_t web_test_play(void)
{
    return play.mode | (uint32_t)play.playing << 2 | (uint32_t)play.now << 4 | (uint32_t)play.nkeys << 12 |
           (uint32_t)app.rec << 20 | (uint32_t)(play.hold & 3u) << 21 | (uint32_t)app.cursor << 24;
}
/* where it is (0..255) | the place SAVE points at << 8 | SAVE's question up << 16 | places of yours in use << 17 */
EXPORT uint32_t web_test_slot(void)
{
    uint32_t i, n = 0;
    for (i = STOCK_VOICES; i < NSLOTS; i++)
        n += store.sound[i].used;
    return app.voice | (uint32_t)app.save_dst << 8 | (uint32_t)app.save_armed << 16 | n << 17;
}
/* the picked operator's envelope: rate k (0..3), level k - 4 (4..7) */
EXPORT uint32_t web_test_eg(uint32_t k) { return op_bytes(app.base, app.op)[(k < 4u ? FP_R1 : FP_L1 - 4u) + k % 8u]; }
/* place i's effects: which are on | effect f's value j << 8 (f, j from k = f * 3 + j) */
EXPORT uint32_t web_test_fx(uint32_t i, uint32_t k) { return store.sound[i % NSLOTS].fx_on | (uint32_t)store.sound[i % NSLOTS].fx_p[k / 3u % FX_N][k % 3u] << 8; }
/* letter k of place i's name */
EXPORT uint32_t web_test_name(uint32_t i, uint32_t k) { return store.sound[i % NSLOTS].patch[FP_NAME + k % 10u]; }
/* place i's TONE (as kept), or -128 for an empty place */
EXPORT int32_t web_test_tone(uint32_t i) { return store.sound[i % NSLOTS].used ? store.sound[i % NSLOTS].tone : -128; }
EXPORT uint32_t web_test_step(uint32_t i) { return play.pat[play.pattern].step[i % SEQ_STEPS].n; }
/* what the page asks for besides: the flash, and LED levels this firmware does not use */
EXPORT uint8_t *web_nor(void) { return nor; }
EXPORT uint32_t web_nor_size(void) { return sizeof nor; }
EXPORT void web_nor_erase(void) { memset(nor, 0xFF, sizeof nor); }
EXPORT uint32_t web_flash_writes_count(void) { return web_writes; }
EXPORT uint32_t web_lit_buttons(void) { return web_led_btn | ((web_led_btn >> B_PLAY) & 1u) << 14; }
EXPORT uint32_t web_lit_keys(void) { return web_led_key; }
