# orbit

A small custom firmware for the M-VAVE FM-1: one six-operator FM sound, a page a button, four values in the
colours of KNOB 1..4 over one picture. Unofficial; not affiliated with M-VAVE or Teenage Engineering.

Status: everything runs in the browser emulator and is covered by `tests/smoke.mjs`. The device build
(`./build_fm1.sh`) runs on one FM-1 (older flash part, JEDEC 856014) since 2026-11-24: screen, sound, panel, LEDs,
saving, and loading sounds from a computer as its owner saw them. Other units are untested. See "The device"
below before installing it.

## The instrument

One button, one page; KNOB 1..4 are the four values on it, SELECT picks the operator, effect or step.

| Page | The four values |
| --- | --- |
| HOME | tone, feed, attack, release |
| EDIT | ratio, fine, level, detune of the picked operator |
| ENV | attack, decay, sustain, release of the picked operator |
| LFO | rate, shape, pitch, level |
| FX | three values of the picked effect: distortion, filter, phaser, chorus, delay, reverb |
| ARP | mode, octaves, rate, gate |
| SEQ | pattern, rate, gate, length; recorded by playing |
| GLO | tempo, swing, glide (above 0: one note at a time), transpose |

ALGORITHM turns through the 32 wirings, PRESETS through the sounds. The keys play at one strength, as the stock
firmware's do (the hardware has no velocity sensors); notes over USB-MIDI are played with their velocity.

Over USB-MIDI a program change picks a sound, on any channel: programs 0..127 are the places 1..128. Bank select
(CC 0 or CC 32) at 1 before it reaches the places 129..256, both at 0 go back; the bank is kept until the
next bank select. An empty place leaves the sound as it is.
Turning PRESETS sends the same out on channel 1: bank select (CC 0, CC 32), then the program change, so a
recording made on a computer brings the sound back when it is played.

## Sounds

256 places. 1..128 start as the stock factory bank, 129..256 are empty until a sound is put there; PRESETS
passes over empty places. Any of the 256 can be replaced.

- SAVE held: the screen says where the sound will go. A sound of yours goes to its own place, a factory sound to
  your first empty place; PRESETS, with SAVE still down, picks any other. Letting go saves. A copy in another
  place gets "alt" after its name. With no place empty, a factory sound is saved only once PRESETS has chosen.
- A sound is the DX7 voice plus orbit's own: tone, attack, release, and the six effects with their values.
- SAVE held while switching on: everything back to the factory's (your places empty, no patterns).

### From a computer

`tools/orbit_load.py` (Python 3 with `mido` and `python-rtmidi`) talks to the FM-1 over USB. Sounds come from
DX7 files: 32-voice cartridges (`.syx`, 4104 bytes), several in one file, or single voices.

```
orbit_load.py BANK.syx --list            the sounds in a file
orbit_load.py BANK.syx --hear 7          play one on the FM-1 without storing it (SAVE keeps it)
orbit_load.py BANK.syx                   all of them into the next empty places
orbit_load.py BANK.syx --only 1,5,9-12   only these
orbit_load.py BANK.syx --to 161          into 161 and on, replacing what is there
orbit_load.py --set SET.json             sounds with effects and settings (the format: `orbit_load.py --help`)
orbit_load.py --rename 129 "MY PAD"      another name for a place's sound
orbit_load.py --clear 129-160            places as they were at first (1..128: the factory's sound again)
orbit_load.py --status                   how many places are in use
orbit_load.py --backup FILE.json         all 256 sounds, the 16 patterns and the settings into a file
orbit_load.py --restore FILE.json        a backup back onto the FM-1
```

Imported DX7 sounds arrive without effects (a DX7 file has none). The firmware answers every message, so the
command sends a lost one again and says itself whether a load is in; a load counts only when every voice
arrived. The messages are SysEx under the non-commercial id (`F0 7D 'o' 'r' 'b' ..`), described in `src/app.c`
above `app_sysex`. No DX7 sounds are part of this repository beyond the stock bank.

## Layout

| Path | What |
| --- | --- |
| `src/hal.h` | What the firmware asks of the machine: input, clock, screen, audio |
| `src/synth.c` | Voices, notes and the patch on top of the FM core |
| `src/gfx.c` | Drawing into one full frame: lines, circles, text |
| `src/app.c` | The loop: read the panel, play, draw the page |
| `web/hal_web.c` | The browser backend |
| `web/emu` | The page and its audio worklet (from Felucca's emulator page, GPL-3.0) |
| `tools/site.sh` | The page for a web site, with a zip of this version's source beside it (`?embed`: inside another page) |
| `fm1/hal_fm1.c`, `fm1/app.ld` | The device backend on felucca-bsp (MPL-2.0), and the memory layout |
| `src/play.c`, `src/fx.c` | The clock, arpeggiator and sequencer; the six effects |
| `tools/check_fm1.py` | Checks on the device build that need no device |
| `tools/orbit_load.py` | Sounds, sets, names and backups between a computer and the FM-1 |
| `tools/` | Generators: the font, the factory voices |
| `tests/smoke.mjs` | Boots the browser build, plays voices, checks sound and screen |
| `tests/fixtures/` | A store written by the layout before, for the test that carries saved sounds over |
| `tests/shot.mjs` | Renders the pages to PNG files without a browser |
| `third_party/felucca` | The FM core (`fm6_core.c`, Apache-2.0, a C port of msfa) and its table generators |
| `third_party/mvave` | The stock FM-1 V15 factory bank (Apache-2.0, from M-VAVE's fm1_open) |

## Build and run (browser)

Needs Emscripten and a Python 3 with Pillow.

```
PYTHON=../.venv/bin/python ./build_web.sh
node tests/smoke.mjs
python3 -m http.server 8732 --directory build/emu
```

## The device

```
PYTHON=../.venv/bin/python ./build_fm1.sh      # -> build/fm1/orbit.fwsc
```

Needs, besides the above: Docker (the JieLi toolchain is Linux x86-64), the JieLi toolchain and AC79 SDK as
Felucca's `BUILDING.md` describes, and a Felucca checkout built once (its hardware layer `firmware/bsp` and its
update loader `build/loader/ota.bin` are used).

What is known and what is not:

- Built and checked without a device: the image fits (about 101 KB of 581 KB flash, 296 KB of 432 KB RAM), starts
  with the entry stub, the RAM-run flash code calls nothing, and none of our own code has a 64-bit multiply
  beside 16-bit loads (felucca-bsp `docs/CPU.md`). The FM core has that pattern, as it does in Felucca's own firmware.
- Seen on one unit: it boots, draws, reads the panel, plays, lights its LEDs, saves, and takes and gives sounds
  over USB (a backup has been read from it; a restore has only run in the emulator); the button and encoder
  numbering (Felucca's default table) was right there. Twelve notes with delay, reverb and chorus on take about
  70 % of the processor (GLO shows the load); above 85 % the firmware lets fewer notes sound. Not yet tried: a
  unit with the newer flash part (UC25HQ80).
- The safety net is felucca-bsp's: two boots in a row that do not live two seconds end in the chip's update
  mode (UBOOT); OCT- and OCT+ held five seconds go there too; the update entry answers the installer over USB-MIDI.
  From UBOOT, felucca-bsp's `tools/fm1_rescue.py` writes M-VAVE's stock firmware back from a Mac; its current
  version accepts both flash parts (older copies only the older one).

Before the first install on a unit: install Felucca's release, enter UBOOT from it (OCT- and OCT+ held) and run
the rescue tool without `--write`: it names the flash part and saves a backup, and shows that the way out works
on that unit. Install with felucca-bsp's `tools/fm1_install.py build/fm1/orbit.fwsc`.

## Licence

GPL-3.0-only (`LICENSE`); `fm1/hal_fm1.c` and `fm1/app.ld` are MPL-2.0 (they follow felucca-bsp's example).
Third-party parts keep their own licences: see `third_party/licenses/`,
`assets/OFL-SpaceMono.txt` (Space Mono).
