#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# The firmware for the FM-1:  ./build_fm1.sh  ->  build/fm1/orbit.bin (the app) and build/fm1/orbit.fwsc (the
# installable package). Read README.md (The device) before installing it on a unit.
#   PYTHON           a python3 with Pillow                  default: python3
#   FELUCCA          a Felucca checkout, built once          default: ../Felucca
#                    (its hardware layer firmware/bsp, and its update loader build/loader/ota.bin)
#   JIELI_TOOLCHAIN  JieLi's Linux toolchain                 default: ~/.jieli/toolchain
#   AC79_SDK         JieLi's AC79 SDK (three files of it)    default: ~/fw-AC79_AIoT_SDK
# The toolchain is Linux x86-64: elsewhere it runs in a Docker container (as Felucca's build does).
set -e
cd "$(dirname "$0")"
HERE="$(pwd)"
PY="${PYTHON:-python3}"
FELUCCA="$(cd "${FELUCCA:-../Felucca}" && pwd)"
TC="${JIELI_TOOLCHAIN:-$HOME/.jieli/toolchain}"
TC="$(cd "$TC" && pwd -P)"
export AC79_SDK="${AC79_SDK:-$HOME/fw-AC79_AIoT_SDK}"
BSP="$FELUCCA/firmware/bsp"
ID="${ORBIT_ID:-FM-1_1310}"
[ -f "$BSP/chip/crt0.S" ] || { echo "build_fm1: no hardware layer at $BSP (git submodule update --init in Felucca)"; exit 1; }
[ -x "$TC/pi32v2/bin/clang" ] || { echo "build_fm1: no toolchain at $TC"; exit 1; }
[ -f "$FELUCCA/build/loader/ota.bin" ] || { echo "build_fm1: no update loader: run ./build.sh in $FELUCCA once"; exit 1; }
OUT=build/fm1
mkdir -p build/gen "$OUT"
"$PY" third_party/felucca/tools/gen_tables.py build/gen/tables.h >/dev/null
"$PY" tools/gen_voices.py third_party/mvave/fm_factory.inc build/gen/voices.h >/dev/null
"$PY" tools/gen_font.py assets/SpaceMono-Regular.ttf build/gen/fonts.h s:12:400 m:17:400 l:30:400 >/dev/null
if [ "$(uname -s)" = Linux ] && [ "$(uname -m)" = x86_64 ]; then
    tc() { tool="$1"; shift; "$TC/$tool" "$@"; }
    W="$HERE"; B="$BSP"
else
    docker info >/dev/null 2>&1 || { echo "build_fm1: Docker is not running (colima start)"; exit 1; }
    tc() { tool="$1"; shift; docker run --rm --platform linux/amd64 -v "$HERE:/work" -v "$BSP:/bsp:ro" -v "$TC:/opt/jieli:ro" \
               -w /work debian:bookworm-slim "/opt/jieli/$tool" "$@"; }
    W=/work; B=/bsp
fi
CC="pi32v2/bin/clang"
for s in crt0 fm1_vec fm1_isr; do
    tc $CC -target pi32v2 -c "$B/chip/$s.S" -o "$W/$OUT/$s.o"
done
tc $CC -target pi32v2 -Os -ffunction-sections -fno-builtin -Wall -Wno-unused-function -Wno-unused-const-variable \
    "-DFELUCCA_ID=\"$ID\"" -I"$B/chip" -I"$B/boards/fm1" -I"$W/build/gen" -I"$W/src" \
    -c "$W/fm1/hal_fm1.c" -o "$W/$OUT/orbit.o"
tc pi32v2/bin/ld -T "$W/fm1/app.ld" "$W/$OUT/crt0.o" "$W/$OUT/fm1_vec.o" "$W/$OUT/fm1_isr.o" "$W/$OUT/orbit.o" -o "$W/$OUT/orbit.elf"
for sec in text data ram_text; do
    tc common/bin/objcopy -O binary -j .$sec "$W/$OUT/orbit.elf" "$W/$OUT/$sec.bin"
done
tc common/bin/objdump -t "$W/$OUT/orbit.elf" > "$OUT/orbit.sym"
tc common/bin/objdump -d "$W/$OUT/orbit.elf" > "$OUT/orbit.dis"
"$PY" - "$OUT" <<'PY'
import re, sys
out = sys.argv[1]
syms = open(f"{out}/orbit.sym").read()
def sym(n): return int(re.search(r"^([0-9a-f]+) .*\s" + n + r"$", syms, re.M).group(1), 16)
assert sym("_start") == 0x02000120, hex(sym("_start"))
img = bytearray(open(f"{out}/text.bin", "rb").read())
for at, name in sorted([(sym("_rt_load"), "ram_text.bin"), (sym("_data_load"), "data.bin")]):
    part = open(f"{out}/{name}", "rb").read()
    if part:
        assert at - 0x02000120 >= len(img), "sections overlap"
        img += b"\xff" * (at - 0x02000120 - len(img)) + part
img += b"\xff" * (-len(img) % 4)
open(f"{out}/orbit.bin", "wb").write(img)
ram = sym("_bss_end") - 0x01C08000
print(f"orbit.bin: {len(img)} bytes of 581564 (flash); RAM: {ram} bytes of 442368")
assert len(img) <= 0x8DFBC and ram <= 432 * 1024
PY
"$PY" tools/check_fm1.py "$OUT"                  # what can be checked without a device
"$PY" "$BSP/tools/fm1pkg.py" "$OUT/orbit.bin" "$FELUCCA/build/loader/ota.bin" "$OUT/orbit.fwsc" --product "$ID"
echo "build_fm1: $OUT/orbit.fwsc (identity $ID)"
