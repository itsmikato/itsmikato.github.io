/* SPDX-License-Identifier: MPL-2.0 */
/* The firmware on the M-VAVE FM-1, through felucca-bsp (MPL-2.0). The start-up, the boot guard, the update
 * entry and the screen's commands follow that repository's hardware test (examples/hwtest/hwtest.c,
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments), the audio interrupt its
 * boards/fm1/fm1_audio.h. Runs on one FM-1 (2026-11-24); saving there is untried.
 *
 *   screen   the app draws whole frames; only the bands of 8 rows that changed are sent
 *   panel    buttons and encoders by printed label (the matrix ids: Felucca's panel.c defaults)
 *   audio    ALNK0, two halves of HALF_FRAMES; the interrupt renders the free half, a block at a time
 *   clock    TIMER5 at 10 kHz: the key scan, the milliseconds, USB
 *   store    the flash from STORE_AT, erased and written a sector at a time with the audio silenced
 *   safety   two boots in a row that do not live 2 s end in UBOOT; OCT- and OCT+ held 5 s: UBOOT; the
 *            installer's update over USB-MIDI (ota.c) replaces the firmware like any other */
#include <stdint.h>
#define ORBIT_FREESTANDING 1
#define FELUCCA_CDC 0
#define FELUCCA_UAC 0
#define FELUCCA_OTA 1                     /* the update entry */
#ifndef FELUCCA_ID
#define FELUCCA_ID "FM-1_1310"            /* the identity the installer sees, == the package's */
#endif
#define FELUCCA_USB_PRODUCT "orbit"      /* the name a computer shows (usb.c) */
#define RING_PUBLISH() __asm__ volatile("" ::: "memory")
#include "fm1_time.h"
#include "fm1_sys.h"
#include "fm1_irq.h"
#include "fm1_guard.h"
#include "fm1_timer.h"
#include "fm1_input.h"
#include "fm1_audio.h"
#include "fm1_adc.h"
#include "fm1_lcd_hw.h"
#include "fm1_flash.h"
#include "libc.c"
#include "usb.c"
#include "ota.c"
#include "../src/hal.h"

extern uint32_t _data_start[], _data_end[], _data_load[], _bss_start[], _bss_end[];
extern uint32_t _rt_start[], _rt_end[], _rt_load[];   /* code that runs from RAM: the flash driver */

static volatile struct { uint32_t magic, pending, failed; } guard __attribute__((section(".noinit")));
static uint8_t flash_ok;
static volatile uint32_t audio_late;

/* ------------------------------------------------------------- clock --- */
void fm1_timer5_irq(void)                 /* 10 kHz: key scan, ms, USB at 2 kHz */
{
    static uint32_t sub, last, acc;
    uint32_t t = fm1_ticks();
    fm1_timer5_ack();
    fm1_input_tick();
    acc += t - last;
    last = t;
    while (acc >= 1000u * FM1_TICKS_PER_US) {
        acc -= 1000u * FM1_TICKS_PER_US;
        fm1_ms++;
    }
    if (++sub == 5u) {
        sub = 0;
        usb_poll();
    }
}
extern void isr_timer5(void);
static uint32_t hal_ms(void) { return fm1_ms; }
static uint32_t hal_lock(void) { return irq_save(); }
static void hal_unlock(uint32_t s) { irq_restore(s); }

/* ------------------------------------------------------------ screen --- */
#define BAND 8u                           /* rows a transfer */
static uint16_t band_px[SCR_W * BAND];    /* as the panel takes it: high byte first */
static uint32_t band_sum[SCR_H / BAND];
static uint8_t lcd_small[4];

static void lcd_cmd(uint8_t c, const uint8_t *d, uint32_t n)
{
    uint32_t i;
    fm1_lcd_send_cmd(c);
    fm1_lcd_wait();
    fm1_lcd_deselect();
    if (!n)
        return;
    for (i = 0; i < n; i++)
        lcd_small[i] = d[i];
    fm1_lcd_send_data(lcd_small, n);
    fm1_lcd_wait();
    fm1_lcd_deselect();
}
static void lcd_rows(uint32_t y, uint32_t h, const uint16_t *px)   /* h full rows from y */
{
    uint8_t a[4] = {0, 0, 0, SCR_W - 1u};
    lcd_cmd(0x2A, a, 4);
    a[1] = (uint8_t)y;
    a[3] = (uint8_t)(y + h - 1u);
    lcd_cmd(0x2B, a, 4);
    lcd_cmd(0x2C, 0, 0);
    fm1_lcd_send_data(px, SCR_W * h * 2u);
    fm1_lcd_wait();
    fm1_lcd_deselect();
}
static void lcd_fill_rows(uint32_t y, uint32_t h, uint16_t rgb)
{
    uint32_t i, k;
    for (i = 0; i < SCR_W * BAND; i++)
        band_px[i] = (uint16_t)((rgb >> 8) | (rgb << 8));
    for (; h; y += k, h -= k) {
        k = h > BAND ? BAND : h;
        lcd_rows(y, k, band_px);
    }
    for (i = 0; i < SCR_H / BAND; i++)
        band_sum[i] = 0xFFFFFFFFu;        /* (hal_present sends everything again) */
}
static void lcd_init(void)
{
    static const uint8_t colmod = 0x55, madctl = 0x00;
    fm1_lcd_hw_init();
    fm1_delay_ms(50);
    lcd_cmd(0x01, 0, 0);                  /* SWRESET */
    fm1_delay_ms(150);
    lcd_cmd(0x11, 0, 0);                  /* SLPOUT */
    fm1_delay_ms(120);
    lcd_cmd(0x3A, &colmod, 1);            /* RGB565 */
    lcd_cmd(0x36, &madctl, 1);            /* top-left origin, RGB */
    lcd_cmd(0x21, 0, 0);                  /* INVON: this panel is IPS */
    lcd_cmd(0x13, 0, 0);                  /* NORON */
    fm1_lcd_baud(4);
    lcd_fill_rows(0, SCR_H, 0);
    lcd_cmd(0x29, 0, 0);                  /* DISPON */
}
static void hal_present(const uint16_t *f)
{
    uint32_t b, i;
    for (b = 0; b < SCR_H / BAND; b++) {
        const uint16_t *src = f + b * BAND * SCR_W;
        uint32_t sum = 2166136261u;
        for (i = 0; i < SCR_W * BAND; i++)
            sum = (sum ^ src[i]) * 16777619u;
        if (sum == band_sum[b])
            continue;
        band_sum[b] = sum;
        for (i = 0; i < SCR_W * BAND; i++)
            band_px[i] = (uint16_t)((src[i] >> 8) | (src[i] << 8));
        lcd_rows(b * BAND, BAND, band_px);
    }
}

/* ------------------------------------------------------------- panel --- */
static const uint8_t BTN_ID[NB] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 1};   /* the matrix button a label is */
static const uint8_t ENC_ID[NE] = {0, 1, 6, 2, 3, 4, 5};                            /* the matrix encoder a role is */
static int32_t master_knob = 512 * 16;
static int32_t batt_raw;                  /* the battery's reading (ADC), smoothed; 0: not read yet */
static uint32_t batt_level = 3;
/* the reading as a level: M-VAVE's own three thresholds (531, 561, 591), each with a little slack so that a
 * reading on a threshold does not flicker between two levels */
static void batt_update(int32_t raw)
{
    static const int16_t T[3] = {531, 561, 591};
    if (raw <= 0)
        return;
    batt_raw = batt_raw ? batt_raw + (raw - batt_raw) / 16 : raw;
    while (batt_level < 3u && batt_raw >= T[batt_level] + 4)
        batt_level++;
    while (batt_level > 0u && batt_raw < T[batt_level - 1u] - 4)
        batt_level--;
}
static void hal_input(hal_input_t *in)
{
    uint32_t i, raw = fm1_in.buttons;
    in->keys = fm1_in.notes & ((1u << NKEYS) - 1u);
    in->buttons = 0;
    for (i = 0; i < NB; i++)
        in->buttons |= ((raw >> BTN_ID[i]) & 1u) << i;
    for (i = 0; i < NE; i++)
        in->enc[i] = fm1_enc_take(ENC_ID[i]);
    in->master = (uint32_t)(master_knob / 16);
    in->battery = batt_level;
    in->usb_power = usb.config && !usb.suspended;   /* (a charger without a computer cannot be told from the battery) */
}
static void hal_leds(uint32_t buttons, uint32_t keys)
{
    uint32_t i;
    for (i = 0; i < NB; i++)
        fm1_led_key(BTN_ID[i], (buttons >> i) & 1u);
    for (i = 0; i < NKEYS; i++)
        fm1_led_key(14u + i, (keys >> i) & 1u);
}

/* ------------------------------------------------------------- audio --- */
static volatile uint32_t load_avg_q4, load_peak, load_peak_ms;   /* percent of a half buffer's time the render took */
static uint32_t hal_load(void) { return ((load_avg_q4 + 8u) / 16u > 255u ? 255u : (load_avg_q4 + 8u) / 16u) | (load_peak > 255u ? 255u : load_peak) << 8; }
static void hal_sysex_out(const uint8_t *p, uint32_t n)   /* (dropped with no host) */
{
    static uint8_t w[202];
    uint32_t i;
    if (n > 200u)
        return;
    w[0] = 0xF0;
    for (i = 0; i < n; i++)
        w[1 + i] = p[i] & 127u;
    w[1 + n] = 0xF7;
    ota_wire_send(w, n + 2u);
}
static void hal_midi_out(uint32_t status, uint32_t d1, uint32_t d2)
{
    midi_out_event((status >> 4) | status << 8 | (d1 & 127u) << 16 | (d2 & 127u) << 24);   /* (dropped with no host) */
}
#define HALF_FRAMES 128u
#define HALF_WORDS (HALF_FRAMES * 2u)
static int32_t abuf[2u * HALF_WORDS] __attribute__((aligned(4)));
static void app_audio(int32_t *out);
void fm1_alnk0_irq(void)                  /* via isr_alnk0 (fm1_isr.S) */
{
    uint8_t p = fm1_audio_pending();
    fm1_audio_ack_aux(p);
    if (p & FM1_AUDIO_HALF) {
        uint32_t half = fm1_audio_free_half(), b, i, t0 = fm1_ticks(), pct;
        int32_t *o = &abuf[half * HALF_WORDS];
        for (b = 0; b < HALF_FRAMES; b += AUDIO_BLOCK)
            app_audio(o + 2u * b);
        for (i = 0; i < HALF_WORDS; i++)
            o[i] >>= 1;                   /* 24 bits with 6 dB to spare, as Felucca sends them */
        fm1_audio_ack_half();
        if (fm1_audio_free_half() != half)
            audio_late++;                 /* the DMA moved on while we rendered */
        /* the load: the ticks this took (TIMER5 nested in it included) of the half's 2.9 ms */
        pct = (fm1_ticks() - t0) / ((HALF_FRAMES * 1000000u / AUDIO_FS) * FM1_TICKS_PER_US / 100u);
        load_avg_q4 += pct - load_avg_q4 / 16u;
        if (pct >= load_peak || fm1_ms - load_peak_ms > 2000u) {
            load_peak = pct;
            load_peak_ms = fm1_ms;
        }
    }
}
extern void isr_alnk0(void);
static void audio_start(void)
{
    uint32_t i;
    for (i = 0; i < 2u * HALF_WORDS; i++)
        abuf[i] = 0;
    fm1_audio_init(abuf, HALF_WORDS, isr_alnk0, 3);
}
static void audio_silence(void)           /* IRQs off: the DMA would loop what is in the buffer */
{
    uint32_t i;
    for (i = 0; i < 2u * HALF_WORDS; i++)
        abuf[i] = 0;
}

/* ------------------------------------------------------------- store --- */
#define STORE_AT FL_DATA_LO               /* 0x97000: a firmware's own data (fm1_flash.h) */
static int fl_read_safe(uint32_t off, void *p, uint32_t n)   /* 256-byte windows with interrupts off */
{
    uint8_t *d = p;
    while (n) {
        uint32_t k = n > 256u ? 256u : n, f = irq_save();
        int rc = FL_FAR(fl_read_ram)(off, d, k);
        irq_restore(f);
        if (rc)
            return rc;
        off += k;
        d += k;
        n -= k;
    }
    return 0;
}
static int hal_store_read(void *dst, uint32_t from, uint32_t n)
{
    if (!flash_ok || !FL_IN(STORE_AT + from, n, FL_DATA_LO, FL_DATA_HI))
        return -1;
    return fl_read_safe(STORE_AT + from, dst, n);
}
static int hal_store_write(const void *base, uint32_t total, uint32_t from, uint32_t n)
{
    uint32_t s, took, f;
    if (!flash_ok || !FL_IN(STORE_AT, total, FL_DATA_LO, FL_DATA_HI) || from > total || n > total - from)
        return -1;
    for (s = from / 0x1000u; s * 0x1000u < from + n; s++) {   /* the sectors the change touches, each as a whole */
        uint32_t off = s * 0x1000u, k = total - off < 0x1000u ? total - off : 0x1000u;
        int rc;
        fm1_wdt_feed();
        f = irq_save();
        audio_silence();
        rc = FL_FAR(fl_erase4k_ram)(STORE_AT + off, &took);
        irq_restore(f);
        if (!rc)
            rc = fl_write(STORE_AT + off, (const uint8_t *)base + off, k);
        if (rc)
            return rc;
    }
    return 0;
}

/* ------------------------------------------------------------ update --- */
static uint32_t ota_now_ms(void) { return fm1_ms; }
static void ota_idle(void) { fm1_wdt_feed(); }
static int ota_in_area(uint32_t off, uint32_t n) { return FL_IN(off, n, OTA_AREA, OTA_AREA + OTA_AREA_LEN); }
static int ota_erase(uint32_t off)
{
    uint32_t took;
    if (!ota_in_area(off, 0x1000u) || (off & 0xFFFu))
        return -8;
    return fl_erase4k(off, &took);
}
static int ota_prog(uint32_t off, const void *p, uint32_t n)
{
    if (!ota_in_area(off, n))
        return -8;
    return fl_write(off, p, n);
}
static int ota_fread(uint32_t off, void *p, uint32_t n) { return fl_read_safe(off, p, n); }
static void ota_show(uint32_t step, int32_t code)   /* the steps as a bar across the middle; red on a failure */
{
    static uint8_t cleared;
    if (!cleared) {
        cleared = 1;
        lcd_fill_rows(0, SCR_H, 0);
    }
    lcd_fill_rows(112, 16, 0x2104);
    if (step < 9u) {
        uint32_t i, w = step * (SCR_W / 8u);
        for (i = 0; i < SCR_W * BAND; i++)
            band_px[i] = i % SCR_W < w ? 0xFFFF : 0x0421;         /* (0x2104 swapped) */
        lcd_rows(112, BAND, band_px);
        lcd_rows(120, BAND, band_px);
    } else {
        lcd_fill_rows(112, 16, code == 1 ? 0x07E0 : 0xF800);
    }
}
static void ota_commit(const uint8_t *parm)
{
    guard.pending = 0;                    /* an intentional reset, not a failed boot */
    guard.failed = 0;
    usb_detach();
    fm1_delay_ms(30);
    fm1_enter_update(parm);
}

/* a fault: the sound off, a red screen, then reset */
static void fm1_fault(const fm1_crash_t *c)
{
    (void)c;
    fm1_audio_stop();
    lcd_fill_rows(0, SCR_H, 0xF800);
    fm1_delay_ms(1500);
    fm1_reboot();
}

static void to_uboot(void)                /* the chip's own update mode: the way back to any firmware */
{
    fm1_audio_stop();
    lcd_fill_rows(0, SCR_H, 0);
    lcd_fill_rows(112, 16, 0x001F);
    usb_detach();
    fm1_delay_ms(30);
    guard.pending = 0;
    guard.failed = 0;
    fm1_enter_uboot();
}

#include "../src/orbit.c"

/* notes, program change and bank select from a computer or a keyboard over USB-MIDI */
static void midi_poll(void)
{
    while (mi_r != mi_w) {
        uint32_t pkt = midi_in_q[mi_r % MQ];
        mi_r++;
        app_midi((pkt >> 8) & 0xFFu, (pkt >> 16) & 127u, (pkt >> 24) & 127u);
    }
    midi_in_overflow = 0;
}

static void app_main(void)
{
    uint32_t last_tick = 0, last_adc = 0, both_t0 = 0, healthy = 0, f;
    f = irq_save();
    {                                     /* the two 1 MiB parts FM-1s have (newer units: UC25HQ80), as Felucca 1.8.2+ */
        uint32_t id = FL_FAR(fl_jedec_ram)();
        flash_ok = id == 0x856014u || id == 0xB36014u;
    }
    irq_restore(f);
    if (flash_ok)
        ota_boot_cleanup();               /* what an interrupted update left behind */
    lcd_init();
    fm1_input_init();
    fm1_adc_init();
    (void)fm1_adc_read(FM1_ADC_MASTER);
    {
        int32_t a = fm1_adc_read(FM1_ADC_MASTER);
        if (a >= 0)
            master_knob = a * 16;
    }
    {                                     /* the battery as it stands, before the first frame */
        int32_t b = fm1_adc_read(FM1_ADC_BATT);
        batt_level = b >= 591 ? 3u : b >= 561 ? 2u : b >= 531 ? 1u : b > 0 ? 0u : 3u;
        batt_update(b);
    }
    app_init();
    syn.master = (uint32_t)(master_knob / 16);
    audio_start();
    usb_start();
    fm1_timer5_start(isr_timer5, 4);
    fm1_guard_lock_top();
    fm1_irq_enable_all();
    fm1_lcd_backlight(1);
    for (;;) {
        uint32_t now = fm1_ms;
        fm1_wdt_feed();
        usb_retry(now);
        if (usb.uboot_req)                /* the SysEx soft key */
            to_uboot();
        {                                 /* sounds from a computer: ours by their first bytes, the rest is the installer's */
            const uint8_t *sp;
            uint32_t sn;
            if (ota_frame_get(&sp, &sn) && sn >= 4u && sp[0] == 0x7Du && sp[1] == 'o' && sp[2] == 'r' && sp[3] == 'b') {
                app_sysex(sp, sn);
                ota_frame_done();
            }
        }
        ota_service();                    /* the installer's handshake */
        if (usb.ota_req) {                /* and its update: commits and resets, or comes back */
            usb.ota_req = 0;
            if (flash_ok) {
                fm1_audio_stop();
                ota_session();
                audio_start();
            }
            lcd_fill_rows(0, SCR_H, 0);
        }
        if (!healthy && now > 2000u) {    /* it runs: the next boot is not a loop */
            healthy = 1;
            guard.pending = 0;
            guard.failed = 0;
        }
        if ((fm1_in.buttons & 3u) != 3u)  /* OCT- and OCT+ (matrix buttons 0 and 1) held 5 s: UBOOT */
            both_t0 = now;
        else if (now - both_t0 > 5000u)
            to_uboot();
        midi_poll();
        if (now - last_adc >= 40u) {
            int32_t a = fm1_adc_read(FM1_ADC_MASTER);
            last_adc = now;
            if (a >= 0)
                master_knob += (a * 16 - master_knob) / 4;
            batt_update(fm1_adc_read(FM1_ADC_BATT));
        }
        if (now - last_tick >= 15u) {
            last_tick = now;
            app_tick();
        }
    }
}

void fm1_cstart(void)
{
    uint32_t *s, *d;
    fm1_time_init();
    fm1_wdt_arm(0x0D);
    if (guard.magic != 0x4F524231u || guard.pending > 1u || guard.failed > 1u) {
        guard.magic = 0x4F524231u;
        guard.failed = 0;
        guard.pending = 0;
    }
    if (guard.pending)
        guard.failed++;
    guard.pending = 1;
    if (guard.failed >= 2u) {
        guard.failed = 0;
        guard.pending = 0;
        fm1_enter_uboot();
    }
    fm1_irq_init();
    for (d = _bss_start; d < _bss_end; d++)
        *d = 0;
    for (s = _data_load, d = _data_start; d < _data_end; s++, d++)
        *d = *s;
    for (s = _rt_load, d = _rt_start; d < _rt_end; s++, d++)
        *d = *s;
    fm1_guard_enable(FM1_GUARD_STACK | FM1_GUARD_WRITE | FM1_GUARD_BUS | FM1_GUARD_PC);
    app_main();
    for (;;)
        ;
}
