#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# The firmware in the browser:  ./build_web.sh  ->  build/emu/{index.html, worklet.js, orbit.wasm}
#   PYTHON   a python3 with Pillow (the font)          default: python3
set -e
cd "$(dirname "$0")"
PY="${PYTHON:-python3}"
command -v emcc >/dev/null 2>&1 || { echo "build_web: no emcc (Emscripten)"; exit 1; }
mkdir -p build/gen build/emu/fonts
"$PY" third_party/felucca/tools/gen_tables.py build/gen/tables.h >/dev/null
"$PY" tools/gen_voices.py third_party/mvave/fm_factory.inc build/gen/voices.h >/dev/null
"$PY" tools/gen_font.py assets/SpaceMono-Regular.ttf build/gen/fonts.h s:12:400 m:17:400 l:30:400 >/dev/null
emcc -O2 -ffp-contract=off -std=gnu99 -Wall -Wno-unused-function -Wno-unused-const-variable -Ibuild/gen -Isrc \
    --no-entry -sSTANDALONE_WASM -sSTACK_SIZE=1048576 -sINITIAL_MEMORY=33554432 -sFILESYSTEM=0 \
    -o build/emu/orbit.wasm web/hal_web.c
VERSION="$(git describe --always --dirty 2>/dev/null || echo dev)"
sed -e "s/@VERSION@/$VERSION/g" web/emu/index.html > build/emu/index.html
cp web/emu/worklet.js build/emu/
cp assets/SpaceMono-Regular.ttf build/emu/fonts/
cp assets/OFL-SpaceMono.txt build/emu/fonts/OFL.txt
rm -f build/emu/felucca.wasm build/emu/fonts/DotGothic16-subset.woff
echo "build_web: build/emu ($(wc -c < build/emu/orbit.wasm | tr -d ' ') B wasm)"
