#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Sounds from DX7 files onto an FM-1 running orbit, over USB.

  orbit_load.py FILE.syx --list            the sounds in the file
  orbit_load.py FILE.syx                   all of them into your next empty places (129..256)
  orbit_load.py FILE.syx --to 161          into 161 and on (what is there is replaced; any of 1..256)
  orbit_load.py FILE.syx --only 1,5,9-12   only these of the file
  orbit_load.py FILE.syx --hear 7          play number 7 on the FM-1 without storing it (SAVE keeps it)
  orbit_load.py --clear 129-160            these places as they were at first: 129..256 empty, 1..128 the
                                           factory's sounds again

FILE: a DX7 cartridge (32 voices, 4104 bytes, or its bare 4096), several of them one after another, or single
voices (163 bytes). Needs mido with python-rtmidi.
  orbit_load.py --status                   how many of your places are in use
  orbit_load.py --rename 129 "MY PAD"      another name for the sound in a place (ten letters at most)
  orbit_load.py --backup FILE.json         every sound on the FM-1 (all 256 places, with their effects and
                                           settings), the 16 patterns and GLO's, ARP's and SEQ's settings
                                           into a file
  orbit_load.py --restore FILE.json        a backup's sounds back into the places they came from (places the
                                           backup had empty are left as they are), its patterns and settings
  orbit_load.py --set SET.json [--to N]    sounds with orbit's own settings (effects, TONE, ATTACK, RELEASE):
      {"sounds": [{"from": "bank.syx", "voice": 11, "name": "WOBBLE EP", "tone": 0, "attack": 0, "release": 10,
                   "fx": {"phaser": [15, 70, 55], "reverb": [1, 45, 25]}}, ...]}
      from: a DX7 file, by its path from the set's folder. fx: the effects that are on, each with its three
      values (dist: gain tone level; filter: type 0..2 cutoff reso; phaser, chorus: rate depth mix; delay: time
      repeat mix; reverb: type 0..2 decay mix). Left out: off, at its usual values.
The messages (app.c: app_sysex) are F0 7D 'o' 'r' 'b' cmd ... F7. The firmware answers each one; one that is not
answered is sent again, and the load only counts when every voice arrived.
"""
import argparse
import json
import os
import sys
import time

HEAD = [0x7D, ord("o"), ord("r"), ord("b")]
FIRST, LAST = 1, 256


def pack_voice(v):
    """a single voice's 155 bytes -> the cartridge's 128"""
    out = []
    for k in range(6):
        o = v[k * 21:k * 21 + 21]
        out += o[0:11]
        out.append((o[11] & 3) | (o[12] & 3) << 2)
        out.append((o[13] & 7) | (o[20] & 15) << 3)
        out.append((o[14] & 3) | (o[15] & 7) << 2)
        out.append(o[16])
        out.append((o[17] & 1) | (o[18] & 31) << 1)
        out.append(o[19])
    g = v[126:]
    out += g[0:8]
    out.append(g[8] & 31)
    out.append((g[9] & 7) | (g[10] & 1) << 3)
    out += g[11:15]
    out.append((g[15] & 1) | (g[16] & 7) << 1 | (g[17] & 7) << 4)
    out.append(g[18])
    out += g[19:29]
    return [b & 127 for b in out]


def voices_of(data):
    """every voice in the file, each as 128 bytes"""
    out, i = [], 0
    if len(data) % 4096 == 0 and data[:1] != b"\xF0":
        return [list(data[k:k + 128]) for k in range(0, len(data), 128)]
    while i < len(data):
        if data[i] != 0xF0:
            i += 1
            continue
        end = data.find(b"\xF7", i)
        if end < 0:
            break
        m = data[i:end + 1]
        i = end + 1
        if len(m) == 4104 and m[1] == 0x43 and m[3] == 0x09:
            out += [list(m[6 + k:6 + k + 128]) for k in range(0, 4096, 128)]
        elif len(m) == 163 and m[1] == 0x43 and m[3] == 0x00:
            out.append(pack_voice(list(m[6:161])))
    return [[b & 127 for b in v] for v in out]


def name_of(v):
    return "".join(chr(c) if 32 <= c < 127 else " " for c in v[118:128]).rstrip()


def numbers(text, lo, hi):
    out = []
    for part in text.split(","):
        a, _, b = part.partition("-")
        a, b = int(a), int(b or a)
        if not lo <= a <= b <= hi:
            raise SystemExit(f"{part}: outside {lo}..{hi}")
        out += range(a, b + 1)
    return out


def check(v):
    return (-sum(v)) & 127


FX = ["dist", "filter", "phaser", "chorus", "delay", "reverb"]
FX_USUAL = [[40, 60, 70], [0, 70, 20], [30, 60, 50], [30, 50, 50], [40, 40, 35], [1, 50, 30]]   # (fx.c)


def sounds_of_set(path):
    """a set file -> [(voice's 128 bytes, the 22 bytes of its settings)]"""
    out, files = [], {}
    here = os.path.dirname(os.path.abspath(path))
    for k, s in enumerate(json.load(open(path))["sounds"], 1):
        src = os.path.join(here, s["from"])
        if src not in files:
            files[src] = voices_of(open(src, "rb").read())
        if not 1 <= s["voice"] <= len(files[src]):
            raise SystemExit(f"sound {k}: {s['from']} has voices 1..{len(files[src])}")
        v = list(files[src][s["voice"] - 1])
        if "name" in s:
            v[118:128] = [ord(c) if 32 <= ord(c) < 127 else 32 for c in s["name"].upper()[:10].ljust(10)]
        on, vals = 0, [list(u) for u in FX_USUAL]
        for name, three in s.get("fx", {}).items():
            if name not in FX or len(three) != 3:
                raise SystemExit(f"sound {k}: fx {name!r}: one of {', '.join(FX)}, with three values")
            on |= 1 << FX.index(name)
            vals[FX.index(name)] = [max(0, min(100, int(t))) for t in three]
        x = [max(0, min(127, int(s.get(m, 0)) + 64)) for m in ("tone", "attack", "release")] + [on]
        x += [t for three in vals for t in three]
        out.append((v, x))
    return out


class Link:
    """the FM-1's MIDI output and input; every message is answered (app.c: imp_answer)"""

    def __init__(self, name):
        try:
            import mido
        except ImportError:
            raise SystemExit("needs mido and python-rtmidi (pip install mido python-rtmidi)")
        import queue
        self.mido, self.q, self.d, self.s, self.Empty = mido, queue.Queue(), queue.Queue(), queue.Queue(), queue.Empty

        def pick(names):
            for want in [name] if name else ["orbit", "felucca", "fm-1"]:   # (macOS may remember a name from before)
                hit = [o for o in names if want.lower() in o.lower()]
                if hit:
                    return hit[0]
            raise SystemExit("no FM-1 running orbit found over USB. MIDI ports: " + (", ".join(names) or "none"))

        self.inp = mido.open_input(pick(mido.get_input_names()), callback=self._rx)
        self.out = mido.open_output(pick(mido.get_output_names()))
        time.sleep(0.3)   # (CoreMIDI may drop a message sent just after opening)

    def _rx(self, msg):
        if msg.type == "sysex" and list(msg.data[:5]) == HEAD + [0x7F] and len(msg.data) == 13:
            self.q.put(list(msg.data[5:]))
        elif msg.type == "sysex" and list(msg.data[:5]) == HEAD + [0x7E] and len(msg.data) in (8, 160):
            self.d.put(list(msg.data[5:]))
        elif msg.type == "sysex" and list(msg.data[:5]) == HEAD + [0x7D] and len(msg.data) in (18, 104):
            self.s.put(list(msg.data[5:]))

    def read_seq(self, i, wait=1.0, tries=3):
        """pattern i (0..15) as its 97 bytes, or with i = 0x7F the settings' 11; None when nothing answers"""
        for _ in range(tries):
            while not self.s.empty():
                self.s.get_nowait()
            self.out.send(self.mido.Message("sysex", data=HEAD + [9, i]))
            end = time.time() + wait
            while time.time() < end:
                try:
                    r = self.s.get(timeout=max(end - time.time(), 0.01))
                except self.Empty:
                    break
                if r[0] == i and check(r[1:-1]) == r[-1]:
                    return r[1:-1]
        return None

    def read(self, place, wait=1.0, tries=5):
        """what is in a place (1..256): None for an empty one, else (the voice's 128 bytes, its 22 settings)"""
        k = place - 1
        for _ in range(tries):
            while not self.d.empty():
                self.d.get_nowait()
            self.out.send(self.mido.Message("sysex", data=HEAD + [8, k >> 7, k & 127]))
            end = time.time() + wait
            while time.time() < end:
                try:
                    r = self.d.get(timeout=max(end - time.time(), 0.01))
                except self.Empty:
                    break
                if r[0] << 7 | r[1] != k:
                    continue
                if not r[2]:
                    return None
                v, x = r[3:131], r[132:154]
                if check(v) == r[131] and check(x) == r[154]:
                    return v, x
        raise SystemExit(f"place {place}: the FM-1 does not answer (an orbit that can be backed up?)")

    def ask(self, body, wait=1.0, tries=5):
        """send; the answer as (ok, n, a, b), or stop when none comes"""
        for _ in range(tries):
            while not self.q.empty():
                self.q.get_nowait()
            self.out.send(self.mido.Message("sysex", data=HEAD + body))
            end = time.time() + wait
            while time.time() < end:
                try:
                    r = self.q.get(timeout=max(end - time.time(), 0.01))
                except self.Empty:
                    break
                if r[0] == body[0]:
                    return r[1], r[2] << 7 | r[3], r[4] << 7 | r[5], r[6] << 7 | r[7]
        raise SystemExit("the FM-1 does not answer. Is it connected, and running an orbit that takes sounds?")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file", nargs="?")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--to", type=int, metavar="PLACE")
    ap.add_argument("--only", metavar="N,N-M")
    ap.add_argument("--hear", type=int, metavar="N")
    ap.add_argument("--clear", metavar="A-B")
    ap.add_argument("--status", action="store_true", help="how many places of yours are in use")
    ap.add_argument("--set", metavar="SET.json", help="sounds with their effects and settings")
    ap.add_argument("--rename", nargs=2, metavar=("PLACE", "NAME"), help="another name for a place's sound")
    ap.add_argument("--backup", metavar="FILE.json", help="every sound on the FM-1 into a file")
    ap.add_argument("--restore", metavar="FILE.json", help="a backup's sounds back into their places")
    ap.add_argument("--port", help="part of the MIDI port's name")
    a = ap.parse_args()

    if a.status:
        _, used, at, _ = Link(a.port).ask([6])
        print(f"{used} of 128 places of yours in use, {128 - used} empty; playing place {at + 1}")
        return
    if a.rename:
        place, name = numbers(a.rename[0], FIRST, LAST)[0], a.rename[1].strip()
        if not name or len(name) > 10 or any(not 32 <= ord(c) < 127 for c in name):
            raise SystemExit("a name: one to ten plain letters, figures or signs")
        link = Link(a.port)
        got = link.read(place)
        if not got:
            raise SystemExit(f"place {place} is empty")
        v, x = got
        was = name_of(v)
        v[118:128] = [ord(c) for c in name.upper().ljust(10)]
        link.ask([0])
        k = place - 1
        ok = link.ask([7, 0, 0, k >> 7, k & 127] + v + [check(v)] + x + [check(x)])[0]
        if not ok or link.ask([3, 1], wait=8.0, tries=1)[0] != 1:
            raise SystemExit("the FM-1 did not take the name. Nothing was changed")
        print(f"place {place}: {was} is now {name_of(v)} (the FM-1 plays it now)")
        return
    if a.backup:
        if os.path.exists(a.backup):
            raise SystemExit(f"{a.backup} is there already: another name, so that no backup is written over")
        link, sounds = Link(a.port), []
        for p in range(FIRST, LAST + 1):
            got = link.read(p)
            if got:
                sounds.append({"place": p, "name": name_of(got[0]), "voice": got[0], "settings": got[1]})
            print(f"\rreading {p}/{LAST}", end="", flush=True)
        print()
        out = {"orbit_backup": 1, "made": time.strftime("%Y-%m-%d %H:%M"), "sounds": sounds}
        settings = link.read_seq(0x7F)
        if settings:
            pats = [link.read_seq(i) for i in range(16)]
            if all(pats):
                out["settings"], out["patterns"] = settings, pats
        with open(a.backup, "w") as f:
            json.dump(out, f, indent=0)
        more = ", the 16 patterns and the settings" if "patterns" in out else \
            " (not the patterns and settings: this orbit does not give them out yet)"
        print(f"{len(sounds)} sounds{more} written to {a.backup}")
        return
    if a.restore:
        b = json.load(open(a.restore))
        if b.get("orbit_backup") != 1:
            raise SystemExit(f"{a.restore}: not a backup this command wrote")
        sounds = [s for s in b["sounds"] if FIRST <= s["place"] <= LAST and len(s["voice"]) == 128 and len(s["settings"]) == 22]
        link, done = Link(a.port), 0
        for at in range(0, len(sounds), 64):          # (in loads of 64: each is stored as a whole)
            part = sounds[at:at + 64]
            link.ask([0])
            for k, s in enumerate(part):
                v, x, p = [t & 127 for t in s["voice"]], [t & 127 for t in s["settings"]], s["place"] - 1
                ok, got, _, _ = link.ask([7, k >> 7, k & 127, p >> 7, p & 127] + v + [check(v)] + x + [check(x)])
                if not ok or got != k + 1:
                    raise SystemExit(f"place {s['place']}: the FM-1 did not take it ({done} sounds are back so far)")
                print(f"\rsending {at + k + 1}/{len(sounds)}", end="", flush=True)
            if link.ask([3, len(part) & 127], wait=8.0, tries=1)[0] != 1:
                raise SystemExit(f"\nthe FM-1 could not store the sounds ({done} are back so far)")
            done += len(part)
        more = ""
        if len(b.get("settings", [])) == 11 and len(b.get("patterns", [])) == 16:
            parts = [(0x7F, b["settings"])] + [(i, pt) for i, pt in enumerate(b["patterns"]) if len(pt) == 97]
            for i, d in parts:
                d = [t & 127 for t in d]
                if not link.ask([0x0A, i] + d + [check(d)])[0]:
                    raise SystemExit(f"\nthe sounds are back, but the FM-1 did not take the patterns and settings")
            if not link.ask([0x0B], wait=4.0)[0]:
                raise SystemExit(f"\nthe sounds are back, but the FM-1 could not store the patterns and settings")
            more = ", the patterns and the settings"
        print(f"\n{done} sounds back in their places{more} (from the backup of {b.get('made', '?')})")
        return
    if a.clear:
        places = numbers(a.clear, FIRST, LAST)
        link = Link(a.port)
        for p in places:
            if not link.ask([5, (p - 1) >> 7, (p - 1) & 127], wait=2.0)[0]:
                raise SystemExit(f"place {p}: the FM-1 could not do it")
        print(f"{len(places)} place(s) as at first (129..256 empty, 1..128 the factory's sounds)")
        return
    extra = None
    if a.set:
        both = sounds_of_set(a.set)
        voices, extra = [b[0] for b in both], [b[1] for b in both]
    elif not a.file:
        ap.error("a file, --set, --clear or --status")
    else:
        voices = voices_of(open(a.file, "rb").read())
    if not voices:
        raise SystemExit(f"{a.file or a.set}: no DX7 voices found in it")
    picked = numbers(a.only, 1, len(voices)) if a.only else list(range(1, len(voices) + 1))
    if a.list:
        for n in picked:
            print(f"{n:4d}  {name_of(voices[n - 1])}")
        return
    if a.hear is not None:
        if not 1 <= a.hear <= len(voices):
            raise SystemExit(f"--hear: the file has 1..{len(voices)}")
        v = voices[a.hear - 1]
        if not Link(a.port).ask([1] + v + [check(v)])[0]:
            raise SystemExit("the FM-1 did not take the voice")
        print(f"the FM-1 plays {a.hear}: {name_of(v)}   (SAVE on it keeps the sound)")
        return
    if len(picked) > 128:
        raise SystemExit(f"{len(picked)} sounds: there are 128 places of yours. Choose with --only")
    if a.to is not None and not (FIRST <= a.to and a.to + len(picked) - 1 <= LAST):
        raise SystemExit(f"--to {a.to}: {len(picked)} sounds do not fit in {FIRST}..{LAST} from there")
    link = Link(a.port)
    if a.to is None:
        room = 128 - link.ask([6])[1]
        if len(picked) > room:
            raise SystemExit(f"{len(picked)} sounds, but only {room} empty place(s). Fewer with --only, or --to / --clear")
    link.ask([0])
    for k, n in enumerate(picked):
        v = voices[n - 1]
        place = [0x7F, 0x7F] if a.to is None else [(a.to - 1 + k) >> 7, (a.to - 1 + k) & 127]
        if extra:
            x = extra[n - 1]
            ok, got, _, _ = link.ask([7, k >> 7, k & 127] + place + v + [check(v)] + x + [check(x)])
        else:
            ok, got, _, _ = link.ask([2, k >> 7, k & 127] + place + v + [check(v)])
        if not ok or got != k + 1:
            raise SystemExit(f"sound {n} ({name_of(v)}): the FM-1 did not take it. Nothing was changed")
        print(f"\rsending {k + 1}/{len(picked)}", end="", flush=True)
    print()
    ok, count, lo, hi = link.ask([3, len(picked) & 127], wait=8.0, tries=1)   # (it stores now: a few seconds)
    if ok == 2:
        raise SystemExit("not enough empty places. Nothing was changed")
    if ok != 1:
        raise SystemExit("the FM-1 could not store the sounds. Nothing was changed")
    print(f"loaded {count} sound(s) into places {lo + 1}..{hi + 1}; the FM-1 plays {lo + 1} now")


if __name__ == "__main__":
    sys.exit(main())
