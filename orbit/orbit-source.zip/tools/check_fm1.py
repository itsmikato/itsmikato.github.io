#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Checks on the device build that need no device:  tools/check_fm1.py build/fm1

  - the image starts with the entry stub, at the app's address
  - the code that runs from RAM (the flash driver) calls nothing
  - nothing refers to the chip's ROM
  - felucca-bsp docs/CPU.md: on this chip a 64-bit multiply inlined among 16-bit loads now and then leaves a
    register a bit off. Lists every function that has both, with the closest distance between the two in
    instructions; fails when a multiply and a 16-bit load are within NEAR instructions of each other.
"""
import bisect
import re
import sys

NEAR = 24
# the FM core (third_party/felucca fm6_core.c) is compiled here as Felucca compiles and ships it: reported, not failed
KNOWN = ("fm6_",)
out = sys.argv[1]
dis = open(f"{out}/orbit.dis").read()
syms = open(f"{out}/orbit.sym").read()
img = open(f"{out}/orbit.bin", "rb").read()
fails = []
if img[:4].hex() != "04818000":
    fails.append(f"image starts with {img[:4].hex()}, not the entry stub")
text, ram = dis.split("Disassembly of section .ram_text:") if ".ram_text:" in dis else (dis, "")
if re.search(r"\bcall\b", ram):
    fails.append(".ram_text contains calls")
funcs = sorted((int(m[1], 16), m[2]) for m in re.finditer(r"^([0-9a-f]{8}) .{7} \.text\S*\s+[0-9a-f]+ (\S+)$", syms, re.M))
starts = [a for a, _ in funcs]
per = {}
for n, ln in enumerate(text.splitlines()):
    m = re.match(r"\s*([0-9a-f]+):\s+(?:[0-9a-f]{2} )+\s*(.*)", ln)
    if not m:
        continue
    addr, ins = int(m[1], 16), m[2]
    if re.search(r"call -?\d+ <[^:>]*: (ffc|FFC)", ins):
        fails.append(f"reference to the ROM at {addr:#x}")
    i = bisect.bisect_right(starts, addr) - 1
    name = funcs[i][1] if i >= 0 else "?"
    d = per.setdefault(name, {"mul": [], "h": []})
    if re.search(r"\br\d+_r\d+\s*\+?=\s*r\d+\s*\*\s*r\d+", ins):
        d["mul"].append(n)
    if re.search(r"=\s*h\[", ins) and not ins.strip().startswith("h["):
        d["h"].append(n)
print(f"{len(funcs)} functions, {sum(len(d['mul']) for d in per.values())} 64-bit multiplies")
for name, d in sorted(per.items()):
    if d["mul"] and d["h"]:
        gap = min(abs(a - b) for a in d["mul"] for b in d["h"])
        print(f"  {name}: {len(d['mul'])} multiplies, {len(d['h'])} 16-bit loads, closest {gap} instructions apart")
        if gap <= NEAR and name.startswith(KNOWN):
            print("    (the FM core, as in Felucca's own firmware)")
        elif gap <= NEAR:
            fails.append(f"{name}: a 64-bit multiply {gap} instructions from a 16-bit load")
    elif d["mul"]:
        print(f"  {name}: {len(d['mul'])} multiplies, no 16-bit load")
for f in fails:
    print("FAIL", f)
sys.exit(1 if fails else 0)
