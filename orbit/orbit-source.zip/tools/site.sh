#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# orbit for a web site:  tools/site.sh DIR  ->  DIR/{index.html, worklet.js, orbit.wasm, fonts/, orbit-source.zip}
# The page with the firmware in it, and the source of exactly that version beside it (the tracked files as
# they are now, no history): who gets the one can get the other. Run ./build_web.sh first.
set -e
cd "$(dirname "$0")/.."
[ -n "$1" ] || { echo "site: where to? tools/site.sh DIR"; exit 1; }
[ -f build/emu/orbit.wasm ] || { echo "site: no build/emu: run ./build_web.sh first"; exit 1; }
mkdir -p "$1/fonts"
OUT="$(cd "$1" && pwd)"
cp build/emu/index.html build/emu/worklet.js build/emu/orbit.wasm "$OUT/"
cp build/emu/fonts/* "$OUT/fonts/"
rm -f "$OUT/orbit-source.zip"
git ls-files -z | xargs -0 zip -q -X "$OUT/orbit-source.zip"
echo "site: $OUT ($(git describe --always --dirty), source $(wc -c < "$OUT/orbit-source.zip" | tr -d ' ') B)"
